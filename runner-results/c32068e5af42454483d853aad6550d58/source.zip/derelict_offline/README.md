# Derelict offline experiment 0.1.8

This standalone research package runs without Surveyor or NMS. It contains the
experiment, its direct analyzer dependencies, regression fixtures, tests and
current handoff. Python 3.10+ is required. The optional emulator uses pinned
Unicorn 2.1.4; no dependency or game executable is bundled.

## Local runner and GitHub evidence uploads

Windows launchers now install/update and run from
`%USERPROFILE%\Documents\NMS Runner` (on your PC,
`C:\Users\Vikman\Documents\NMS Runner`). Unicorn, GitHub settings and reports
stay in that permanent folder across future ZIP updates.

Run `Start-Runner.cmd` once to open the desktop window. It prepares Unicorn only if needed, tests a frozen
snapshot, checks bundled evidence, runs 4,040 comparisons and packages results.
It then waits for stable source changes or a fixed NMS request. Ctrl+C stops.
Developer status: `python start.py runner --status`. Source/evidence ZIPs and
logs are under `reports/<request_id>/`; `.local/latest-result.json` points to
the latest result. Run `Setup-GitHub.cmd` once to enable automatic uploads to
your NMS-Derelict-Probe repo's `nms-runner-evidence` branch. The setup installs
GitHub CLI if needed and uses its sign-in flow. See RUNNER.md and
GITHUB_CHECK_PROMPT.md for the scheduled ChatGPT research continuation. Uploads are off until
setup succeeds. The repository is public; uploaded evidence/source are public.

0.1.6 fixes a Windows-only test failure: the symlink guard test no longer creates
a real symbolic link or requires administrator privileges. The user's 0.1.5
log confirms Unicorn installation and upload of a failed-run report. That report
failed at this test, not the emulator. Installer progress is now streamed live;
an expected missing-Unicorn probe gives a friendly automatic-repair message.

All 100 experiment checks passed with Unicorn on Linux. Twelve permanent-folder
checks cover preservation, retries, backups, conflicts and worker locks. The desktop window has Start,
Pause/Resume, Stop, Run check, Retry uploads, latest check/upload status and a
collapsible live activity area. Pause finishes the current job before waiting;
Stop cancels owned work. The Developer button shows diagnostics and exports the
complete source ZIP. Each report now carries the exact tested AI_HANDOFF.md and
GITHUB_CHECK_PROMPT.md as readable artifacts for the scheduled research task. `Start-Runner-CLI.cmd` retains console access; existing
`Start-Runner.cmd --once/--status/--exe ...` arguments still use console mode.
The GUI's first Windows run still needs confirmation. A ChatGPT task reviews uploads
and continues offline research hourly; five-minute scheduling is unsupported. No
automatic build download/application is configured. Surveyor and the existing Unspottable runner are untouched.

## Installer repair in 0.1.3

The old launcher printed nothing before its first Python command finished.
That hid startup failures or delays; the exact failure on the user's PC is
unknown because the old launcher did not log it. This version immediately
prints a startup banner, uses unbuffered output and CALL, reports each setup
stage, pauses on success/failure, and ships all CMD files with Windows CRLF.
`install_unicorn.py` preserves an existing private environment, installs the
pinned dependency and verifies an actual x64 instruction. A small structured
`latest-install.log` records stages/exit codes without machine paths or IDs.

A real clean virtual-environment installation and instruction check passed on
the Linux development host, using a local official wheel. The user subsequently
confirmed the repaired installer worked on Windows.
Five setup/packaging regressions cover preserved environments, failed venv,
failed pip, incomplete extraction and launcher bytes. The full project suite
passed in the previous 0.1.3 workspace: 303 run / 285 passed / 18 display skips.
That full application suite is not included in this experiment-only package;
0.1.8 reruns all experiment tests; verification.json retains its historical
provenance. Current verification and remaining gates are in STATUS.json.

If setup still fails, attach `latest-install.log`; the console remains open.
No further game export is needed to diagnose installation.

## Run on Windows

1. Stop the old runner and close its window.
2. To migrate your existing setup, copy the contents of this ZIP's
   `derelict_offline` folder over your current runner folder. Keep `.local`,
   `.unicorn-venv` and `reports`; use the new launchers.
3. Open `Start-Runner.cmd`. It copies the experiment and missing runtime data
   to `C:\Users\Vikman\Documents\NMS Runner`, then opens the GUI there.
4. Use `Start-Runner.cmd` in the permanent folder from now on. New ZIP launchers
   update that same folder. For a fresh setup, simply extract and start.

`Install-Runner.cmd` performs installation without starting a check. GitHub setup,
Unicorn installation/testing and evidence-export CMD files use the same permanent
folder. A healthy existing permanent environment is retained; moving an existing
Unicorn installation creates a correctly rooted environment and reuses the pinned
package files. Original reports/settings remain in the old folder as well.
Existing permanent settings and report IDs win if copies differ; they are never
merged or overwritten. Stop both workers before updating. Source backups are in
`.local/source-backups`; see RUNNER.md for repair and rollback.

No game launch or fresh export is needed to run the bundled checks. The small
ZIP expands to a few MiB; installing Python/Unicorn separately uses more space.
Unicorn alone occupied about 56 MiB in the development installation; wheel,
pip cache and virtual environment add overhead. There is no 2 GB requirement
for these checks. Keep Python dependency installation separate from the ZIP.

Developer commands, from this folder:

```text
python start.py diagnose
python start.py code
python start.py rng --seed 9C2818C7FE094FC8
python start.py rng --seed 0 --disabled-seed
python start.py address --address 0000760006606CAB
python start.py benchmark
python -m pip install -r requirements-unicorn.txt
python start.py emulate --repetitions 1000 --out unicorn-local-result.json
python start.py test
python start.py export --exe "C:\path\to\NMS.exe"
python start.py package --out derelict-offline.zip
```

On Windows use `.unicorn-venv\Scripts\python.exe` instead of `python` to run
commands in the private installation. `Install-Unicorn.cmd` needs internet.
Base diagnostics/export/replay use Python's standard library. Missing Unicorn
produces an actionable error; it does not prevent those base functions.

## What Unicorn now verifies

The supplied second export has **149 verified code ranges / 103,256 bytes**.
All four original root-call windows match. The executable identity is still
exporter-reported: the original EXE was not uploaded and cannot be rehashed here.

The optional emulator maps only specified validated code spans at the preferred
image base. Code pages are read/execute; private data and stack are read/write.
Each case resets registers, SIMD state, stack and data. Execution has instruction
and time limits. Code gaps, unknown calls and absent memory fail explicitly.
Nothing attaches to NMS, invokes native game code, or silently supplies imports.

Measured comparisons, zero mismatches:

| Boundary | Inputs | Result |
| --- | ---: | --- |
| Enabled seed → initial RNG state | 1,009 | Exact x64 arithmetic agrees with Python |
| Supplied state → advanced state/output | 1,004 | Exact x64 arithmetic agrees with Python |
| Empty identifier-vector descriptor copy | 1,024 | Both seeds, raw flags and padding preserved |
| Identifier removal | 1,003 | First match swapped with last; seeds unchanged |

The newest export omitted vector helper bytes because its bounded dependency
quota filled. The emulator reuses exactly 406 previously exported bytes from
the preceding export, after verifying both exports and identical binary
metadata; it never overwrites latest ranges. Both source hashes are reported.

The descriptor-copy check runs the full exported constructor `00227A40` and
vector helper `02BF9A00` on a **synthetic empty vector**. The absent external
helper at `033E4B4C` is explicitly modeled only for zero byte length. Its ABI
appears copy-like; its identity is not verified. Nonzero length is refused.
A nonempty vector reaches absent allocator `02C20E90` and fails as expected.
This verifies the empty-vector path under that stated model; it does not prove
all paths through the allocator or imply captured game vectors were empty.

Identifier removal `00640EA0..00640F30` needs no environment model. The RNG
checks execute exported instruction blocks rather than the full palette function.
Disabled seed initialization remains a separately decoded constant branch.

The recorded arithmetic batch processed 2,013 cases in about 0.317 seconds
(~6,346/sec), including reset, hooks and Python comparison. This is validation
throughput on this development host, not a generation benchmark. No in-game
baseline or end-to-end speedup has been established.

## Corrections and current boundary

The new full bodies correct the earlier missing-helper hypotheses:

- `00227A40` copies the descriptor; it does not derive the root.
- `00227620` manages 32-byte identifiers, including normalization/deduplication;
  it is not a root-seed replacement helper.
- `00641160` builds an identifier string/hash; it is not a seed descriptor.
- Owner setup forwards an incoming descriptor into the copy constructor.
  Two decoded wrappers `00639490` / `00639A70` also forward that descriptor.
  Its upstream producer is still missing.

Shipwright was inspected at commit
`f89691ed037edf437a7406c176aa6b96e654d314`:
https://github.com/S-T-0-7/NMS-Shipwright/tree/f89691ed037edf437a7406c176aa6b96e654d314
Its `palette_table` signature matches the 48-byte prefix of `0062E2B0`.
This is a source-labeled palette candidate, not proof of a dungeon layout
function. The existing RNG arithmetic also agrees with Shipwright's MWC
reference on 10,005 inputs. This emulator was implemented independently;
Shipwright source was not copied. Unicorn supplies portable instruction
validation now and a controlled base for larger functions when inputs and
assets are actually known. Freighter customization is not implemented here.

**No address-to-derelict-root or root-to-layout generator exists yet.** Public
system-seed equations are a separate reference and are not derelict seeds.
Scene replay still reproduces totals 37 / 23 from captured selections. Four
captures form two repeat pairs; all lack captured full executable identity and
remain quarantined from strict generation validation. Version 7.05 is user
context only. Table Rooms=7 vs captured groups 10 / 9 remains unresolved.
Asset-derived totals are not a completed physical inventory or topology proof.

## Latest root-lineage review

All five newly exported wrapper-call sites are valid decoded instructions:
`001B2CF9`, `01688764`, `016888D2`, `02D08081`, `02D08898`.
The latter pair forwards incoming argument six as the descriptor; the other
three pass existing object/local descriptor storage. This narrows the static
input boundary but does not identify any one branch as live derelict generation.
The input descriptor's producer remains upstream. Allocator code is now present,
but allocator globals and TLS are absent; these are separate blockers.

The next research action is to trace callers of `02D07C80` / `02D08430` and
writes to the referenced descriptor storage. Do not repeatedly run the unchanged
exporter expecting extra data. The current hotfix needs only an installer retry.

Exports are bounded to 1 MiB raw code and 64 KiB per fragment, include linked
unwind fragments, and write atomically. Failure preserves a previous successful
export and removes partial output. Disk-full errors identify the actual output
location/free space. No game executable copy is created.

## Provenance and tests

Fixture manifest retains source hashes and hashes of the exact included
projections. Analyzer modules are unchanged dependencies from the 0.3.75 source
candidate. Old evidence is retained only where needed by the regression suite.
Recorded research results: `unicorn-verification.json`, `verification.json`,
`CODE_REVIEW_20261011_v0.1.3.json`, `STATUS.json`, and `AI_HANDOFF.md`.

Run `python start.py test` for the 100 focused checks. Twelve checks specifically
exercise Unicorn, including missing code/memory, instruction budgets, dependency
errors, wrong binary identity, state reset, tampering and the explicit model.
Nine optional emulation tests skip when Unicorn is absent; dependency tests
still run. One legacy native arithmetic check is Linux x64 only.

No Surveyor UI, updater, runtime, saved formats or Probe code changed. This ZIP
is intentionally experiment-only, not an application update. Repackage uses an
explicit allowlist and excludes virtual environments, installed packages,
caches, logs and local generated results.
