"""Minimal standalone source archive: experiment, direct dependencies, tests."""
import argparse
from pathlib import Path
import zipfile
from .common import HERE, ROOT

TOOLS = ("analyze_generation_baseline.py", "record_generation_measurement.py",
         "analyze_seed_room_correlation.py", "analyze_dungeon_generation_table.py",
         "analyze_nms_seed_function.py", "extract_nms_caller_code.py",
         "extract_nms_upstream_callers.py")
MODULES = ("__init__.py", "common.py", "build_corpus.py", "prototype.py", "public_seed.py",
           "rng_kernel.py", "code_evidence.py", "export_evidence.py", "unicorn_check.py",
           "native_check.py", "audit.py", "run.py", "start.py", "package_experiment.py", "install_unicorn.py",
           "local_runner.py", "runner_protocol.py", "windows_job.py", "github_exchange.py",
           "gui_process.py", "runner_gui.py", "install_runner.py")
REPORTS = ("README.md", "AI_HANDOFF.md", "STATUS.json", "CODE_REVIEW_20261011_v0.1.3.json",
           "verification.json", "unicorn-verification.json", "requirements-unicorn.txt",
           "Install-Unicorn.cmd", "Test-Unicorn.cmd", "Export-Offline-Evidence.cmd",
           "Start-Runner.cmd", "Setup-GitHub.cmd", "RUNNER.md", "LOCAL_WORK_PROMPT.md",
           "GITHUB_CHECK_PROMPT.md", "Start-Runner-CLI.cmd", "Install-Runner.cmd")
EVIDENCE = ("offline-code-evidence-20261011.json", "offline-code-evidence-20261011-v0.1.1.json",
            "offline-code-evidence-20261011-v0.1.2.json",
            "root-journal-analysis.json", "generation-measurements-summary.json",
            "dungeon-seed-function-analysis-latest.json")


def members():
    result = {name: HERE / name for name in (*MODULES, *REPORTS)}
    for name in EVIDENCE:
        result["evidence/" + name] = HERE / "evidence" / name
    for path in (HERE / "fixtures").glob("*.json"):
        result["fixtures/" + path.name] = path
    standalone = (HERE / "tools").is_dir()
    for name in TOOLS:
        result["tools/" + name] = (HERE / "tools" if standalone else ROOT / "tools") / name
    tests = HERE / "tests" if standalone else ROOT / "tests"
    for path in tests.glob("test_derelict_offline*.py"):
        result["tests/" + path.name] = path
    return result, standalone


def package(destination):
    files, standalone = members()
    destination = Path(destination).resolve()
    if destination in (path.resolve() for path in files.values()):
        raise ValueError("Output cannot overwrite a source member")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(files.items()):
            raw = path.read_bytes()
            if name.endswith(".cmd"):
                # CMD label/goto parsing is sensitive to Unix line endings.
                raw = raw.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
            if name.startswith("tests/") and not standalone:
                raw = raw.replace(b"experiments.derelict_offline", b"derelict_offline")
                # The child process uses the standalone launcher, independent
                # of folder name and without needing parent import paths.
                raw = raw.replace(b'[sys.executable, "-m", "derelict_offline.native_check"]',
                                  b'[sys.executable, "start.py", "native"]')
            archive.writestr("derelict_offline/" + name, raw)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() or len(archive.namelist()) != len(files):
            raise ValueError("Standalone ZIP verification failed")
    return {"archive": destination.name, "members": len(files), "bytes": destination.stat().st_size,
            "expanded_bytes": sum(p.stat().st_size for p in files.values())}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    print(package(parser.parse_args(argv).out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
