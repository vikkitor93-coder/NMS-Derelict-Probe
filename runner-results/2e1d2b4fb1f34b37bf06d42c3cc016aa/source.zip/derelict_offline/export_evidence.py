"""Read-only bounded byte export for offline analysis. Does not launch NMS.

Capture window matches establish local byte compatibility, not retrospective
proof that a session used this whole executable. Never rewrites corpus pins.
"""
from __future__ import annotations
import argparse
import json
import os
import shutil
import struct
import tempfile
import zipfile
from pathlib import Path
from tools import analyze_nms_seed_function as pe
from tools import extract_nms_caller_code as caller
from . import VERSION
from .build_corpus import build
from .common import HERE, sha256

KNOWN_BINARY = "13d5060d4efb9d2a6a6b1b349bc4257231056cc2a055df4bb15d816262cc3499"
MAX_BODY = 65536
MAX_BYTES = 1048576
# Reviewed decoded calls in the returned 2026-10-11 same-hash export:
# descriptor copy/identifier helpers, selection helper and table initializer.
# No historical RVA is applied to an executable with a different full hash.
PINNED_HELPERS = (0x00639BE0, 0x00639610, 0x00227A40, 0x00227620,
                  0x0062E9E0, 0x02D6F410, 0x00641160, 0x00640EA0,
                  0x00630310, 0x00639490, 0x00639A70, 0x02C20E90)

# The two decoded setup wrappers forward an incoming descriptor into argument
# five of 00639BE0. Their callers are the next root-source boundary. The handoff
# also identifies two seed-building functions whose parent callsites are still
# missing. Export bounded caller candidates for those exact-hash targets too.
# Raw E8 matches remain unverified instruction candidates, not confirmed calls.
UPSTREAM_TARGETS = {0x00639490: 8, 0x00639A70: 8, 0x00639BE0: 16,
                    0x02D07C80: 8, 0x02D08430: 8}

def window_matches(exe, sections, event):
    window = event.get("caller_code_window") or {}
    raw = bytes.fromhex(str(window.get("bytes_hex") or ""))
    if not raw:
        return False
    start = int(window["start_offset_hex"], 16)
    try:
        actual = pe._read_rva(exe, sections, start, len(raw))
    except ValueError:
        return False
    return actual == raw

def pdata_records(exe, sections):
    section = next((s for s in sections if s["name"] == ".pdata"), None)
    if section is None:
        raise ValueError("Executable has no .pdata")
    raw = pe._read_section(exe, section)
    records = [struct.unpack_from("<III", raw, offset) for offset in range(0, len(raw) - 11, 12)]
    return [record for record in records if 0 < record[0] < record[1] and record[2]]

def chain_parent(exe, sections, record):
    raw = pe._read_rva(exe, sections, record[2], 4)
    if len(raw) != 4:
        raise ValueError("Truncated unwind header")
    flags, count = raw[0] >> 3, raw[2]
    if not flags & 4:
        return None
    offset = record[2] + 4 + ((count * 2 + 3) & ~3)
    raw = pe._read_rva(exe, sections, offset, 12)
    if len(raw) != 12:
        raise ValueError("Truncated chained unwind record")
    return struct.unpack("<III", raw)

def connected_ranges(exe, sections, records, root, parents=None):
    # Undirected chain closure includes primary ranges and attached funclets.
    if parents is None:
        parents = {record: chain_parent(exe, sections, record) for record in records}
    selected = {root}
    for _ in range(len(records) + 1):
        expanded = set(selected)
        for record, parent in parents.items():
            if record in selected and parent:
                expanded.add(parent)
            if parent in selected:
                expanded.add(record)
        if expanded == selected:
            return sorted(selected)
        selected = expanded
    raise ValueError("Unwind chain did not converge")

def collect(exe, corpus):
    exe = Path(exe)
    timestamp, base, sections = pe._parse_pe(exe)
    binary_hash = sha256(exe)
    checks, compatible = [], []
    for case in corpus["cases"]:
        for event in case["root_events"]:
            matches = window_matches(exe, sections, event)
            checks.append({"case_id": case["case_id"], "window_matches": matches,
                           "capture_utc": event.get("utc")})
            if matches:
                compatible.append(event)
    if not compatible:
        raise ValueError("No bundled root-call window matches this executable. No historical RVA export attempted.")
    records = pdata_records(exe, sections)
    parents = {record: chain_parent(exe, sections, record) for record in records}
    selected = set()
    for event in compatible:
        call = int(event["caller_return_offset_hex"], 16) - 5
        if pe._read_rva(exe, sections, call, 1) != b"\xe8":
            raise ValueError("Matched capture does not identify a rel32 root call")
        record = next((r for r in records if r[0] <= call < r[1]), None)
        if record is None:
            raise ValueError("Matched root call has no runtime-function record")
        selected.update(connected_ranges(exe, sections, records, record, parents))
    requested_helpers = []
    if binary_hash == KNOWN_BINARY:
        # Already supported by same-binary caller evidence; never apply these
        # fixed addresses to a different hash.
        for address in PINNED_HELPERS:
            helper = next((r for r in records if r[0] <= address < r[1]), None)
            if helper:
                selected.update(connected_ranges(exe, sections, records, helper, parents))
                requested_helpers.append(f"{address:08X}")
    upstream_candidates = []
    if binary_hash == KNOWN_BINARY:
        # Scan read-only text for direct rel32 candidates entering owner setup.
        # Raw E8 matches can be embedded bytes: preserve uncertainty for review.
        text_section = next((s for s in sections if s["name"] == ".text"), None)
        if text_section:
            text_bytes = pe._read_section(exe, text_section)
            section_start = int(text_section["virtual_address"])
            cursor = 0
            counts = {target: 0 for target in UPSTREAM_TARGETS}
            while len(upstream_candidates) < sum(UPSTREAM_TARGETS.values()):
                offset = text_bytes.find(b"\xe8", cursor)
                if offset < 0 or offset + 5 > len(text_bytes):
                    break
                cursor = offset + 1
                source = section_start + offset
                target = source + 5 + int.from_bytes(text_bytes[offset + 1:offset + 5], "little", signed=True)
                if target not in UPSTREAM_TARGETS or counts[target] >= UPSTREAM_TARGETS[target]:
                    continue
                record = next((r for r in records if r[0] <= source < r[1]), None)
                if record:
                    selected.update(connected_ranges(exe, sections, records, record, parents))
                    counts[target] += 1
                    upstream_candidates.append({"source_rva_hex": f"{source:08X}", "target_rva_hex": f"{target:08X}",
                                                "instruction_boundary_verified": False})
            del text_bytes
    bodies, errors, budget = [], [], 0
    exported_starts = set()
    def add_body(record, reason):
        nonlocal budget
        start, end, unwind = record
        if start in exported_starts:
            return
        size = end - start
        if size <= 0 or size > MAX_BODY or budget + size > MAX_BYTES:
            errors.append({"start_rva_hex": f"{start:08X}", "reason": "size-budget"})
            return
        raw = pe._read_rva(exe, sections, start, size)
        if len(raw) != size:
            raise ValueError("Incomplete function bytes")
        budget += size
        exported_starts.add(start)
        import hashlib
        bodies.append({"start_rva_hex": f"{start:08X}", "end_rva_exclusive_hex": f"{end:08X}",
                       "unwind_info_rva_hex": f"{unwind:08X}", "reason": reason,
                       "sha256": hashlib.sha256(raw).hexdigest(), "bytes_hex": raw.hex().upper()})
    for record in sorted(selected):
        add_body(record, "matched-root-unwind-chain-or-hash-pinned-helper")
    # Bounded one-level dependency candidates. E8 scans may hit data/immediates;
    # do not describe these as decoded calls or execute them automatically.
    seed_bodies = list(bodies)
    known_starts = {int(body["start_rva_hex"], 16) for body in bodies}
    candidates = []
    for body in seed_bodies:
        raw = bytes.fromhex(body["bytes_hex"])
        for offset in range(max(0, len(raw) - 4)):
            if raw[offset] != 0xE8:
                continue
            source = int(body["start_rva_hex"], 16) + offset
            target = source + 5 + int.from_bytes(raw[offset + 1:offset + 5], "little", signed=True)
            candidate = next((r for r in records if r[0] <= target < r[1]), None)
            if candidate and candidate[0] not in known_starts and len(candidates) < 32:
                known_starts.add(candidate[0])
                candidates.append({"source_rva_hex": f"{source:08X}", "target_rva_hex": f"{target:08X}",
                                   "instruction_boundary_verified": False})
                # A .pdata record is often only a fragment. Export its entire
                # unwind-connected closure, respecting the same global budget.
                for fragment in connected_ranges(exe, sections, records, candidate, parents):
                    known_starts.add(fragment[0])
                    add_body(fragment, "heuristic-E8-dependency-unwind-chain")
    return {"schema_version": 1, "prototype_version": VERSION,
            "binary": {"file_name": exe.name, "sha256": binary_hash,
                       "size_bytes": exe.stat().st_size, "pe_timestamp_hex": f"{timestamp:08X}",
                       "preferred_image_base_hex": f"{base:016X}"},
            "identity_scope": "Executable inspected during export; matching snippets do not retrospectively pin capture identity.",
            "window_checks": checks, "known_binary_helpers": requested_helpers,
            "upstream_candidates": upstream_candidates,
            "function_ranges": bodies, "dependency_candidates": candidates,
            "byte_count": budget, "errors": errors,
            "emulation_ready": False,
            "limits": ["Raw export only", "No data/heap/RNG state reconstructed",
                       "No game launch or process attachment", "No root formula asserted"]}

def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--exe", type=Path)
    parser.add_argument("--out", type=Path, default=HERE / "offline-evidence.zip")
    args = parser.parse_args(argv)
    temporary = None
    try:
        exe = caller.find_nms_exe(str(args.exe) if args.exe else None)
        if args.out.resolve() == Path(exe).resolve():
            raise ValueError("Output cannot overwrite NMS.exe")
        result = collect(exe, build())
        args.out.parent.mkdir(parents=True, exist_ok=True)
        # Keep an earlier successful export intact if writing runs out of space.
        with tempfile.NamedTemporaryFile(dir=args.out.parent, prefix="offline-evidence-", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("offline-code-evidence.json", json.dumps(result, indent=2) + "\n")
        os.replace(temporary, args.out)
        print(f"Created {args.out.name}; binary {result['binary']['sha256']}; bytes {result['byte_count']}; errors {len(result['errors'])}")
        return 0 if not result["errors"] else 1
    except (ValueError, OSError, KeyError, struct.error) as error:
        print(f"Export error: {error}")
        if isinstance(error, OSError) and error.errno == 28:
            try:
                print(f"Evidence destination: {args.out.resolve()}; free space: {shutil.disk_usage(args.out.parent).free / 1048576:.1f} MiB")
                print("Only bounded code evidence is written; NMS.exe is not copied. Try another output drive using --out.")
            except OSError:
                pass
        return 2
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)

if __name__ == "__main__":
    raise SystemExit(main())
