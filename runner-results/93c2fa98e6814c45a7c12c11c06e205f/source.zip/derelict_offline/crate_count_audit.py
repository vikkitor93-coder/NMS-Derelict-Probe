"""Audit saved derelict crate totals without launching the game."""
from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path

from .common import HERE


def _count(value):
    return value if type(value) is int and value >= 0 else None


def analyze(summary):
    rows = summary.get("measurements") if isinstance(summary, dict) else None
    if not isinstance(rows, list):
        raise ValueError("crate-measurements-invalid")

    checks = []
    by_identity = defaultdict(list)
    for row in rows:
        if not isinstance(row, dict):
            continue
        rooms = row.get("room_sequence")
        if not isinstance(rooms, list):
            continue
        salvage_parts = [_count(room.get("salvage")) for room in rooms if isinstance(room, dict)]
        locker_parts = [_count(room.get("footlockers")) for room in rooms if isinstance(room, dict)]
        target_parts = [_count(room.get("targets")) for room in rooms if isinstance(room, dict)]
        if any(value is None for value in salvage_parts + locker_parts + target_parts):
            continue
        salvage = sum(salvage_parts)
        lockers = sum(locker_parts)
        targets = sum(target_parts)
        recorded_salvage = _count(row.get("salvage_crates"))
        recorded_lockers = _count(row.get("crew_footlockers"))
        recorded_targets = _count(row.get("target_containers"))
        valid_totals = None not in (recorded_salvage, recorded_lockers, recorded_targets)
        check = {
            "session_id": row.get("session_id"),
            "probe_version": row.get("probe_version"),
            "universe_address_hex": row.get("universe_address_hex"),
            "preset": row.get("preset"),
            "root_candidates_hex": row.get("dungeon_root_seed_hexes", []),
            "room_count": len(rooms),
            "room_sum": salvage + lockers,
            "recorded_total": recorded_targets,
            "salvage_sum": salvage,
            "recorded_salvage": recorded_salvage,
            "footlocker_sum": lockers,
            "recorded_footlockers": recorded_lockers,
            "target_sum": targets,
            "recorded_target_sum": recorded_targets,
            "matches_recorded_totals": bool(valid_totals and
                salvage == recorded_salvage and lockers == recorded_lockers and
                salvage + lockers == recorded_targets and targets == recorded_targets),
        }
        checks.append(check)
        address = row.get("universe_address_hex")
        roots = row.get("dungeon_root_seed_hexes") or []
        preset = row.get("preset")
        if address and preset:
            for root in roots or [None]:
                by_identity[(address, root)].append((preset, recorded_targets, row.get("session_id")))

    cross_preset = []
    for (address, root), samples in sorted(by_identity.items(), key=lambda item: str(item[0])):
        distinct = {}
        for preset, total, session in samples:
            if total is not None:
                distinct.setdefault(preset, set()).add(total)
        if len(distinct) > 1:
            cross_preset.append({"universe_address_hex": address, "root_candidate_hex": root,
                "preset_totals": {preset: sorted(totals) for preset, totals in sorted(distinct.items())},
                "sessions": [session for _, _, session in samples]})

    matched = sum(check["matches_recorded_totals"] for check in checks)
    return {
        "schema_version": 1,
        "input": "evidence/generation-measurements-summary.json",
        "input_version": summary.get("version"),
        "measurement_rows": len(rows),
        "rows_with_recomputable_room_counts": len(checks),
        "rows_matching_recorded_totals": matched,
        "rows_with_mismatched_or_missing_totals": len(checks) - matched,
        "executable_hash_provenance_present": any(
            isinstance(row, dict) and row.get("executable_sha256") for row in rows),
        "capture_version_scope": "probe version is recorded per row; game executable hash is absent",
        "same_address_and_recorded_root_different_preset_totals": cross_preset,
        "samples": checks,
        "interpretation": (
            "Checks only arithmetic agreement between saved per-room counts and saved aggregate fields. "
            "It does not verify live-game object completeness or predict counts from system inputs."
        ),
    }


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    source = HERE / "evidence/generation-measurements-summary.json"
    result = analyze(json.loads(source.read_text(encoding="utf-8")))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("Crate-count evidence audit: {}/{} room-count rows agree".format(
        result["rows_matching_recorded_totals"], result["rows_with_recomputable_room_counts"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
