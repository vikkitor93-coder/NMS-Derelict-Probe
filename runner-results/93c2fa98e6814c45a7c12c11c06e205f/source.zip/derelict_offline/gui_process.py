"""UI-independent process ownership; bounded console messages stay in memory."""
import os
from pathlib import Path
import queue
import signal
import subprocess
import sys
import threading
import time


def worker_python():
    path = Path(sys.executable)
    if path.name.lower() == "pythonw.exe":
        path = path.with_name("python.exe")
    return str(path)


class WorkerProcess:
    def __init__(self, root):
        self.root = root
        self.process = None
        self.job = None
        self.messages = queue.Queue(maxsize=500)
        self.stopping_since = None
        self.started = None
        self.reader_done = threading.Event()

    @property
    def active(self):
        return self.process is not None and self.process.poll() is None

    def start(self, args):
        if self.active:
            raise ValueError("worker-already-running")
        self.finish()
        while not self.messages.empty():
            self.messages.get_nowait()
        self.reader_done.clear()
        env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")
        flags = (subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NEW_CONSOLE) if os.name == "nt" else 0
        # A hidden console supports cooperative CTRL_BREAK cancellation on Windows.
        info = None
        if os.name == "nt":
            info = subprocess.STARTUPINFO()
            info.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            info.wShowWindow = 0
        self.process = subprocess.Popen([worker_python(), "-u", str(self.root / "start.py"), *args],
                cwd=self.root, stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                env=env, creationflags=flags, startupinfo=info, start_new_session=os.name != "nt")
        try:
            if os.name == "nt":
                from .windows_job import OwnedJob
                self.job = OwnedJob(self.process)
        except OSError:
            self.process.kill()
            self.process.wait()
            self.process.stdout.close()
            raise
        self.started = time.monotonic()
        self.stopping_since = None
        threading.Thread(target=self._read, args=(self.process,), daemon=True).start()

    def _read(self, process):
        try:
            for raw in iter(process.stdout.readline, b""):
                message = raw[:8192].decode("utf-8", errors="replace").rstrip()
                try:
                    self.messages.put_nowait(message)
                except queue.Full:
                    try:
                        self.messages.get_nowait()
                    except queue.Empty:
                        pass
                    self.messages.put_nowait(message)
        finally:
            process.stdout.close()
            self.reader_done.set()

    def stop(self):
        if not self.active or self.stopping_since is not None:
            return
        self.stopping_since = time.monotonic()
        try:
            if os.name == "nt":
                # The pythonw GUI has no console: briefly attach to the child's
                # console, ignore the event ourselves, and signal its process group.
                import ctypes
                kernel = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel.FreeConsole()
                attached = kernel.AttachConsole(self.process.pid)
                if attached:
                    kernel.SetConsoleCtrlHandler(None, True)
                    try:
                        kernel.GenerateConsoleCtrlEvent(1, self.process.pid)
                    finally:
                        kernel.FreeConsole()
                else:
                    # Job cleanup below is the bounded fallback.
                    self.stopping_since -= 5
            else:
                os.killpg(self.process.pid, signal.SIGINT)
        except OSError:
            self.stopping_since -= 5

    def tick(self):
        if self.active and self.stopping_since is not None and time.monotonic() - self.stopping_since >= 5:
            if self.job:
                self.job.close()
                self.job = None
            else:
                self.process.kill()

    def finish(self):
        if self.active:
            return None
        code = self.process.returncode if self.process else None
        if self.job:
            self.job.close()
            self.job = None
        return code
