import copy
import errno
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from derelict_offline.build_corpus import build
from derelict_offline.code_evidence import EVIDENCE, slice_bytes, verify
from derelict_offline.common import read_json, sha256
from derelict_offline.export_evidence import collect, main as export_main
from derelict_offline.native_check import supported
from derelict_offline.rng_kernel import seed_state, advance_output, diagnose
from derelict_offline.run import main


class CodeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.evidence, cls.corpus = read_json(EVIDENCE), build()

    def test_returned_ranges_and_recomputed_capture_windows(self):
        result = verify(self.evidence, self.corpus)
        self.assertEqual(38, result["range_count"])
        self.assertEqual(14037, result["verified_code_bytes"])
        self.assertTrue(all(w["recomputed_window_matches"] for w in result["window_checks"]))
        self.assertEqual(4, len(result["window_checks"]))
        self.assertFalse(result["whole_executable_hash_independently_verified"])
        self.assertFalse(result["root_generation_verified"])

    def test_tampered_range_rejected(self):
        evidence = copy.deepcopy(self.evidence)
        evidence["function_ranges"][0]["bytes_hex"] = "90" + evidence["function_ranges"][0]["bytes_hex"][2:]
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            verify(evidence, self.corpus)

    def test_duplicate_range_rejected(self):
        evidence = copy.deepcopy(self.evidence)
        evidence["function_ranges"].append(copy.deepcopy(evidence["function_ranges"][0]))
        with self.assertRaisesRegex(ValueError, "overlapping"):
            verify(evidence, self.corpus)

    def test_fragment_spanning_read_and_missing_dependency(self):
        self.assertEqual(0x10, len(slice_bytes(self.evidence, 0x63B048, 0x63B058)))
        with self.assertRaisesRegex(ValueError, "Missing code range"):
            slice_bytes(self.evidence, 0x227A40, 0x227A50)

    def test_initial_state_flag_zero_and_widths(self):
        self.assertEqual((1, 0), seed_state(0, True))
        self.assertEqual((1, 0), seed_state(0xFFFFFFFFFFFFFFFF, False))
        self.assertEqual((1, 1), seed_state(1 << 32, True))
        self.assertEqual((0xFFFFFFFF, 0xFFFFFFFF), seed_state(0xFFFFFFFFFFFFFFFF, True))
        with self.assertRaises(ValueError):
            seed_state(1, None)
        for state in ((-1, 0), (1 << 32, 0), (True, 0)):
            with self.assertRaises(ValueError):
                advance_output(state)

    def test_arithmetic_never_claims_new_root_or_layout(self):
        result = diagnose("9C2818C7FE094FC8")
        self.assertFalse(result["derelict_root_derived"])
        self.assertFalse(result["layout_generated"])
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "report.json"
            with patch("builtins.print"):
                self.assertEqual(0, main(["rng", "--seed", "9C2818C7FE094FC8", "--out", str(path)]))
            self.assertFalse(read_json(path)["result"]["layout_generated"])

    @unittest.skipUnless(supported(), "Exact native instruction check requires Linux x86-64")
    def test_exact_exported_instruction_blocks_in_child_process(self):
        root = Path(__file__).resolve().parents[1]
        result = subprocess.run([sys.executable, "start.py", "native"],
                                cwd=root, capture_output=True, text=True, timeout=30)
        self.assertEqual(0, result.returncode, result.stderr)
        report = json.loads(result.stdout)
        self.assertEqual(0, report["mismatches"])
        self.assertGreaterEqual(report["initialization_comparisons"], 10000)
        self.assertGreaterEqual(report["state_output_comparisons"], 10000)

    def test_failed_write_preserves_previous_export_and_cleans_partial_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "offline-evidence.zip"
            out.write_bytes(b"previous-good-export")
            with patch("derelict_offline.export_evidence.caller.find_nms_exe", return_value=Path(tmp) / "NMS.exe"), \
                 patch("derelict_offline.export_evidence.collect", return_value=self.evidence), \
                 patch("zipfile.ZipFile.writestr", side_effect=OSError(errno.ENOSPC, "No space left on device")), \
                 patch("builtins.print"):
                self.assertEqual(2, export_main(["--out", str(out)]))
            self.assertEqual(b"previous-good-export", out.read_bytes())
            self.assertEqual([], list(Path(tmp).glob("*.tmp")))

    def test_game_executable_cannot_be_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            exe = Path(tmp) / "NMS.exe"
            exe.write_bytes(b"untouched-game-file")
            with patch("derelict_offline.export_evidence.caller.find_nms_exe", return_value=exe), \
                 patch("builtins.print"):
                self.assertEqual(2, export_main(["--out", str(exe)]))
            self.assertEqual(b"untouched-game-file", exe.read_bytes())

    def test_dependency_export_includes_connected_fragments(self):
        root, first, chained = (0x1000, 0x1006, 0x3000), (0x2000, 0x2004, 0x3010), (0x2004, 0x200A, 0x3020)
        parents = {root: None, first: None, chained: first}
        import struct
        raw = b"\xe8" + struct.pack("<i", 0x2000 - 0x1005) + b"\xc3"
        def read_rva(exe, sections, start, size):
            if start == 0x1000:
                return raw[:size]
            return b"\x90" * size
        with tempfile.TemporaryDirectory() as tmp:
            exe = Path(tmp) / "NMS.exe"
            exe.write_bytes(b"test")
            corpus = {"cases": [{"case_id": "test", "root_events": [{"caller_return_offset_hex": "00001005"}]}]}
            module = "derelict_offline.export_evidence"
            with patch(module + ".pe._parse_pe", return_value=(0, 0x140000000, [])), \
                 patch(module + ".window_matches", return_value=True), \
                 patch(module + ".pdata_records", return_value=[root, first, chained]), \
                 patch(module + ".chain_parent", side_effect=lambda exe, sections, record: parents[record]), \
                 patch(module + ".pe._read_rva", side_effect=read_rva):
                result = collect(exe, corpus)
            self.assertEqual(["00001000", "00002000", "00002004"], [b["start_rva_hex"] for b in result["function_ranges"]])
            self.assertEqual(16, result["byte_count"])
            self.assertEqual([], result["known_binary_helpers"])

    def test_hash_pinned_export_collects_seed_builder_callers(self):
        import struct
        root, caller_range = (0x1000, 0x1006, 0x3000), (0x5000, 0x5020, 0x3010)
        parents = {root: None, caller_range: None}
        targets = (0x02D07C80, 0x02D08430)
        text = bytearray(b"\x90" * 0x20)
        for offset, target, opcode in ((0, targets[0], 0xE8), (0x10, targets[1], 0xE9)):
            source = 0x5000 + offset
            text[offset] = opcode
            struct.pack_into("<i", text, offset + 1, target - (source + 5))
            text[offset + 5] = 0xC3
        with tempfile.TemporaryDirectory() as tmp:
            exe = Path(tmp) / "NMS.exe"
            exe.write_bytes(b"synthetic exact-hash executable")
            root_body = b"\xE8" + struct.pack("<i", 0x5000 - 0x1005) + b"\xC3"
            caller_body = bytes(text)
            def read_rva(_exe, _sections, start, size):
                data = {0x1000: root_body, 0x5000: caller_body}.get(start, b"")
                return data[:size]
            corpus = {"cases": [{"case_id": "test", "root_events": [
                {"caller_return_offset_hex": "00001005"}]}]}
            module = "derelict_offline.export_evidence"
            with patch(module + ".KNOWN_BINARY", sha256(exe)), \
                 patch(module + ".pe._parse_pe", return_value=(0, 0x140000000, [
                     {"name": ".text", "virtual_address": 0x5000}])), \
                 patch(module + ".window_matches", return_value=True), \
                 patch(module + ".pdata_records", return_value=[root, caller_range]), \
                 patch(module + ".chain_parent", side_effect=lambda _exe, _sections, record: parents[record]), \
                 patch(module + ".pe._read_section", return_value=bytes(text)), \
                 patch(module + ".pe._read_rva", side_effect=read_rva):
                result = collect(exe, corpus)
        self.assertEqual({"02D07C80", "02D08430"},
                         {item["target_rva_hex"] for item in result["upstream_candidates"]})
        self.assertEqual({"call", "tail-jump"},
                         {item["branch_kind"] for item in result["upstream_candidates"]})
        self.assertTrue(all(not item["instruction_boundary_verified"]
                            for item in result["upstream_candidates"]))
        self.assertIn("00005000", {item["start_rva_hex"] for item in result["function_ranges"]})


if __name__ == "__main__":
    unittest.main()
