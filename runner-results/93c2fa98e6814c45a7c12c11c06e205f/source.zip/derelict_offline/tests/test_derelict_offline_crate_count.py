import json
from pathlib import Path
import tempfile
import unittest

from derelict_offline.crate_count_audit import analyze


class CrateCountAuditTests(unittest.TestCase):
    def test_recomputes_totals_and_flags_same_root_cross_preset_difference(self):
        room = {"salvage": 3, "footlockers": 2, "targets": 5}
        rows = [
            {"session_id": "a", "probe_version": "x", "universe_address_hex": "AA",
             "preset": "CARGO", "dungeon_root_seed_hexes": ["11"], "salvage_crates": 3,
             "crew_footlockers": 2, "target_containers": 5, "room_sequence": [room]},
            {"session_id": "b", "probe_version": "x", "universe_address_hex": "AA",
             "preset": "MEDI", "dungeon_root_seed_hexes": ["11"], "salvage_crates": 4,
             "crew_footlockers": 1, "target_containers": 5,
             "room_sequence": [{"salvage": 4, "footlockers": 1, "targets": 5}]},
        ]
        result = analyze({"version": "fixture", "measurements": rows})
        self.assertEqual(2, result["rows_matching_recorded_totals"])
        self.assertEqual(1, len(result["same_address_and_recorded_root_different_preset_totals"]))
        self.assertEqual({"CARGO": [5], "MEDI": [5]},
                         result["same_address_and_recorded_root_different_preset_totals"][0]["preset_totals"])
        self.assertFalse(result["executable_hash_provenance_present"])

    def test_mismatch_is_reported_and_missing_or_invalid_counts_are_not_used(self):
        result = analyze({"measurements": [{"session_id": "x", "room_sequence": [
            {"salvage": 1, "footlockers": 0, "targets": 1}], "salvage_crates": 2,
            "crew_footlockers": 0, "target_containers": 2}]})
        self.assertEqual(0, result["rows_matching_recorded_totals"])
        self.assertEqual(1, result["rows_with_mismatched_or_missing_totals"])


if __name__ == "__main__":
    unittest.main()
