@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "NMS_RUNNER_HOME=%USERPROFILE%\Documents\NMS Runner"
if /I "%~dp0"=="%NMS_RUNNER_HOME%\" goto permanent_folder
call "%~dp0Install-Runner.cmd" --quiet-exit
if errorlevel 1 goto permanent_failed
call "%NMS_RUNNER_HOME%\Start-Runner.cmd" %*
exit /b %ERRORLEVEL%
:permanent_failed
echo Installation could not finish. Stop the old runner, close its window, then retry.
pause
exit /b 2
:permanent_folder
title NMS Offline runner 0.1.19
pushd "%~dp0"
if errorlevel 1 goto folder_failed
if not "%~1"=="" goto console
 echo Opening NMS Offline runner 0.1.19...
if exist ".unicorn-venv\Scripts\pythonw.exe" goto gui_private
where pyw.exe >nul 2>&1
if not errorlevel 1 goto gui_py
where pythonw.exe >nul 2>&1
if not errorlevel 1 goto gui_python
 echo Python with Tcl/Tk is needed for the window. Starting console mode instead.
goto console
:gui_private
call ".unicorn-venv\Scripts\python.exe" -c "import tkinter"
if errorlevel 1 goto console
start "" ".unicorn-venv\Scripts\pythonw.exe" start.py gui
popd
exit /b 0
:gui_py
call py.exe -3 -c "import tkinter"
if errorlevel 1 goto console
start "" pyw.exe -3 start.py gui
popd
exit /b 0
:gui_python
call python.exe -c "import tkinter"
if errorlevel 1 goto console
start "" pythonw.exe start.py gui
popd
exit /b 0
:console
 echo Starting NMS Offline console runner 0.1.19...
 echo Leave this window open. Ctrl+C stops the runner.
:restart_runner
if exist ".unicorn-venv\Scripts\python.exe" goto use_venv
where py.exe >nul 2>&1
if errorlevel 1 goto try_python
call py.exe -3 -u start.py runner %*
set "RC=%ERRORLEVEL%"
if "%RC%"=="75" goto wait_for_update
goto finished
:use_venv
call ".unicorn-venv\Scripts\python.exe" -u start.py runner %*
set "RC=%ERRORLEVEL%"
if "%RC%"=="75" goto wait_for_update
goto finished
:try_python
where python.exe >nul 2>&1
if errorlevel 1 goto no_python
call python.exe -u start.py runner %*
set "RC=%ERRORLEVEL%"
if "%RC%"=="75" goto wait_for_update
goto finished
:no_python
 echo Python 3.10 or newer is required. Install Python, then try again.
set "RC=2"
goto finished
:wait_for_update
set /a UPDATE_WAIT=0
set /a UPDATE_LOG_TICK=0
 echo [update] Verified package handed to installer. Waiting for restart confirmation...
:wait_for_update_check
findstr /C:"applied" ".local\update-state.json" >nul 2>&1
if not errorlevel 1 goto restart_runner
findstr /C:"failed" ".local\update-state.json" >nul 2>&1
if not errorlevel 1 goto update_wait_failed
set /a UPDATE_WAIT+=1
set /a UPDATE_LOG_TICK+=1
if "%UPDATE_LOG_TICK%"=="10" echo [update] Still waiting for installer confirmation. Elapsed: %UPDATE_WAIT% seconds.
if "%UPDATE_LOG_TICK%"=="10" set /a UPDATE_LOG_TICK=0
if "%UPDATE_WAIT%"=="120" goto update_wait_timeout
timeout /t 1 /nobreak >nul
goto wait_for_update_check
:update_wait_failed
 echo [update] Installer reported failure after %UPDATE_WAIT% seconds. Check .local\update-state.json.
set "RC=75"
goto finished
:update_wait_timeout
 echo [update] No restart confirmation after %UPDATE_WAIT% seconds. Check .local\update-state.json; logs are retained.
set "RC=75"
goto finished
:finished
popd
 echo Runner finished with code %RC%.
pause
exit /b %RC%
:folder_failed
 echo Extract the entire ZIP before starting the runner.
pause
exit /b 2
