"""Read-only derelict research. Never imported by Surveyor."""
VERSION = "0.1.12"
SCHEMA_VERSION = 1
