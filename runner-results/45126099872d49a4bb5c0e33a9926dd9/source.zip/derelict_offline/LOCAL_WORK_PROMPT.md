# Local AI handoff for the offline research loop

Use this experiment folder, AI_HANDOFF.md and the latest complete source ZIP.
Read `.local/status.json` and `.local/latest-result.json`; process each new
completed request_id exactly once. The runner must already be started on this
PC; it is not a cloud execution service.

Read only the failed stage/result evidence first. Respect stale/failed/cancelled
statuses and the source_sha256. Do not infer generation from arithmetic tests.
No address-to-root or root-to-layout generator has been established. Prefer
tracing root producer callers over additional palette/allocator experiments.

Complete narrow research edits, add meaningful checks, update AI_HANDOFF.md.
Then run `python start.py runner --request offline-check` once. Do not publish
multiple requests, arbitrary commands or reuse request IDs. The runner watches
stable source edits too; requests are useful to establish a finished editing
boundary or explicitly retest. Never edit production Surveyor/Unspottable.

Request `offline-check-and-export` only after a targeted exporter update when
the required missing bytes are identified. The runner must have been started
with --exe for export jobs. Do not request unchanged exports expecting new
evidence. Exports remain bounded and read-only. No game launch is required.

Continue after every new completed result until a specific unavailable capture,
function input, byte range or supported PC operation is actually needed. Stop
and give numbered human steps only for that concrete blocker. Unknown globals,
imports and inputs must fail, not be silently invented. Preserve version/hash
quarantine. Report measured results separately from inference/hypothesis.

No outbound message, scheduled task, API key or automatic upload is configured.
Use an already authorized local Work/Codex session with this folder's access.
This prompt is instructions, not a claim that the AI connection is active.
