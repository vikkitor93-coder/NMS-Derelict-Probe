"""Permanent install safety, state preservation, retries and launcher defaults."""
import contextlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile
from derelict_offline import install_runner as installer
from derelict_offline.common import HERE
from derelict_offline.local_runner import instance_lock


class PermanentFolderTests(unittest.TestCase):
    def fixture(self, parent):
        source, target = parent / "download", parent / "permanent"
        source.mkdir()
        (source / "__init__.py").write_text('VERSION = "0.1.7"\n')
        (source / "start.py").write_text('print("new")\n')
        self.files = {name: source / name for name in ("__init__.py", "start.py")}
        return source, target

    def invoke(self, source, target, **kwargs):
        with patch.object(installer, "source_files", return_value=self.files), patch.object(installer, "migrate_unicorn"):
            return installer.install(source, target, **kwargs)

    def test_default_is_documents_nms_runner(self):
        with patch.object(Path, "home", return_value=Path("profile")):
            self.assertEqual(Path("profile/Documents/NMS Runner"), installer.default_folder())

    def test_migration_preserves_both_originals_and_permanent_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = self.fixture(Path(tmp))
            for root, value in ((source, "old-folder"), (target, "permanent")):
                (root / ".local").mkdir(parents=True)
                (root / ".local/github-config.json").write_text(value)
                (root / "reports/same-id").mkdir(parents=True)
                (root / "reports/same-id/result.json").write_text(value)
            (target / "__init__.py").write_text('VERSION = "0.1.6"\n')
            (source / ".local/receipt.json").write_text("saved")
            (source / "reports/unique-id").mkdir()
            (source / "reports/unique-id/result.json").write_text("retained")
            result = self.invoke(source, target)
            self.assertEqual("installed", result["status"])
            self.assertEqual("permanent", (target / ".local/github-config.json").read_text())
            self.assertEqual("permanent", (target / "reports/same-id/result.json").read_text())
            self.assertEqual("retained", (target / "reports/unique-id/result.json").read_text())
            self.assertEqual("saved", (target / ".local/receipt.json").read_text())
            self.assertEqual("old-folder", (source / ".local/github-config.json").read_text())
            self.assertTrue((source / "reports/unique-id/result.json").is_file())

    def test_idempotent_install_resumes_missing_data_migration(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = self.fixture(Path(tmp))
            self.invoke(source, target)
            (source / ".local/new-receipt.json").write_text("resume")
            result = self.invoke(source, target)
            self.assertEqual("already-installed", result["status"])
            self.assertEqual("resume", (target / ".local/new-receipt.json").read_text())
            self.assertFalse((target / ".local/source-backups").exists())

    def test_retry_after_runtime_copy_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = self.fixture(Path(tmp))
            (source / ".local").mkdir()
            (source / ".local/settings.json").write_text("retained")
            with patch.object(installer, "copy_missing", side_effect=OSError("disk-full")):
                with self.assertRaises(OSError):
                    self.invoke(source, target)
            self.assertTrue((target / "start.py").is_file())
            self.invoke(source, target)
            self.assertEqual("retained", (target / ".local/settings.json").read_text())

    def test_upgrade_backs_up_source_and_keeps_runtime(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = self.fixture(Path(tmp))
            target.mkdir()
            (target / "__init__.py").write_text('VERSION = "0.1.6"\n')
            (target / "start.py").write_text("old source")
            (target / ".local").mkdir()
            (target / ".local/config.json").write_text("keep")
            self.invoke(source, target)
            with zipfile.ZipFile(next((target / ".local/source-backups").glob("*.zip"))) as archive:
                self.assertEqual(b"old source", archive.read("derelict_offline/start.py"))
                self.assertNotIn("derelict_offline/.local/config.json", archive.namelist())
            self.assertEqual("keep", (target / ".local/config.json").read_text())
            self.assertEqual((source / "start.py").read_bytes(), (target / "start.py").read_bytes())

    def test_partial_source_write_failure_restores_old_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = self.fixture(Path(tmp))
            target.mkdir()
            (target / "__init__.py").write_text('VERSION = "0.1.6"\n')
            (target / "start.py").write_text("old source")
            real_replace = installer.os.replace
            def fail_second(src, dst):
                if Path(dst) == target / "start.py" and ".install-" in Path(src).name:
                    raise OSError("disk-full")
                return real_replace(src, dst)
            with patch.object(installer.os, "replace", side_effect=fail_second):
                with self.assertRaises(OSError):
                    self.invoke(source, target)
            self.assertIn("0.1.6", (target / "__init__.py").read_text())
            self.assertEqual("old source", (target / "start.py").read_text())
            self.assertFalse(list(target.glob("*.install-*")))

    def test_both_source_and_destination_worker_locks_block_install(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = self.fixture(Path(tmp))
            for root in (source, target):
                with instance_lock(root / ".local"):
                    with self.assertRaises(OSError):
                        self.invoke(source, target)
                self.assertFalse((target / "start.py").exists())

    def test_downgrade_and_same_version_edits_require_review(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = self.fixture(Path(tmp))
            self.invoke(source, target)
            (target / "start.py").write_text("local changes")
            with self.assertRaisesRegex(ValueError, "same-version-source-conflict"):
                self.invoke(source, target)
            self.invoke(source, target, replace_source=True)
            (target / "__init__.py").write_text('VERSION = "0.1.8"\n')
            with self.assertRaisesRegex(ValueError, "newer-runner"):
                self.invoke(source, target, replace_source=True)
            self.assertIn("0.1.8", (target / "__init__.py").read_text())

    def test_unrecognized_folder_and_nested_folders_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = self.fixture(Path(tmp))
            target.mkdir()
            (target / "unrelated.txt").write_text("keep")
            with self.assertRaisesRegex(ValueError, "not-empty"):
                self.invoke(source, target)
            with self.assertRaisesRegex(ValueError, "separate"):
                self.invoke(source, source / "nested")
            self.assertEqual("keep", (target / "unrelated.txt").read_text())

    def test_linked_destination_directory_is_rejected_without_symlink_privileges(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = self.fixture(Path(tmp))
            with patch.object(Path, "is_symlink", lambda path: path == target):
                with self.assertRaisesRegex(ValueError, "linked-install"):
                    self.invoke(source, target)
            self.assertFalse(target.exists())

    def test_same_folder_is_a_no_op(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, _ = self.fixture(Path(tmp))
            self.assertEqual("already-installed", self.invoke(source, source)["status"])
            self.assertFalse((source / ".local").exists())

    def test_windows_helpers_all_route_to_the_permanent_folder(self):
        for name in ("Start-Runner.cmd", "Setup-GitHub.cmd", "Install-Unicorn.cmd", "Test-Unicorn.cmd", "Export-Offline-Evidence.cmd"):
            raw = (HERE / name).read_bytes()
            self.assertNotIn(b"\n", raw.replace(b"\r\n", b""), name)
            self.assertIn(b'%USERPROFILE%\\Documents\\NMS Runner', raw, name)
            self.assertIn(b'call "%~dp0Install-Runner.cmd" --quiet-exit', raw, name)
            self.assertIn(('call "%NMS_RUNNER_HOME%\\' + name + '" %*').encode(), raw, name)
