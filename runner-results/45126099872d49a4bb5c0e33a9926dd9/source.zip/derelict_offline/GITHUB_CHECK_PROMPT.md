# Scheduled GitHub evidence review

Paste the text below into a scheduled ChatGPT check with the GitHub connector
enabled. An hourly check is sufficient; the PC worker must remain running for
new automatic uploads. This package does not create a scheduled task.

The first PC run also checks Windows launch/job behavior. A passed Linux report
does not confirm Windows. The latest pointer and every referenced report are on
branch `nms-runner-evidence`, not the default `main` branch.

```text
Check vikkitor93-coder/NMS-Derelict-Probe using the GitHub connector.
Read the head commit of branch nms-runner-evidence, then fetch
runner-results/latest.json using that commit ref. If the branch
or file is absent, the PC has not uploaded a completed job yet: do not claim
an experiment failed or request a fresh game export.

Pin all further reads to the commit that supplied latest.json. Read
runner-results/<request_id>/manifest.json and result.json. Check the request ID,
source SHA256 and status agree with latest.json. Fetch only the stage reports
needed for the next decision, starting with the first failed stage. The manifest
lists exact file SHA256/byte counts; verify downloaded ZIPs against them before
using source or evidence. Do not describe running, failed, stale or cancelled
work as passed. Missing files or inconsistent hashes are a transport problem.

Before reviewing, read runner-reviews/<request_id>.json on the same branch,
if present. If it records the same source SHA256, this job was already reviewed:
do not repeat the notification or research work. After a new review, create that
small JSON file on nms-runner-evidence with schema=1, request_id, source_sha256,
status="reviewed" and concise findings/next_action. This instruction authorizes
that review receipt only. Preserve an existing matching receipt, and report a
conflicting receipt rather than overwriting it. If recording fails, say so;
do not claim persistent deduplication. Never modify latest.json or job artifacts.

Use the exact tested source.zip and its AI_HANDOFF.md as the project baseline
when available, rather than an older main-branch copy. If a failed package stage
left no source.zip, report that specific failure. Report the result and the next
useful step; do not announce freighter customization or root/layout generation
from arithmetic tests. Root producer/layout remain unresolved. Do not request
an unchanged export again. Any new export request must name the missing code
ranges and the targeted exporter change it requires.

The runner uploads results; it does not download/apply new builds. A scheduled
review is not evidence that autonomous coding or PC updates are connected.
Do not change production files, merge PRs, run arbitrary commands on the PC,
or claim a new build was installed. If the task lacks a code execution workspace
or repository access, report the actual limitation rather than inventing a run.
```

The review receipt allows separate scheduled runs to avoid repeating a job.
It is written by the scheduled check, not by the PC uploader. Concurrent reviews
may race; use GitHub's create-file conflict handling and retain the first receipt.
The uploader preserves other branch files and uses non-forced branch updates.
If a review commit races an upload, the upload retries from the new branch head.
