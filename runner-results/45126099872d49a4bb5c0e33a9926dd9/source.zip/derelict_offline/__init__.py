"""Read-only derelict research. Never imported by Surveyor."""
VERSION = "0.1.7"
SCHEMA_VERSION = 1
