"""Optional evidence-only GitHub transport. Authentication belongs to gh CLI."""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import zipfile
from .common import HERE
from .runner_protocol import atomic_json, validate_request

REPO = "vikkitor93-coder/NMS-Derelict-Probe"
BRANCH = "nms-runner-evidence"
PREFIX = "runner-results"
MAX_FILE = 4 * 1024 * 1024
MAX_TOTAL = 8 * 1024 * 1024
FILES = ("result.json", "latest.log", "diagnose.json", "code.json", "emulate.json",
         "runner-evidence.zip", "source.zip")


class TransportError(Exception):
    """Only fixed error codes escape the transport, never raw gh diagnostics."""


def valid_repo(repo):
    return (isinstance(repo, str) and re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo)
            and all(part not in (".", "..") for part in repo.split("/")))


def gh_path():
    found = shutil.which("gh")
    if found:
        return found
    for key in ("ProgramFiles", "LOCALAPPDATA"):
        base = os.environ.get(key)
        if base:
            path = Path(base) / ("GitHub CLI/gh.exe" if key == "ProgramFiles" else "Programs/GitHub CLI/gh.exe")
            if path.is_file():
                return str(path)
    raise TransportError("github-cli-missing")


def command(args, payload=None, timeout=30):
    try:
        # Tokens stay in gh's credential store/environment. No shell or raw logs.
        return subprocess.run([gh_path(), *args], input=payload, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=timeout, check=False)
    except subprocess.TimeoutExpired:
        raise TransportError("github-timeout") from None
    except OSError:
        raise TransportError("github-cli-start-failed") from None


class GitHub:
    def __init__(self, repo):
        self.prefix = "repos/" + repo

    def api(self, endpoint, method="GET", body=None, missing_ok=False):
        argv = ["api", self.prefix + ("/" + endpoint if endpoint else ""), "--hostname", "github.com", "--method", method,
                "--header", "Accept: application/vnd.github+json"]
        payload = None
        if body is not None:
            argv += ["--input", "-"]
            payload = json.dumps(body).encode("utf-8")
        result = command(argv, payload)
        if result.returncode:
            if missing_ok and b"(HTTP 404)" in result.stderr:
                return None
            raise TransportError("github-api-failed")
        try:
            return json.loads(result.stdout)
        except ValueError:
            raise TransportError("github-invalid-response") from None


def config(root):
    path = root / ".local/github-config.json"
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        # Transport destination cannot be a URL, main, or an arbitrary command.
        if (set(value) != {"schema", "repo", "branch"} or type(value["schema"]) is not int
                or value["schema"] != 1 or value["branch"] != BRANCH
                or not valid_repo(value["repo"])):
            raise ValueError()
        return value
    except (OSError, ValueError, KeyError, TypeError):
        raise TransportError("github-config-invalid") from None


def prepare(folder):
    """Freeze only completed worker artifacts, never scan arbitrary local files."""
    try:
        if folder.is_symlink():
            raise ValueError()
        raw_result = (folder / "result.json").read_bytes()
        if len(raw_result) > 65536:
            raise ValueError()
        result = json.loads(raw_result)
        request = validate_request({key: result[key] for key in ("schema", "request_id", "action", "source_sha256")})
        if folder.name != request["request_id"] or result["status"] not in ("passed", "failed", "stale", "cancelled"):
            raise ValueError()
        data = {}
        for name in FILES:
            path = folder / name
            if path.is_symlink():
                raise ValueError()
            if path.is_file():
                if path.stat().st_size > MAX_FILE:
                    raise TransportError("github-artifact-too-large")
                data[name] = path.read_bytes()
                if len(data[name]) > MAX_FILE:
                    raise TransportError("github-artifact-too-large")
        if sum(map(len, data.values())) > MAX_TOTAL:
            raise TransportError("github-artifacts-too-large")
        if data.get("result.json") != raw_result or "runner-evidence.zip" not in data:
            raise ValueError()
        from io import BytesIO
        with zipfile.ZipFile(BytesIO(data["runner-evidence.zip"])) as archive:
            allowed = {"result.json", "latest.log", "diagnose.json", "code.json", "emulate.json", "offline-evidence.zip"}
            if (not set(archive.namelist()) <= allowed or len(archive.namelist()) != len(set(archive.namelist()))
                    or archive.getinfo("result.json").file_size > 65536
                    or archive.read("result.json") != raw_result):
                raise ValueError()
        manifest = {"schema": 1, "request_id": request["request_id"], "source_sha256": request["source_sha256"],
                    "status": result["status"], "prototype_version": result["prototype_version"],
                    "report_path": PREFIX + "/" + request["request_id"],
                    "files": {name: {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
                              for name, raw in data.items()}}
        return data, manifest
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile):
        raise TransportError("github-report-invalid") from None


def read_json(api, path, ref):
    entry = api.api("contents/" + path + "?ref=" + ref, missing_ok=True)
    if entry is None:
        return None
    try:
        return json.loads(base64.b64decode(entry["content"], validate=False))
    except (ValueError, KeyError, TypeError):
        raise TransportError("github-remote-manifest-invalid") from None


def publish(api, data, manifest):
    """One non-forced commit makes every file and latest pointer visible together."""
    head = api.api("git/ref/heads/" + BRANCH, missing_ok=True)
    if head is None:
        info = api.api("")
        # URL-encode the repo's existing default branch for the read only.
        from urllib.parse import quote
        base = api.api("git/ref/heads/" + quote(info["default_branch"], safe=""))
        api.api("git/refs", "POST", {"ref": "refs/heads/" + BRANCH, "sha": base["object"]["sha"]})
        head = base
    parent = head["object"]["sha"]
    remote = read_json(api, manifest["report_path"] + "/manifest.json", parent)
    if remote is not None:
        if remote != manifest:
            raise TransportError("github-request-id-conflict")
        # Lost replies/restarts must not republish an old latest pointer.
        return parent
    commit = api.api("git/commits/" + parent)
    encoded = json.dumps(manifest, indent=2, sort_keys=True).encode("utf-8") + b"\n"
    paths = {manifest["report_path"] + "/" + name: raw for name, raw in data.items()}
    paths[manifest["report_path"] + "/manifest.json"] = encoded
    paths[PREFIX + "/latest.json"] = encoded
    tree = []
    for path, raw in paths.items():
        blob = api.api("git/blobs", "POST", {"encoding": "base64", "content": base64.b64encode(raw).decode("ascii")})
        tree.append({"path": path, "mode": "100644", "type": "blob", "sha": blob["sha"]})
    created = api.api("git/trees", "POST", {"base_tree": commit["tree"]["sha"], "tree": tree})
    changed = api.api("git/commits", "POST", {"message": "NMS offline evidence " + manifest["request_id"],
                      "tree": created["sha"], "parents": [parent]})
    api.api("git/refs/heads/" + BRANCH, "PATCH", {"sha": changed["sha"], "force": False})
    return changed["sha"]


class Uploader:
    def __init__(self, root, settings, api=None):
        self.root = root
        self.settings = settings
        self.api = api or GitHub(settings["repo"])
        self.ledger = root / ".local/github-uploads.json"
        self.next_poll = 0

    def poll(self, force=False):
        now = time.monotonic()
        if not force and now < self.next_poll:
            return True
        self.next_poll = now + 60
        try:
            state = json.loads(self.ledger.read_text()) if self.ledger.is_file() else {}
            # A repo switch must not inherit another repo's completed receipts.
            if state.get("repo") != self.settings["repo"]:
                state = {"schema": 1, "repo": self.settings["repo"], "jobs": {}}
            folders = sorted((self.root / "reports").glob("*"), key=lambda p: p.stat().st_mtime)
            success = True
            for folder in folders:
                if not re.fullmatch(r"[a-f0-9]{32}", folder.name) or not (folder / "result.json").is_file():
                    continue
                job = state["jobs"].get(folder.name, {"attempts": 0})
                if job.get("status") == "uploaded":
                    continue
                if job["attempts"] >= 3:
                    success = False
                    break  # Preserve order: a late retry must not rewind latest.
                job["attempts"] += 1
                job["status"] = "pending"
                state["jobs"][folder.name] = job
                atomic_json(self.ledger, state)  # Crash still counts as a bounded attempt.
                try:
                    data, manifest = prepare(folder)
                    commit = publish(self.api, data, manifest)
                    job.update(status="uploaded", commit=commit)
                    job.pop("error", None)
                    print("[github-upload] uploaded " + folder.name, flush=True)
                except TransportError as error:
                    success = False
                    job.update(status="failed", error=str(error))
                    print("[github-upload] " + str(error) + "; local reports retained. See RUNNER.md.", flush=True)
                atomic_json(self.ledger, state)
                if not success:
                    break
            atomic_json(self.root / ".local/github-status.json", {"schema": 1,
                        "status": "uploaded" if success else "pending-or-blocked", "jobs": state["jobs"]})
            return success
        except (OSError, ValueError, KeyError, TypeError):
            print("[github-upload] github-local-state-invalid; local reports retained.", flush=True)
            return False


def setup(root, repo):
    settings = {"schema": 1, "repo": repo, "branch": BRANCH}
    if not valid_repo(repo):
        raise TransportError("github-repository-invalid")
    gh_path()
    if command(["auth", "status", "--hostname", "github.com"]).returncode:
        print("Sign in to GitHub once. The browser/device code comes from GitHub CLI.", flush=True)
        # Interactive output is console-only, never evidence; do not store tokens.
        code = subprocess.call([gh_path(), "auth", "login", "--hostname", "github.com", "--git-protocol", "https", "--web"])
        if code or command(["auth", "status", "--hostname", "github.com"]).returncode:
            raise TransportError("github-sign-in-required")
    info = GitHub(repo).api("")
    if not info.get("permissions", {}).get("push") or info.get("archived"):
        raise TransportError("github-repository-write-access-required")
    if info.get("visibility") == "public":
        print("This repository is public. Completed source/reports and selected bounded code exports will be public.", flush=True)
    atomic_json(root / ".local/github-config.json", settings)
    print("GitHub uploads enabled. Restart Start-Runner.cmd. Destination branch: " + BRANCH, flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--setup", action="store_true")
    parser.add_argument("--repo", default=REPO)
    parser.add_argument("--disable", action="store_true")
    parser.add_argument("--retry", action="store_true")
    args = parser.parse_args(argv)
    root = HERE.resolve()
    try:
        if args.disable:
            (root / ".local/github-config.json").unlink(missing_ok=True)
            print("Uploads disabled. Restart a running worker.", flush=True)
            return 0
        if args.setup:
            setup(root, args.repo)
            return 0
        settings = config(root)
        if settings is None:
            raise TransportError("github-not-configured-run-setup")
        from .local_runner import instance_lock
        with instance_lock(root / ".local"):
            uploader = Uploader(root, settings)
            if args.retry and uploader.ledger.is_file():
                state = json.loads(uploader.ledger.read_text())
                for job in state["jobs"].values():
                    if job.get("status") != "uploaded":
                        job["attempts"] = 0
                atomic_json(uploader.ledger, state)
            return 0 if uploader.poll(force=True) else 1
    except TransportError as error:
        print("[github] " + str(error), flush=True)
        if str(error) == "github-cli-missing":
            print("Install GitHub CLI from https://cli.github.com/ then run Setup-GitHub.cmd again.", flush=True)
        return 2
    except (OSError, ValueError, KeyError, TypeError):
        print("[github] local-state-or-lock-error. Stop the runner before manual upload/retry.", flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
