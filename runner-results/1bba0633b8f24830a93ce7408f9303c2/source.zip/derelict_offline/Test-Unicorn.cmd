@echo off
setlocal EnableExtensions DisableDelayedExpansion
title NMS Offline - Unicorn checks
echo Starting the Unicorn checks...
pushd "%~dp0"
set "OFFLINE_PY=python"
where py.exe >nul 2>&1
if not errorlevel 1 set "OFFLINE_PY=py -3"
if exist ".unicorn-venv\Scripts\python.exe" set "OFFLINE_PY=.unicorn-venv\Scripts\python.exe"
call %OFFLINE_PY% -u start.py emulate --repetitions 1000 --out unicorn-local-result.json
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (echo Passed. Results: unicorn-local-result.json) else (echo See the error above. Install-Unicorn.cmd installs the optional dependency.)
popd
pause
exit /b %RC%
