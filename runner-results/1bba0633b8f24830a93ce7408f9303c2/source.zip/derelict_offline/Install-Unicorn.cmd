@echo off
setlocal EnableExtensions DisableDelayedExpansion
title NMS Offline - Unicorn installer 0.1.3
echo.
echo Starting Unicorn setup 0.1.3...
echo This window stays open when setup finishes or fails.
echo.
pushd "%~dp0"
if errorlevel 1 goto folder_failed
> "latest-install.log" echo {"schema_version":1,"build":"0.1.3","stage":"launcher-start","status":"running"}
where py.exe >nul 2>&1
if errorlevel 1 goto try_python
echo Starting Python with the Windows launcher...
call py.exe -3 -u install_unicorn.py
set "RC=%ERRORLEVEL%"
goto finished
:try_python
where python.exe >nul 2>&1
if errorlevel 1 goto no_python
echo Starting Python...
call python.exe -u install_unicorn.py
set "RC=%ERRORLEVEL%"
goto finished
:no_python
echo Python was not found. Install Python 3.10 or newer, then try again.
set "RC=2"
goto finished
:finished
>> "latest-install.log" echo {"schema_version":1,"build":"0.1.3","stage":"launcher-end","returncode":%RC%}
echo.
if "%RC%"=="0" goto success
echo Setup failed. Read the error above and share latest-install.log.
goto close_window
:success
echo Setup passed. Run Test-Unicorn.cmd next.
:close_window
popd
echo.
pause
exit /b %RC%
:folder_failed
echo Could not open the extracted experiment folder.
echo Extract the entire ZIP before running this file.
pause
exit /b 2
