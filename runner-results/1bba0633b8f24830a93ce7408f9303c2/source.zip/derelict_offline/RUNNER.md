# NMS Offline local runner

Start once with `Start-Runner.cmd`. It checks the private Unicorn environment,
installs the pinned dependency only if needed, runs the first job, then watches
this experiment's source files. NMS stays closed. Ctrl+C stops owned work.
There is no game launch or process attachment. GitHub uploads are optional;
enable them once with `Setup-GitHub.cmd`. The worker does not log in to ChatGPT.

Each stable source change runs once. Fixed stages: frozen source ZIP, focused
tests, scene replay diagnostics, code evidence validation, 4,040 Unicorn
comparisons. A failed stage stops the job; failures are not retried endlessly.
Unchanged source is idle, not repeatedly tested. An explicit request can retest
unchanged source. Changes during a run mark that result stale and queue the
new stable source. Two consecutive observations, five seconds apart, debounce
source edits; Work should publish a request only after completing all edits.

Latest state: `.local/status.json`, `.local/latest.log`,
`.local/latest-result.json`. Per-job results: `reports/<request_id>/` with
`result.json`, `source.zip` and `runner-evidence.zip`. The source ZIP is the
exact tested snapshot, with handoff/tests/assets; local environments, outputs,
requests and caches are excluded. The evidence ZIP contains allowlisted result
JSON, stage logs and a bounded game-code export if requested. No machine paths,
network/device identifiers or personal telemetry are added to these logs.
Subprocess text is shown in the console only; share the stage reports for
diagnosis. Original historical verification reports remain provenance, not
claims about the latest local run. Check the per-run result for actual status.

Developer controls:

```text
python start.py runner --status
python start.py runner --once
python start.py runner --request offline-check
python start.py package --out complete-source.zip
```

## Automatic GitHub uploads in 0.1.5

1. Run `Setup-GitHub.cmd` once. It installs GitHub CLI through the official
   winget package if missing and opens GitHub's sign-in flow if needed. If winget
   is unavailable, install GitHub CLI from https://cli.github.com/ and rerun it.
   An already authenticated CLI is reused; repository write access is checked.
2. Start/restart `Start-Runner.cmd`. Completed jobs upload automatically to
   `vikkitor93-coder/NMS-Derelict-Probe`, branch `nms-runner-evidence`.
3. Use `GITHUB_CHECK_PROMPT.md` for your scheduled ChatGPT check with GitHub
   access. No scheduled task is created by setup or by the runner.

This repository is public. Uploaded source, reports and any explicitly selected
bounded code export are visible publicly. No full NMS.exe, private environment,
credentials, raw process output or unrelated local files are uploaded.
GitHub CLI owns authentication; this package never reads or saves a token.
The CLI is not bundled into the small source ZIP. Auth storage follows GitHub CLI.

Remote layout: `runner-results/<request_id>/` contains readable stage JSON/logs,
`result.json`, `manifest.json`, `runner-evidence.zip`, and `source.zip` when
packaging succeeded. `runner-results/latest.json` repeats the latest manifest,
including source digest, status, file SHA256 and byte counts. All files/pointer
publish together in one commit. Existing files on the evidence branch are
preserved. Main is never written by the uploader. Old IDs are immutable;
matching uploads are idempotent and do not rewind the latest pointer.

Only allowlisted artifacts are sent: at most 4 MiB each / 8 MiB total per job.
The evidence ZIP also includes the bounded export if requested. Reports retain
their original execution status; `.local/github-status.json` and
`github-uploads.json` record transfer separately. No successful upload means
no verified research conclusion. The uploader uses GitHub CLI's authenticated
API requests with bounded timeouts and no shell commands.

Upload attempts occur after a job and at most once per minute while idle, with
three attempts per report, persisted across restarts. Failed uploads retain all
files, do not rerun tests/export, and block later uploads to preserve order.
After fixing network/auth/access, stop the runner, then run:
`python start.py github --retry`. This resets failed attempt counts and sends
retained reports. Restart the worker afterward. `python start.py github` sends
pending reports without resetting limits. Both require the worker to be stopped.
The first configured launch also uploads retained completed reports from this
experiment folder. A one-shot run returns failure if its upload is unsuccessful.

Disable with `python start.py github --disable`, then restart the worker.
Configuration is `.local/github-config.json`; it is excluded from all ZIPs.
For another authorized repo: `Setup-GitHub.cmd --repo owner/name`; the fixed
evidence branch remains the same. GitHub history retains uploaded reports even
after local cleanup; the existing 100-report local cap still applies.

## Optional executable exports

Only select NMS.exe when new bounded exports are needed. The existing unchanged
exporter cannot reveal new callers. Run:

```text
Start-Runner.cmd --exe "G:\SteamLibrary\steamapps\common\No Man's Sky\Binaries\NMS.exe"
```

This enables bounded read-only exports; the EXE is not launched, modified or
copied. Its path is kept only in process memory, not reports or configuration.
The exporter checks the executable's hash and fails if incompatible. Unchanged
export inputs reuse the validated local export. A changed exporter or EXE
invalidates that cache. To ask for a check/export after edits:
`python start.py runner --request offline-check-and-export`.
Without the initial `--exe` selection this action fails with
`nms-exe-not-selected`; it does not prompt or probe a different game.

## AI / runner boundary

This is a separate NMS worker using the earlier Unspottable runner pattern.
Unspottable request `build-and-h2` remains unchanged and is not accepted here.
NMS schema 1 accepts exactly:

```json
{"schema":1,"request_id":"32 lowercase hex characters","action":"offline-check","source_sha256":"64 lowercase hex characters"}
```

Publish `requests/ready.json` atomically without replacing a pending request;
the helper command above calculates the source hash and publishes safely.
Only `offline-check` / `offline-check-and-export` are accepted. No arbitrary
commands, arguments or paths are accepted from requests. A lock prevents two
workers. Claimed requests survive crashes and stop the next launch for review.
Check `.local/claimed-request.json` and the corresponding report; after
review, move the claimed file aside, then restart. IDs cannot be reused.

For a local AI with access to the same folder, use `LOCAL_WORK_PROMPT.md`.
That AI can read results, edit code and publish the next fixed request.
The runner itself does not write research code or make scientific decisions.
Alternatively the GitHub upload path lets a scheduled check read completed
results without direct PC folder access. Setup must succeed on the PC first.
The included scheduled prompt records a review receipt per job and avoids
repeated review. It authorizes only those review receipts, not production edits.
No scheduled task was installed. Automatic code-writing and downloading/applying
the next build on the PC are not implemented in this version. Repository upload
does not itself connect that return path.

Runner source changes take effect after restarting `Start-Runner.cmd`;
research-module changes are picked up by the next snapshot. Keep completed
reports for review/rollback. At 100 report folders, the runner stops for cleanup
rather than filling disk or deleting evidence. Rollback: stop runner and use
the prior experiment ZIP; existing Surveyor/Unspottable files are untouched.
