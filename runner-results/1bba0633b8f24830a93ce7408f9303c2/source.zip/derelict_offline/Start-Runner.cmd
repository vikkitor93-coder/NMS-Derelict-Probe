@echo off
setlocal EnableExtensions DisableDelayedExpansion
title NMS Offline runner 0.1.4
echo Starting NMS Offline runner 0.1.4...
echo Leave this window open. Ctrl+C stops the runner.
pushd "%~dp0"
if errorlevel 1 goto folder_failed
if exist ".unicorn-venv\Scripts\python.exe" goto use_venv
where py.exe >nul 2>&1
if errorlevel 1 goto try_python
call py.exe -3 -u start.py runner %*
set "RC=%ERRORLEVEL%"
goto finished
:use_venv
call ".unicorn-venv\Scripts\python.exe" -u start.py runner %*
set "RC=%ERRORLEVEL%"
goto finished
:try_python
where python.exe >nul 2>&1
if errorlevel 1 goto no_python
call python.exe -u start.py runner %*
set "RC=%ERRORLEVEL%"
goto finished
:no_python
echo Python 3.10 or newer is required. Install Python, then try again.
set "RC=2"
:finished
popd
echo Runner finished with code %RC%.
pause
exit /b %RC%
:folder_failed
echo Extract the entire ZIP before starting the runner.
pause
exit /b 2
