@echo off
setlocal EnableExtensions
pushd "%~dp0"
set "NMS_EXE_ARG="
if not "%~1"=="" set NMS_EXE_ARG=--exe "%~1"
where py.exe >nul 2>&1
if not errorlevel 1 (
    py -3 start.py export %NMS_EXE_ARG%
) else (
    python start.py export %NMS_EXE_ARG%
)
set "RC=%ERRORLEVEL%"
popd
echo.
if "%RC%"=="0" (
    echo Attach offline-evidence.zip from this folder to the chat.
) else (
    echo Export did not complete cleanly. Send the error shown above.
)
pause
exit /b %RC%
