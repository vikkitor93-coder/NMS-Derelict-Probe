# Derelict offline experiment — AI handoff

## Purpose and state (2026-10-11)

- Experiment 0.1.5; standalone experiment-only ZIP, root `derelict_offline/`.
  Isolated from Surveyor 0.3.75 / Probe 0.3.42. No production application,
  game installation, updater or existing Unspottable runner was edited.
- Goal: address/POI → root descriptor → parameters/layout → containers.
  Implemented: public system seed (NOT root), captured-scene replay, RNG
  arithmetic, empty-vector descriptor copy and identifier swap-delete.
  Root formula and room generation are unresolved; no freighter feature.
- User confirmed 0.1.3 installer worked on Windows. Runner automates local
  execution; optional GitHub evidence uploads added for the user's scheduled
  ChatGPT checks. PC setup/auth still needed. No cloud task created, no automatic
  coding/build download/application connected. See GITHUB_CHECK_PROMPT.md.

## Architecture, entry points and dependencies

- `start.py`: standalone bootstrap; works in renamed folder. `run.py`,
  `build_corpus.py`, `prototype.py`: diagnose/replay/corpus/benchmark.
- `rng_kernel.py`, `unicorn_check.py`: direct arithmetic / bounded x64 emulation.
  `code_evidence.py`, `export_evidence.py`: validation/read-only bounded export.
- `local_runner.py`: watcher, fixed subprocess pipeline, immutable snapshots,
  dependency health check, status/results and source/evidence packaging.
  `runner_protocol.py`: NMS request schema and atomic publication/source digest.
- `github_exchange.py`: optional gh CLI transport, config/receipts, allowlisted
  artifacts, bounded retries. `Setup-GitHub.cmd`: winget install/sign-in/setup.
  Credentials stay with gh CLI; CLI installation is external to this ZIP.
- `windows_job.py`: unchanged containment helper reused from local runner
  v0.1.9; Windows Job Object / POSIX process-group cleanup on cancel/timeout.
- `install_unicorn.py`: private optional environment; installer build marker
  remains 0.1.3. `package_experiment.py`: explicit source allowlist.
  `RUNNER.md`, `LOCAL_WORK_PROMPT.md`: operation / local AI integration contract.
- Python 3.10+, base stdlib; optional pinned unicorn==2.1.4. `.unicorn-venv`
  excluded from packages. Seven analyzer tools are unchanged dependencies.
  `fixtures/manifest.json` preserves original source/fixture provenance.

## Contracts, data and critical flow

- Corpus/evidence/protocol/log schemas remain 1. Unsigned 64-bit hex seeds,
  observed flags preserved. Production protocols/saved formats unchanged.
- NMS request has exactly schema=1, request_id=32 lowercase hex,
  action=`offline-check` or `offline-check-and-export`, source_sha256=64 hex.
  Atomic `requests/ready.json`; no command strings/paths. Never redirect
  Unspottable `build-and-h2` requests to this separate NMS worker.
- Single-instance lock → copy/rehash source → source ZIP → focused tests →
  replay → code validation → Unicorn comparisons → optional bounded export →
  result/evidence ZIP. Stop on first failure. Changed source marks result stale.
- Claimed jobs survive crashes and require review; IDs cannot be reused.
  Automatic stable changes run once; explicit requests may intentionally retest.
- `.local/status.json`, `latest.log`, `latest-result.json` hold latest state.
  `reports/<request_id>/` retains result.json, exact tested source.zip and
  runner-evidence.zip. Logs contain allowlisted stages/codes, no personal,
  machine-path/device/network telemetry. Raw child output is console-only.
  At 100 report folders stop for cleanup instead of deleting evidence.
- Optional --exe is memory-only/read-only. Export cache keys include exporter
  input and EXE hashes; cache ZIP rehashed before reuse. Game EXE never copied
  into deliverables. Unchanged exports do not supply additional research bytes.
- Uploads default off; .local/github-config.json enables fixed evidence branch
  nms-runner-evidence in vikkitor93-coder/NMS-Derelict-Probe (public), or a repo
  explicitly selected during setup. Never write main. Artifact limits 4 MiB/file,
  8 MiB/job; only result/log/stage JSON, evidence/source ZIPs. Full EXE/private
  environment/raw child output/config/secrets excluded. No token read by Python.
- One git tree/commit publishes immutable job files + runner-results/latest.json
  together; non-forced branch advance rejects conflicts. Manifests contain source
  hash/status/file SHA256/size. Matching ID is idempotent, conflicting ID blocked.
  Preserve base tree, including AI review receipts. Separate local upload ledger;
  no change to research results on transport failure. Three persisted attempts/job,
  minute idle polling; failure blocks later uploads, retains evidence, no rerun.
- Scheduled review prompt pins reads to a commit and records runner-reviews/ID.json
  for deduplication. This prompt is provided for user setup, not an active task.
  A review receipt does not implement remote coding or installing the next build.

## Research evidence and constraints

- Four projections: roots 9C2818C7FE094FC8 / 2A41B0E7EF42A1F7; repeat asset
  totals 37 / 23. Historical captures lack captured full version/hash; keep
  quarantined. 7.05 is user context only; never retroactively pin captures.
- Latest offline-code-evidence-20261011-v0.1.2.json: 149 ranges / 103,256 bytes;
  hashes and four root-call windows verified. Exporter-reported EXE SHA256
  13d5060d4efb9d2a6a6b1b349bc4257231056cc2a055df4bb15d816262cc3499,
  image base 140000000, size 88,560,712. Full EXE not uploaded/rehashed here.
- 4,040 Unicorn comparisons: 1,009 seed initialization, 1,004 state/output,
  1,024 empty-vector copies, 1,003 deletions; zero mismatches. RX code,
  private stack/data, clean state per case, instruction/time budgets. Unknown
  imports/memory fail. ONLY external model: 033E4B4C for zero byte length;
  refuses nonzero. Supplement 406 vector-helper bytes from prior same-identity
  export after validation. Nonempty copy fails at global RVA 05292041; no
  invented allocator/TLS model. Kernel tests do not prove dungeon generation.
- 00227A40 copies +10/+18 and +20/+28 seed fields; 00227620 manages 32-byte
  identifiers; 00641160 builds identifier/hash. None derives the root.
  Owner 639BE0 → 639610 → 227A40 forwards input argument five; wrappers
  639490 / 639A70 forward descriptors. Caller sites 1B2CF9, 1688764, 16888D2,
  2D08081, 2D08898 decoded; last pair forwards argument six into
  2D07C80 / 2D08430. Upstream producer and live derelict branch unknown.
- Shipwright f89691ed037edf437a7406c176aa6b96e654d314 labels matching 0062E2B0
  palette-related. Semantic inference only, not dungeon proof; independent
  code here. Table Rooms=7 vs observed 10/9 groups unresolved. Asset totals
  are not physical inventory/topology proof. No generation speedup established.

## Run, debug and verification

- Windows: extract → Start-Runner.cmd. Reuses healthy private environment;
  setup only if needed. Ctrl+C stops. --exe optional when new bytes needed.
- Developer: `python start.py runner --status`, `runner --once`,
  `runner --request offline-check`, `diagnose`, `code`, `test`, `emulate`.
  Source export: `python start.py package --out complete-source.zip`.
- GitHub: Setup-GitHub.cmd once, then restart runner. CLI controls:
  `python start.py github --retry` (stop runner first); `github --disable` then
  restart. Retry resets only failed upload counts; receipts persist across runs.
- 80 experiment tests passed with Unicorn on Linux; 18 runner regressions
  cover schema, atomic claims, snapshots, stale/failed/cancelled runs, timeouts,
  exclusive lock, export cache, limits and packaging privacy. 14 transport tests
  cover atomic visibility, conflicts, lost replies, retry limits, restart receipts,
  bounded artifacts, default-off behavior and upload failure without rerunning.
  Network writes simulated; no live upload/Windows sign-in tested here.
- Previous 0.1.4 real one-shot pipeline passed on Linux: source ZIP, 66 tests,
  four replays, hashes, 4,040 comparisons. 0.1.5 real one-shot also passed
  on Linux: source ZIP, current experiment suite, four replays, hashes and
  4,040 comparisons. No network upload was enabled; STATUS.json records gates.
- New Windows launcher/job/setup behavior cannot be executed here: first PC run
  needed. Previous full application suite in 0.1.3: 303 run / 285 passed /
  18 display skips. Not rerun in this experiment-only package.

## Migration, rollback and exact next action

- Additive uploader; no data/schema migration. Stop and use 0.1.4 ZIP to roll
  back; retain per-job source/evidence ZIPs. Surveyor remains independent.
- Research-module changes picked up in snapshots; runner/bootstrap changes
  require restart. No local AI/scheduler/chat connection installed. Use an
  authorized local Work/Codex session on this folder + LOCAL_WORK_PROMPT.md;
  never claim the unattended AI connection is already active.
- User: Setup-GitHub.cmd once → Start-Runner.cmd; schedule a check using
  GITHUB_CHECK_PROMPT.md with GitHub access. Inspect uploaded latest.json/result
  for first Windows confirmation. NMS can stay closed. No next-build auto apply.
- AI: inspect first PC report/failed stage. Establish return-path mechanism only
  as a separate verified change. Root research: trace callers of 2D07C80/2D08430 and descriptor-storage
  writes. Update targeted exporter only when missing bytes are named; never
  request another unchanged export. Do not invent globals to claim generation.
