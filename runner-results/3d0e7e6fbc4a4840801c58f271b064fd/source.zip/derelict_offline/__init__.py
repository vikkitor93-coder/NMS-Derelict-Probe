"""Read-only derelict research. Never imported by Surveyor."""
VERSION = "0.1.15"
SCHEMA_VERSION = 1
