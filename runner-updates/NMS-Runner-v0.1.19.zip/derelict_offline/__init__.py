"""Read-only derelict research. Never imported by Surveyor."""
VERSION = "0.1.19"
SCHEMA_VERSION = 1
