from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def hex64(value):
    if isinstance(value, bool):
        raise ValueError("Boolean is not a seed/address")
    number = value if isinstance(value, int) else int(str(value).removeprefix("0x").removeprefix("0X"), 16)
    if not 0 <= number < 2**64:
        raise ValueError("Expected an unsigned 64-bit value")
    return f"{number:016X}"

def effective_seed(primary):
    flag = primary.get("use_seed_value")
    raw = primary.get("seed_hex")
    return hex64(raw) if flag is True and raw is not None else None
