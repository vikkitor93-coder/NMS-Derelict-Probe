#!/usr/bin/env python3
"""Analyze accumulated derelict generation measurements for deterministic seed/address relationships."""
from __future__ import annotations
import argparse, json
from collections import defaultdict
from pathlib import Path
from typing import Any


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding='utf-8'))


def analyze(summary: dict[str, Any]) -> dict[str, Any]:
    rows=list(summary.get('measurements') or [])
    by_address: dict[str,list[dict[str,Any]]]=defaultdict(list)
    for row in rows:
        ua=str(row.get('universe_address_hex') or '').upper()
        if ua:
            by_address[ua].append(row)

    address_groups=[]
    repeated_stable=0
    repeated_total=0
    for ua, xs in sorted(by_address.items()):
        layouts=sorted({str(x.get('layout_multiset_signature_sha256') or x.get('layout_signature_sha256') or x.get('generation_signature_sha256') or '') for x in xs if x.get('layout_multiset_signature_sha256') or x.get('layout_signature_sha256') or x.get('generation_signature_sha256')})
        ordered_layouts=sorted({str(x.get('layout_signature_sha256') or '') for x in xs if x.get('layout_signature_sha256') and int(x.get('room_parent_index_coverage') or 0) >= int(x.get('total_rooms') or 0)})
        rewards=sorted({seed for x in xs for seed in (x.get('reward_seed_hexes') or []) if seed})
        dungeon_roots=sorted({seed for x in xs for seed in (x.get('dungeon_root_seed_hexes') or []) if seed})
        poi_args=sorted({seed for x in xs for seed in (x.get('poi_seed_candidate_hexes') or []) if seed})
        poi_equals_address=bool(poi_args) and all(str(v).upper().zfill(16)==ua.zfill(16) for v in poi_args)
        stable_layout = len(layouts)==1 if len(xs)>1 else None
        stable_reward = len(rewards)==1 if len(xs)>1 and rewards else None
        dungeon_root_measurements=sum(1 for x in xs if x.get('dungeon_root_seed_hexes'))
        lineage_signatures=sorted({str(x.get('resource_seed_lineage_signature_sha256') or '') for x in xs if x.get('resource_seed_lineage_signature_sha256')})
        lineage_measurements=sum(1 for x in xs if x.get('resource_seed_lineage_signature_sha256'))
        stable_dungeon_root = (
            len(dungeon_roots)==1
            if len(xs)>1 and dungeon_root_measurements==len(xs)
            else None
        )
        stable_lineage = (
            len(lineage_signatures)==1
            if len(xs)>1 and lineage_measurements==len(xs)
            else None
        )
        if len(xs)>1:
            repeated_total += 1
            if stable_layout:
                repeated_stable += 1
        address_groups.append({
            'universe_address_hex':ua,
            'measurement_count':len(xs),
            'preset_values':sorted({str(x.get('preset') or '') for x in xs if x.get('preset')}),
            'target_container_values':sorted({x.get('target_containers') for x in xs if x.get('target_containers') is not None}),
            'layout_multiset_signatures':layouts,
            'ordered_layout_signatures':ordered_layouts,
            'reward_seed_hexes':rewards,
            'dungeon_root_seed_hexes':dungeon_roots,
            'dungeon_root_seed_measurement_coverage':dungeon_root_measurements,
            'poi_context_hexes':poi_args,
            'poi_context_equals_universe_address':poi_equals_address,
            'layout_stable_across_repeats':stable_layout,
            'reward_seed_stable_across_repeats':stable_reward,
            'dungeon_root_seed_stable_across_repeats':stable_dungeon_root,
            'resource_seed_lineage_signatures':lineage_signatures,
            'resource_seed_lineage_measurement_coverage':lineage_measurements,
            'resource_seed_lineage_stable_across_repeats':stable_lineage,
            'room_sequences':[x.get('room_sequence') or [] for x in xs],
        })

    reward_to_addresses: dict[str,set[str]]=defaultdict(set)
    dungeon_root_to_addresses: dict[str,set[str]]=defaultdict(set)
    layout_to_addresses: dict[str,set[str]]=defaultdict(set)
    for row in rows:
        ua=str(row.get('universe_address_hex') or '').upper()
        for seed in row.get('reward_seed_hexes') or []:
            if seed and ua: reward_to_addresses[str(seed)].add(ua)
        for seed in row.get('dungeon_root_seed_hexes') or []:
            if seed and ua: dungeon_root_to_addresses[str(seed)].add(ua)
        sig=str(row.get('layout_multiset_signature_sha256') or row.get('layout_signature_sha256') or row.get('generation_signature_sha256') or '')
        if sig and ua: layout_to_addresses[sig].add(ua)

    return {
        'version':1,
        'measurement_count':len(rows),
        'unique_addresses':len(by_address),
        'repeated_address_groups':repeated_total,
        'repeated_address_groups_with_stable_layout':repeated_stable,
        'address_groups':address_groups,
        'reward_seed_collisions_across_addresses':[{'seed_hex':k,'addresses':sorted(v)} for k,v in sorted(reward_to_addresses.items()) if len(v)>1],
        'dungeon_root_seed_collisions_across_addresses':[{'seed_hex':k,'addresses':sorted(v)} for k,v in sorted(dungeon_root_to_addresses.items()) if len(v)>1],
        'layout_collisions_across_addresses':[{'layout_signature_sha256':k,'addresses':sorted(v)} for k,v in sorted(layout_to_addresses.items()) if len(v)>1],
        'interpretation':{
            'poi_context':'If poi_context_equals_universe_address is true, that hook argument is the system address, not a layout seed.',
            'layout_signature':'Ordered Room N signature when full parent-index coverage is available.',
            'layout_multiset_signature':'Stable room-assembly signature independent of threaded stream order and available for legacy captures.',
            'reward_seed':'Still a correlation candidate; equality with layout seed is not assumed.',
            'dungeon_root_seed':'Primary cTkResourceDescriptor seed attached to MODELS/SPACE/POI/DUNGEON.SCENE.MBIN; strongest current layout-seed candidate but still unverified.',
            'resource_seed_lineage':'Ordered non-zero descriptor seeds on DUNGEON resource add/find events; used to locate the derivation chain without assuming any event is RNG state.',
        },
    }


def main(argv=None)->int:
    ap=argparse.ArgumentParser(description='Analyze address/seed/room-layout correlations')
    ap.add_argument('summary',type=Path)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args(argv)
    out=analyze(load(args.summary))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
    print(f"Measurements: {out['measurement_count']} across {out['unique_addresses']} addresses")
    print(f"Repeated address groups with stable layout: {out['repeated_address_groups_with_stable_layout']}/{out['repeated_address_groups']}")
    for row in out['address_groups']:
        if row['measurement_count']>1:
            print(f"{row['universe_address_hex']}: repeats={row['measurement_count']} layout_stable={row['layout_stable_across_repeats']} reward_stable={row['reward_seed_stable_across_repeats']} dungeon_root_seed_stable={row['dungeon_root_seed_stable_across_repeats']} poi_arg_is_address={row['poi_context_equals_universe_address']}")
    print(f"Wrote: {args.output}")
    return 0

if __name__=='__main__':
    raise SystemExit(main())
