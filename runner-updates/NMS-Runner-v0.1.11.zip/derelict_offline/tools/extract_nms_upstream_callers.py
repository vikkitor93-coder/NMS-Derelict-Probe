#!/usr/bin/env python3
"""Offline xref scan for the function that hands the seeded derelict descriptor to Engine::AddResource.

Consumes dungeon-caller-code-latest.json, derives the containing function start from
compiler padding/prologue evidence, then scans the installed NMS.exe .text section
for direct E8/E9 rel32 references to that function.  Read-only; NMS does not run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

try:
    import extract_nms_caller_code as caller
except ModuleNotFoundError:
    import importlib.util
    _spec = importlib.util.spec_from_file_location("extract_nms_caller_code", Path(__file__).with_name("extract_nms_caller_code.py"))
    if _spec is None or _spec.loader is None:
        raise
    caller = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(caller)

TOOL_VERSION = "0.3.33"
DEFAULT_BEFORE = 1024
DEFAULT_AFTER = 256
MIN_PADDING = 4


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def find_input(explicit: str | None = None) -> Path:
    if explicit:
        p = Path(explicit).expanduser()
        if p.is_file():
            return p
        raise FileNotFoundError(f"Caller evidence not found: {p}")
    local = os.environ.get("LOCALAPPDATA")
    if local:
        p = Path(local) / "NMSDerelictSurveyor" / "asset-work-v1" / "dungeon-caller-code-latest.json"
        if p.is_file():
            return p
    raise FileNotFoundError("dungeon-caller-code-latest.json was not found. Run Extract dungeon caller code first.")


def _hex(value: int) -> str:
    return f"{value:08X}"


def _window_bytes(evidence: dict[str, Any]) -> tuple[int, bytes, int]:
    win = evidence.get("code_window") or {}
    start = int(str(win.get("start_rva_hex") or "0"), 16)
    raw = bytes.fromhex(str(win.get("bytes_hex") or ""))
    call_rva = int(str(evidence.get("call_instruction_rva_hex") or "0"), 16)
    if not raw or not start or not call_rva:
        raise ValueError("Caller evidence has no usable code window/call RVA")
    return start, raw, call_rva


def find_function_start_from_padding(evidence: dict[str, Any], min_padding: int = MIN_PADDING) -> dict[str, Any]:
    """Find the nearest credible compiler-padding/prologue boundary before the root call.

    MSVC does not require long INT3 padding.  The current NMS build uses four CC bytes
    immediately before the real entry at 0x00634BC0, so the older >=6 rule skipped the
    correct boundary and landed on the previous helper at 0x006345B0.  Candidates now
    require >=4 CC bytes *and* a normal x64 function-entry shape, preventing that regression.
    """
    start, raw, call_rva = _window_bytes(evidence)
    call_idx = call_rva - start
    if not (0 <= call_idx <= len(raw)):
        raise ValueError("Call RVA is outside the captured code window")
    best: tuple[int, int] | None = None

    def credible_prologue(idx: int) -> bool:
        # Current logical entry starts by spilling RDX/RCX, saving non-volatiles, then
        # establishing a large frame.  Keep wildcards for the two stack spill offsets.
        if idx + 15 > len(raw):
            return False
        b = raw[idx:idx + 15]
        return (
            b[0:4] == bytes.fromhex("48895424")
            and b[5:9] == bytes.fromhex("48894C24")
            and b[10:15] == bytes.fromhex("5553564155")
        )

    i = 0
    while i < call_idx:
        if raw[i] != 0xCC:
            i += 1
            continue
        j = i
        while j < call_idx and raw[j] == 0xCC:
            j += 1
        if j - i >= min_padding and j < call_idx and credible_prologue(j):
            best = (i, j)
        i = j
    if best is None:
        raise ValueError("No compiler-padding function boundary found before the call")
    pad_start, fn_idx = best
    fn_rva = start + fn_idx
    return {
        "status": "candidate-from-int3-padding",
        "function_start_rva_hex": _hex(fn_rva),
        "padding_start_rva_hex": _hex(start + pad_start),
        "padding_byte_count": fn_idx - pad_start,
        "prologue_hex": raw[fn_idx:fn_idx + 40].hex().upper(),
        "distance_to_root_add_call": call_rva - fn_rva,
    }


def analyze_descriptor_flow(evidence: dict[str, Any], function_start_rva: int) -> dict[str, Any]:
    start, raw, call_rva = _window_bytes(evidence)
    a = max(0, function_start_rva - start)
    b = min(len(raw), call_rva - start + 5)
    body = raw[a:b]

    def hits(pattern_hex: str) -> list[int]:
        pattern = bytes.fromhex(pattern_hex)
        out: list[int] = []
        pos = 0
        while True:
            idx = body.find(pattern, pos)
            if idx < 0:
                return out
            out.append(function_start_rva + idx)
            pos = idx + 1

    # Current build facts. These are byte-pattern observations, not guessed symbol names.
    seed_reads = hits("0F108638010000")          # movups xmm0,[rsi+0x138]
    use_seed_checks = hits("4438B640010000")     # cmp [rsi+0x140],r14b
    descriptor_leas = hits("488DBE28010000")     # lea rdi,[rsi+0x128]
    second_arg_copy = hits("488BF2")              # mov rsi,rdx

    return {
        "second_argument_copied_to_rsi": bool(second_arg_copy),
        "second_argument_copy_rvas": [_hex(x) for x in second_arg_copy[:4]],
        "descriptor_offset_from_second_argument_hex": "00000128" if descriptor_leas else None,
        "descriptor_lea_rvas": [_hex(x) for x in descriptor_leas],
        "primary_seed_offset_from_second_argument_hex": "00000138" if seed_reads else None,
        "primary_seed_offset_from_descriptor_hex": "00000010" if seed_reads and descriptor_leas else None,
        "primary_seed_read_rvas": [_hex(x) for x in seed_reads],
        "use_seed_flag_offset_from_second_argument_hex": "00000140" if use_seed_checks else None,
        "use_seed_flag_offset_from_descriptor_hex": "00000018" if use_seed_checks and descriptor_leas else None,
        "use_seed_flag_check_rvas": [_hex(x) for x in use_seed_checks],
        "seed_observed_before_root_add": bool(seed_reads and min(seed_reads) < call_rva),
        "interpretation": "The caller reads the embedded descriptor seed before the root Engine::AddResource call; seed construction is upstream of this function." if seed_reads and min(seed_reads) < call_rva else "Descriptor flow pattern not fully recognized in this build.",
    }


def _read_section(path: Path, section: dict[str, int | str]) -> bytes:
    with path.open("rb") as fh:
        fh.seek(int(section["raw_offset"]))
        raw = fh.read(int(section["raw_size"]))
    if len(raw) != int(section["raw_size"]):
        raise ValueError("Could not read complete PE section")
    return raw


def find_rel32_references(section_raw: bytes, section_rva: int, target_rva: int) -> list[dict[str, Any]]:
    """Return direct E8 call / E9 jump byte references whose rel32 target equals target_rva."""
    out: list[dict[str, Any]] = []
    for idx in range(0, max(0, len(section_raw) - 4)):
        opcode = section_raw[idx]
        if opcode not in (0xE8, 0xE9):
            continue
        disp = int.from_bytes(section_raw[idx + 1:idx + 5], "little", signed=True)
        source_rva = section_rva + idx
        dest = (source_rva + 5 + disp) & 0xFFFFFFFFFFFFFFFF
        if dest == target_rva:
            out.append({
                "kind": "call-rel32" if opcode == 0xE8 else "jump-rel32",
                "instruction_rva_hex": _hex(source_rva),
                "return_or_next_rva_hex": _hex(source_rva + 5),
                "target_rva_hex": _hex(target_rva),
            })
    return out


def _capture_from_section(section_raw: bytes, section_rva: int, center_rva: int, before: int, after: int) -> dict[str, Any]:
    idx = center_rva - section_rva
    a = max(0, idx - max(0, before))
    b = min(len(section_raw), idx + max(5, after))
    raw = section_raw[a:b]
    return {
        "start_rva_hex": _hex(section_rva + a),
        "center_rva_hex": _hex(center_rva),
        "center_index": idx - a,
        "end_rva_exclusive_hex": _hex(section_rva + b),
        "byte_count": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes_hex": raw.hex().upper(),
    }


def extract(evidence_path: Path, exe_path: Path, before: int = DEFAULT_BEFORE, after: int = DEFAULT_AFTER) -> dict[str, Any]:
    evidence = _read_json(evidence_path)
    boundary = find_function_start_from_padding(evidence)
    target_rva = int(boundary["function_start_rva_hex"], 16)
    flow = analyze_descriptor_flow(evidence, target_rva)

    timestamp, sections = caller.parse_pe_sections(exe_path)
    text_section = next((s for s in sections if str(s.get("name")) == ".text"), None)
    if text_section is None:
        raise ValueError("NMS.exe has no .text section")
    text_raw = _read_section(exe_path, text_section)
    text_rva = int(text_section["virtual_address"])
    refs = find_rel32_references(text_raw, text_rva, target_rva)
    for item in refs:
        src = int(item["instruction_rva_hex"], 16)
        item["code_window"] = _capture_from_section(text_raw, text_rva, src, before, after)

    return {
        "version": 1,
        "tool_version": TOOL_VERSION,
        "source_caller_evidence": evidence_path.name,
        "source_session_id": evidence.get("source_session_id"),
        "universe_address_hex": evidence.get("universe_address_hex"),
        "dungeon_root_seed_hex": evidence.get("dungeon_root_seed_hex"),
        "nms_exe": {
            "file_name": exe_path.name,
            "file_size": exe_path.stat().st_size,
            "sha256": caller.sha256_file(exe_path),
            "pe_timestamp_hex": f"{timestamp:08X}",
        },
        "root_add_call_rva_hex": evidence.get("call_instruction_rva_hex"),
        "containing_function": boundary,
        "descriptor_flow": flow,
        "direct_rel32_reference_count": len(refs),
        "direct_rel32_references": refs,
        "interpretation": "Offline xref scan for callers/tail-jumps into the logical entry identified by compiler padding plus a validated x64 prologue. The earlier v0.3.26 scan skipped a four-byte INT3 boundary and targeted the previous helper; v0.3.31 corrects that regression. Candidate references remain static byte evidence, not named-symbol claims.",
    }


def default_output() -> Path:
    local = os.environ.get("LOCALAPPDATA")
    if local:
        return Path(local) / "NMSDerelictSurveyor" / "asset-work-v1" / "dungeon-upstream-callers-latest.json"
    return Path.cwd() / "dungeon-upstream-callers-latest.json"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--caller-evidence", help="dungeon-caller-code-latest.json")
    ap.add_argument("--exe", help="NMS.exe; normally auto-detected")
    ap.add_argument("--before", type=int, default=DEFAULT_BEFORE)
    ap.add_argument("--after", type=int, default=DEFAULT_AFTER)
    ap.add_argument("--out", help="output JSON path")
    args = ap.parse_args(argv)

    evidence = find_input(args.caller_evidence)
    exe = caller.find_nms_exe(args.exe)
    out = Path(args.out).expanduser() if args.out else default_output()
    out.parent.mkdir(parents=True, exist_ok=True)
    result = extract(evidence, exe, max(128, args.before), max(64, args.after))
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    print(f"NMS Derelict Surveyor v{TOOL_VERSION} - offline upstream caller scan")
    print(f"Containing function candidate: 0x{result['containing_function']['function_start_rva_hex']}")
    print(f"Seed read before root AddResource: {result['descriptor_flow']['seed_observed_before_root_add']}")
    print(f"Direct rel32 references: {result['direct_rel32_reference_count']}")
    for ref in result["direct_rel32_references"]:
        print(f"  {ref['kind']}: 0x{ref['instruction_rva_hex']} -> 0x{ref['target_rva_hex']}")
    print(f"\nCreated: {out}")
    print("Use 'Extract upstream callers + upload' or send this JSON to ChatGPT. No NMS run is needed.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
