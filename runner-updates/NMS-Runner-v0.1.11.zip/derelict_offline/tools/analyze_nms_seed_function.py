#!/usr/bin/env python3
"""Offline structural analysis of the NMS function surrounding the derelict root AddResource call.

Read-only. Uses PE unwind metadata (.pdata) to identify the runtime fragment that contains
the root AddResource call, but does not confuse that fragment with the logical C++ function
entry. It separately recovers the logical entry from compiler padding + prologue evidence,
scans the known entry-to-root prefix for seed reads/writes, and searches for direct xrefs.
No game launch is required.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import struct
from pathlib import Path
from typing import Any

try:
    import extract_nms_caller_code as caller
except ModuleNotFoundError:
    import importlib.util
    _spec = importlib.util.spec_from_file_location("extract_nms_caller_code", Path(__file__).with_name("extract_nms_caller_code.py"))
    if _spec is None or _spec.loader is None:
        raise
    caller = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(caller)


try:
    import extract_nms_upstream_callers as upstream
except ModuleNotFoundError:
    import importlib.util as _importlib_util
    _uspec = _importlib_util.spec_from_file_location("extract_nms_upstream_callers", Path(__file__).with_name("extract_nms_upstream_callers.py"))
    if _uspec is None or _uspec.loader is None:
        raise
    upstream = _importlib_util.module_from_spec(_uspec)
    _uspec.loader.exec_module(upstream)

TOOL_VERSION = "0.3.33"
OFFSETS = {0x128: "descriptor", 0x138: "primary_seed", 0x140: "use_seed_flag"}


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _hex(v: int) -> str:
    return f"{v:08X}"


def find_input(explicit: str | None = None) -> Path:
    if explicit:
        p = Path(explicit).expanduser()
        if p.is_file():
            return p
        raise FileNotFoundError(f"Upstream evidence not found: {p}")
    local = os.environ.get("LOCALAPPDATA")
    if local:
        p = Path(local) / "NMSDerelictSurveyor" / "asset-work-v1" / "dungeon-upstream-callers-latest.json"
        if p.is_file():
            return p
    raise FileNotFoundError("dungeon-upstream-callers-latest.json was not found. Run Extract upstream callers first.")


def find_caller_evidence(upstream_path: Path, upstream_evidence: dict[str, Any]) -> Path | None:
    name = str(upstream_evidence.get("source_caller_evidence") or "dungeon-caller-code-latest.json")
    candidates = [upstream_path.with_name(name)]
    local = os.environ.get("LOCALAPPDATA")
    if local:
        candidates.append(Path(local) / "NMSDerelictSurveyor" / "asset-work-v1" / name)
    for p in candidates:
        if p.is_file():
            return p
    return None

def _parse_pe(path: Path) -> tuple[int, int, list[dict[str, int | str]]]:
    """Return timestamp, preferred image base and section table."""
    with path.open("rb") as f:
        dos = f.read(0x40)
        if len(dos) < 0x40 or dos[:2] != b"MZ":
            raise ValueError("Not a PE executable")
        pe_off = struct.unpack_from("<I", dos, 0x3C)[0]
        f.seek(pe_off)
        hdr = f.read(24)
        if len(hdr) != 24 or hdr[:4] != b"PE\0\0":
            raise ValueError("Missing PE signature")
        _, section_count, timestamp, _, _, opt_size, _ = struct.unpack("<HHIIIHH", hdr[4:24])
        opt = f.read(opt_size)
        if len(opt) != opt_size:
            raise ValueError("Truncated PE optional header")
        magic = struct.unpack_from("<H", opt, 0)[0]
        if magic == 0x20B:  # PE32+
            image_base = struct.unpack_from("<Q", opt, 24)[0]
        elif magic == 0x10B:
            image_base = struct.unpack_from("<I", opt, 28)[0]
        else:
            raise ValueError(f"Unsupported PE optional-header magic 0x{magic:X}")
        sections: list[dict[str, int | str]] = []
        for _ in range(section_count):
            sh = f.read(40)
            if len(sh) != 40:
                raise ValueError("Truncated PE section table")
            name = sh[:8].split(b"\0", 1)[0].decode("ascii", errors="replace")
            virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from("<IIII", sh, 8)
            characteristics = struct.unpack_from("<I", sh, 36)[0]
            sections.append({
                "name": name,
                "virtual_size": virtual_size,
                "virtual_address": virtual_address,
                "raw_size": raw_size,
                "raw_offset": raw_offset,
                "characteristics": characteristics,
            })
    return timestamp, image_base, sections


def _read_section(path: Path, s: dict[str, int | str]) -> bytes:
    with path.open("rb") as f:
        f.seek(int(s["raw_offset"]))
        raw = f.read(int(s["raw_size"]))
    if len(raw) != int(s["raw_size"]):
        raise ValueError(f"Could not read section {s['name']}")
    return raw


def _read_rva(path: Path, sections: list[dict[str, int | str]], rva: int, size: int) -> bytes:
    s = caller.section_for_rva(sections, rva)
    va = int(s["virtual_address"])
    off = int(s["raw_offset"]) + (rva - va)
    max_n = int(s["raw_size"]) - (rva - va)
    n = min(size, max_n)
    if n <= 0:
        return b""
    with path.open("rb") as f:
        f.seek(off)
        return f.read(n)


def find_runtime_function(path: Path, sections: list[dict[str, int | str]], rva: int) -> dict[str, Any] | None:
    pdata = next((s for s in sections if str(s.get("name")) == ".pdata"), None)
    if pdata is None:
        return None
    raw = _read_section(path, pdata)
    for off in range(0, len(raw) - 11, 12):
        begin, end, unwind = struct.unpack_from("<III", raw, off)
        if begin <= rva < end and end > begin:
            return {
                "begin_rva_hex": _hex(begin),
                "end_rva_exclusive_hex": _hex(end),
                "byte_count": end - begin,
                "unwind_info_rva_hex": _hex(unwind),
                "pdata_entry_rva_hex": _hex(int(pdata["virtual_address"]) + off),
            }
    return None


def find_rel32_refs(raw: bytes, base_rva: int, target_rva: int, fn_begin: int, fn_end: int) -> list[dict[str, Any]]:
    out=[]
    for i in range(0, max(0, len(raw)-4)):
        op=raw[i]
        if op not in (0xE8,0xE9):
            continue
        disp=int.from_bytes(raw[i+1:i+5],"little",signed=True)
        src=base_rva+i
        dest=(src+5+disp)&0xFFFFFFFFFFFFFFFF
        if dest != target_rva:
            continue
        out.append({
            "kind":"call-rel32" if op==0xE8 else "jump-rel32",
            "instruction_rva_hex":_hex(src),
            "target_rva_hex":_hex(target_rva),
            "source_inside_target_function": fn_begin <= src < fn_end,
        })
    return out


def scan_disp_references(fn_raw: bytes, fn_begin: int) -> list[dict[str, Any]]:
    out=[]
    for disp,label in OFFSETS.items():
        needle=struct.pack("<I",disp)
        pos=0
        while True:
            i=fn_raw.find(needle,pos)
            if i<0: break
            a=max(0,i-12); b=min(len(fn_raw),i+16)
            out.append({
                "field":label,
                "displacement_hex":f"{disp:08X}",
                "displacement_rva_hex":_hex(fn_begin+i),
                "instruction_context_start_rva_hex":_hex(fn_begin+a),
                "context_hex":fn_raw[a:b].hex().upper(),
                "possible_memory_write": _looks_like_write(fn_raw, i),
            })
            pos=i+1
    out.sort(key=lambda x:int(x["displacement_rva_hex"],16))
    return out


def _looks_like_write(raw: bytes, disp_index: int) -> bool:
    """Conservative classifier for common x64 stores using mod=10,r/m=RSI + disp32."""
    # ModRM immediately before disp32 for common opcodes. We only return true on recognizable stores.
    if disp_index < 2:
        return False
    modrm=raw[disp_index-1]
    if (modrm & 0xC7) != 0x86:  # mod=10, r/m=110 (RSI)
        return False
    # Walk back over REX/prefixes only far enough for common encodings.
    prefixes={0x66,0xF2,0xF3}
    j=disp_index-2
    if 0x40 <= raw[j] <= 0x4F:
        j-=1
    if j>=0 and raw[j] in (0x88,0x89,0xC6,0xC7):
        return True
    if j>=1 and raw[j-1]==0x0F and raw[j] in (0x11,0x29,0x7F):
        return True
    if j>=2 and raw[j-2] in prefixes and raw[j-1]==0x0F and raw[j] in (0x11,0x29,0x7F):
        return True
    return False


def scan_function_pointer_refs(path: Path, sections: list[dict[str, int | str]], image_base: int, fn_rva: int) -> list[dict[str, Any]]:
    target_va=image_base+fn_rva
    va_needle=struct.pack("<Q",target_va)
    rva_needle=struct.pack("<I",fn_rva)
    out=[]
    for s in sections:
        name=str(s["name"])
        if name==".text":
            continue
        raw=_read_section(path,s)
        va=int(s["virtual_address"])
        for encoding,needle in (("absolute-va64",va_needle),("rva32",rva_needle)):
            pos=0
            while True:
                i=raw.find(needle,pos)
                if i<0: break
                # Suppress the expected .pdata begin-address entry from the more interesting pointer list.
                out.append({
                    "section":name,
                    "encoding":encoding,
                    "reference_rva_hex":_hex(va+i),
                    "context_hex":raw[max(0,i-24):min(len(raw),i+40)].hex().upper(),
                })
                pos=i+1
    return out


def _rva_to_file_bytes(path: Path, sections: list[dict[str, int | str]], rva: int, size: int) -> bytes:
    try:
        return _read_rva(path, sections, rva, size)
    except Exception:
        return b""


def parse_msvc_rtti_for_pointer(path: Path, sections: list[dict[str, int | str]], image_base: int, pointer_ref: dict[str, Any]) -> dict[str, Any] | None:
    """Best-effort MSVC x64 vftable/RTTI recovery around an absolute function pointer slot."""
    if pointer_ref.get("encoding") != "absolute-va64":
        return None
    slot_rva=int(pointer_ref["reference_rva_hex"],16)
    # Walk backwards over contiguous text VAs to a likely first vftable slot.
    first=slot_rva
    for _ in range(64):
        prev=first-8
        q=_rva_to_file_bytes(path,sections,prev,8)
        if len(q)!=8: break
        val=struct.unpack("<Q",q)[0]
        rva=val-image_base
        try:
            s=caller.section_for_rva(sections,rva)
        except Exception:
            break
        if str(s.get("name")) != ".text":
            break
        first=prev
    colq=_rva_to_file_bytes(path,sections,first-8,8)
    if len(colq)!=8:
        return None
    col_va=struct.unpack("<Q",colq)[0]
    col_rva=col_va-image_base
    col=_rva_to_file_bytes(path,sections,col_rva,24)
    if len(col)<24:
        return None
    sig,off,cd,type_rva,class_rva,self_rva=struct.unpack("<IIIIII",col)
    if sig not in (0,1) or type_rva==0:
        return None
    td=_rva_to_file_bytes(path,sections,type_rva,256)
    if len(td)<17:
        return None
    name_bytes=td[16:].split(b"\0",1)[0]
    if not name_bytes.startswith(b".?"):
        return None
    try:
        name=name_bytes.decode("ascii",errors="replace")
    except Exception:
        return None
    return {
        "vftable_first_slot_rva_hex":_hex(first),
        "function_slot_index":(slot_rva-first)//8,
        "complete_object_locator_rva_hex":_hex(col_rva),
        "type_descriptor_rva_hex":_hex(type_rva),
        "mangled_type_name":name,
        "col_signature":sig,
        "col_offset":off,
        "col_cd_offset":cd,
        "class_descriptor_rva_hex":_hex(class_rva),
        "col_self_rva_hex":_hex(self_rva),
    }


def extract(evidence_path: Path, exe_path: Path) -> dict[str, Any]:
    evidence=_read_json(evidence_path)
    root_call=int(str(evidence.get("root_add_call_rva_hex") or "0"),16)
    previous_candidate=int(str((evidence.get("containing_function") or {}).get("function_start_rva_hex") or "0"),16)
    if not root_call:
        raise ValueError("Upstream evidence has no usable root call")
    timestamp,image_base,sections=_parse_pe(exe_path)
    rf=find_runtime_function(exe_path,sections,root_call)
    if rf is None:
        raise ValueError("PE .pdata did not contain a runtime-function entry for the root AddResource call")
    frag_begin=int(rf["begin_rva_hex"],16); frag_end=int(rf["end_rva_exclusive_hex"],16)
    frag_raw=_read_rva(exe_path,sections,frag_begin,frag_end-frag_begin)
    if len(frag_raw)!=(frag_end-frag_begin):
        raise ValueError("Could not read complete root runtime fragment bytes")

    logical = None
    caller_evidence_path=find_caller_evidence(evidence_path,evidence)
    if caller_evidence_path:
        logical=upstream.find_function_start_from_padding(_read_json(caller_evidence_path))
    logical_begin=int(logical["function_start_rva_hex"],16) if logical else previous_candidate
    if not logical_begin:
        raise ValueError("Could not recover the logical function entry")

    text=caller.section_for_rva(sections,logical_begin)
    text_raw=_read_section(exe_path,text); text_rva=int(text["virtual_address"])
    # The entry->root prefix is enough to prove the pre-AddResource seed read and to
    # search for direct writes without pretending the .pdata fragment is the whole function.
    prefix_end=root_call+5
    prefix_raw=_read_rva(exe_path,sections,logical_begin,prefix_end-logical_begin)
    disprefs=scan_disp_references(prefix_raw,logical_begin)
    relrefs=find_rel32_refs(text_raw,text_rva,logical_begin,logical_begin,prefix_end)
    ptrrefs=scan_function_pointer_refs(exe_path,sections,image_base,logical_begin)
    rtti=[]
    for ref in ptrrefs:
        parsed=parse_msvc_rtti_for_pointer(exe_path,sections,image_base,ref)
        if parsed and parsed not in rtti:
            rtti.append(parsed)
    return {
        "version":1,
        "tool_version":TOOL_VERSION,
        "source_upstream_evidence":evidence_path.name,
        "source_session_id":evidence.get("source_session_id"),
        "universe_address_hex":evidence.get("universe_address_hex"),
        "dungeon_root_seed_hex":evidence.get("dungeon_root_seed_hex"),
        "nms_exe":{
            "file_name":exe_path.name,
            "file_size":exe_path.stat().st_size,
            "sha256":caller.sha256_file(exe_path),
            "pe_timestamp_hex":f"{timestamp:08X}",
            "preferred_image_base_hex":f"{image_base:016X}",
        },
        "root_add_call_rva_hex":_hex(root_call),
        "previous_padding_candidate_rva_hex":_hex(previous_candidate) if previous_candidate else None,
        "logical_function_entry": logical,
        "root_runtime_fragment":rf,
        "root_fragment_is_logical_entry":logical_begin==frag_begin,
        "root_runtime_fragment_sha256":hashlib.sha256(frag_raw).hexdigest(),
        "root_runtime_fragment_bytes_hex":frag_raw.hex().upper(),
        "known_prefix_start_rva_hex":_hex(logical_begin),
        "known_prefix_end_rva_exclusive_hex":_hex(prefix_end),
        "known_prefix_sha256":hashlib.sha256(prefix_raw).hexdigest(),
        "direct_references_to_logical_entry":relrefs,
        "outside_known_prefix_direct_reference_count":sum(1 for x in relrefs if not x["source_inside_target_function"]),
        "inside_known_prefix_direct_reference_count":sum(1 for x in relrefs if x["source_inside_target_function"]),
        "descriptor_field_references":disprefs,
        "possible_descriptor_field_writes":[x for x in disprefs if x["possible_memory_write"]],
        "nontext_function_pointer_references":ptrrefs,
        "msvc_rtti_candidates":rtti,
        "interpretation":(
            "PE .pdata is authoritative for the runtime fragment containing the root call, not necessarily the logical C++ function entry. "
            "v0.3.31 separately recovers the logical entry from compiler padding plus prologue evidence and scans the entry-to-root prefix. "
            "Descriptor-field occurrences are byte-level evidence only; possible writes are conservative common-store matches. "
            "RTTI recovery remains best-effort."
        ),
    }


def default_output() -> Path:
    local=os.environ.get("LOCALAPPDATA")
    if local:
        return Path(local)/"NMSDerelictSurveyor"/"asset-work-v1"/"dungeon-seed-function-analysis-latest.json"
    return Path.cwd()/"dungeon-seed-function-analysis-latest.json"


def main(argv: list[str] | None=None) -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--upstream-evidence")
    ap.add_argument("--exe")
    ap.add_argument("--out")
    args=ap.parse_args(argv)
    evidence=find_input(args.upstream_evidence)
    exe=caller.find_nms_exe(args.exe)
    out=Path(args.out).expanduser() if args.out else default_output()
    out.parent.mkdir(parents=True,exist_ok=True)
    result=extract(evidence,exe)
    out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    rf=result["root_runtime_fragment"]
    logical=result.get("logical_function_entry") or {}
    print(f"NMS Derelict Surveyor v{TOOL_VERSION} - seed function analysis")
    print(f"Logical entry: 0x{logical.get('function_start_rva_hex','UNKNOWN')}")
    print(f"Root .pdata fragment: 0x{rf['begin_rva_hex']}..0x{rf['end_rva_exclusive_hex']}")
    print(f"Root fragment is logical entry: {result['root_fragment_is_logical_entry']}")
    print(f"Direct refs outside known prefix: {result['outside_known_prefix_direct_reference_count']}")
    print(f"Possible descriptor-field writes: {len(result['possible_descriptor_field_writes'])}")
    print(f"RTTI candidates: {len(result['msvc_rtti_candidates'])}")
    print(f"Created: {out}")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
