#!/usr/bin/env python3
"""Parse the extracted current NMS FREIGHTERDUNGEONSTABLE into compact JSON.

The parser is intentionally schema-tolerant. It normalizes fields that are useful
for the offline derelict generator while retaining every source property as a raw
tree so unknown/current rule types are never silently discarded.
"""
from __future__ import annotations

import argparse
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Iterable

TABLE_STEM = "FREIGHTERDUNGEONSTABLE"


def _num(value: str | None) -> Any:
    if value is None:
        return None
    s = value.strip()
    if not s:
        return ""
    if re.fullmatch(r"[-+]?\d+", s):
        try:
            return int(s)
        except ValueError:
            pass
    if re.fullmatch(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?", s):
        try:
            return float(s)
        except ValueError:
            pass
    lo = s.lower()
    if lo == "true":
        return True
    if lo == "false":
        return False
    return s


def prop_to_obj(el: ET.Element) -> dict[str, Any]:
    return {
        "name": el.attrib.get("name"),
        "value": _num(el.attrib.get("value")),
        "children": [prop_to_obj(c) for c in el if c.tag.lower().endswith("property")],
    }


def cf(s: str | None) -> str:
    return (s or "").replace("_", "").lower()


def child_named(node: dict[str, Any], *names: str) -> dict[str, Any] | None:
    wanted = {cf(n) for n in names}
    for c in node.get("children", []):
        if cf(c.get("name")) in wanted:
            return c
    return None


def children_named(node: dict[str, Any], *names: str) -> list[dict[str, Any]]:
    wanted = {cf(n) for n in names}
    return [c for c in node.get("children", []) if cf(c.get("name")) in wanted]


def scalar(node: dict[str, Any], *names: str, default=None):
    c = child_named(node, *names)
    return c.get("value") if c else default


def list_values(node: dict[str, Any] | None) -> list[Any]:
    if not node:
        return []
    out: list[Any] = []
    for c in node.get("children", []):
        if c.get("children"):
            v = scalar(c, "Value", "RoomID", "RoomId", "Name", "ID")
            if v is None and c.get("value") not in (None, "") and not str(c.get("value")).endswith(".xml"):
                v = c.get("value")
            if v is not None:
                out.append(v)
        elif c.get("value") is not None:
            out.append(c.get("value"))
    return out


def parse_room_types(params: dict[str, Any]) -> list[dict[str, Any]]:
    holder = child_named(params, "MainRoomTypes")
    if not holder:
        return []
    out=[]
    for item in holder.get("children", []):
        out.append({
            "room_id": scalar(item, "RoomID", "RoomId", "RoomIDValue"),
            "branch_probability": scalar(item, "BranchProbability"),
            "raw_type": item.get("value"),
            "raw": item,
        })
    return out


def _type_name(value: Any) -> str:
    s = str(value or "")
    return s[:-4] if s.lower().endswith(".xml") else s


def unwrap_typed_payload(item: dict[str, Any]) -> dict[str, Any]:
    """Return the rule payload across both flat and Cosmos nested MXML shapes.

    Current Cosmos output wraps rules as:
      GenerationRules(value=GcRoomCountRule) -> GcRoomCountRule -> fields
    while older/synthetic output may place the fields directly under the first node.
    """
    children = item.get("children", [])
    rule_type = _type_name(item.get("value"))
    if len(children) == 1:
        only = children[0]
        if cf(only.get("name")) == cf(rule_type) or cf(only.get("value")) == cf(rule_type):
            return only
    return item


def parse_rules(params: dict[str, Any]) -> list[dict[str, Any]]:
    holder = child_named(params, "GenerationRules")
    if not holder:
        return []
    out=[]
    for item in holder.get("children", []):
        rule_type = _type_name(item.get("value"))
        low = rule_type.lower()
        payload = unwrap_typed_payload(item)
        norm: dict[str, Any] = {"type": rule_type, "raw": item}
        if "roomcountrule" in low:
            norm.update({
                "room_id": scalar(payload, "RoomID", "RoomId"),
                "min": scalar(payload, "Min"),
                "max": scalar(payload, "Max"),
            })
        elif "roomsequencerule" in low:
            norm.update({
                "room_id": scalar(payload, "RoomID", "RoomId"),
                "min_room_index": scalar(payload, "MinRoomIndex"),
                "must_be_before_room": scalar(payload, "MustBeBeforeRoom"),
                "must_be_after_room": scalar(payload, "MustBeAfterRoom"),
            })
        elif "questitemplacementrule" in low:
            norm.update({
                "quest_item_id": scalar(payload, "QuestItemID"),
                "min_room_index": scalar(payload, "MinRoomIndex"),
                "max_room_index": scalar(payload, "MaxRoomIndex"),
                "must_be_before_quest_item": scalar(payload, "MustBeBeforeQuestItem"),
                "must_be_after_quest_item": scalar(payload, "MustBeAfterQuestItem"),
                "valid_room_ids": list_values(child_named(payload, "ValidRoomIDs")),
            })
        else:
            # Preserve generic fields for current/future unknown rules.
            norm["fields"] = prop_to_compact(payload) if payload.get("children") else {}
        out.append(norm)
    return out


def normalize_dungeon(item: dict[str, Any]) -> dict[str, Any]:
    params = child_named(item, "DungeonParams") or item
    return {
        "name": scalar(item, "Name", "ID"),
        "size": {
            "x": scalar(params, "SizeX"),
            "y": scalar(params, "SizeY"),
            "z": scalar(params, "SizeZ"),
        },
        "entrance": {
            "x": scalar(params, "EntranceX"),
            "y": scalar(params, "EntranceY"),
            "z": scalar(params, "EntranceZ"),
        },
        "rooms": scalar(params, "Rooms"),
        "probability": {
            "x": scalar(params, "XProbability"),
            "y": scalar(params, "YProbability"),
            "z": scalar(params, "ZProbability"),
            "straight": scalar(params, "StraightProbability"),
            "straight_multiplier": scalar(params, "StraightMultiplier"),
        },
        "main_room_types": parse_room_types(params),
        "branch_room_types": list_values(child_named(params, "BranchRoomTypes")),
        "quests": [prop_to_compact(q) for q in (child_named(params, "Quests") or {}).get("children", [])],
        "generation_rules": parse_rules(params),
        "pruning_rules": list_values(child_named(params, "PruningRules")),
        "raw": item,
    }


def prop_to_compact(node: dict[str, Any]) -> Any:
    if not node.get("children"):
        return node.get("value")
    out: dict[str, Any] = {}
    for c in node.get("children", []):
        k = c.get("name") or str(c.get("value") or "item")
        v = prop_to_compact(c)
        if k in out:
            if not isinstance(out[k], list):
                out[k] = [out[k]]
            out[k].append(v)
        else:
            out[k] = v
    if node.get("value") not in (None, ""):
        out["__type__"] = node.get("value")
    return out


def find_table(root: Path) -> Path:
    if root.is_file():
        return root
    candidates=[]
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        u=p.name.upper()
        if TABLE_STEM in u and p.suffix.upper() in {".MXML", ".EXML", ".XML"}:
            candidates.append(p)
    if not candidates:
        # MBINCompiler sometimes emits .MBIN.MXML.
        for p in root.rglob("*"):
            if p.is_file() and TABLE_STEM in p.name.upper() and "MXML" in p.name.upper():
                candidates.append(p)
    if not candidates:
        raise SystemExit(
            f"Could not find a decompiled {TABLE_STEM} MXML/EXML under {root}. "
            "Run Prepare-Crate-Assets.cmd first."
        )
    return sorted(candidates, key=lambda p: len(str(p)))[0]


def iter_dungeon_items(tree_root: ET.Element) -> Iterable[ET.Element]:
    # Standard MBINCompiler MXML: Data -> Property name=Dungeons -> Property value=GcFreighterDungeonParams.xml
    for el in tree_root.iter():
        if not el.tag.lower().endswith("property"):
            continue
        v=(el.attrib.get("value") or "").lower()
        if "gcfreighterdungeonparams" in v:
            yield el


def main(argv=None) -> int:
    ap=argparse.ArgumentParser(description="Parse current NMS freighter dungeon generation table")
    ap.add_argument("root", type=Path, help="asset-work extracted folder or FREIGHTERDUNGEONSTABLE MXML")
    ap.add_argument("--output", type=Path, required=True)
    args=ap.parse_args(argv)
    path=find_table(args.root)
    tree=ET.parse(path)
    doc=tree.getroot()
    raw_root=prop_to_obj(doc) if doc.tag.lower().endswith("property") else {
        "name": doc.attrib.get("template") or doc.tag,
        "value": doc.attrib.get("template"),
        "children": [prop_to_obj(c) for c in doc if c.tag.lower().endswith("property")],
    }
    items=[prop_to_obj(el) for el in iter_dungeon_items(doc)]
    dungeons=[normalize_dungeon(i) for i in items]
    # Fallback: if type annotations are absent, use children under Dungeons.
    if not dungeons:
        dholder=child_named(raw_root,"Dungeons")
        if dholder:
            dungeons=[normalize_dungeon(i) for i in dholder.get("children", [])]
    out={
        "version":1,
        "source":str(path),
        "dungeon_count":len(dungeons),
        "dungeons":dungeons,
        "raw_table":raw_root,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding="utf-8")
    print(f"Parsed {len(dungeons)} dungeon presets -> {args.output}")
    for d in dungeons:
        print(f"  {d.get('name')}: rooms={d.get('rooms')} size={d.get('size')} rules={len(d.get('generation_rules',[]))}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
