#!/usr/bin/env python3
"""Store compact derelict generation measurements and rebuild comparison outputs."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def compact_row(d: dict[str, Any]) -> dict[str, Any]:
    reward_seeds=sorted({str(x.get("seed_hex") or "") for x in d.get("reward_seed_candidates",[]) if x.get("seed_hex")})
    dungeon_root_seeds=sorted({str(x.get("seed_hex") or "") for x in d.get("dungeon_root_seed_candidates",[]) if x.get("seed_hex")})
    poi_seeds=sorted({str(x.get("raw_argument_hex") or "") for x in d.get("poi_seed_candidates",[]) if x.get("raw_argument_hex")})
    lineage=d.get("resource_seed_lineage") or {}
    lineage_primary=[str(x) for x in (lineage.get("unique_primary_seed_hexes") or []) if x]
    context_lineage=d.get("resource_seed_context_lineage") or {}
    context_lineage_primary=[str(x) for x in (context_lineage.get("unique_primary_seed_hexes") or []) if x]
    poi_generation=d.get("poi_generation_trace") or {}
    poi_return_hexes=[str(x) for x in (poi_generation.get("description_return_hexes") or []) if x]
    ga=d.get("galactic_address") or {}
    room_seq=[
        {
            "order":g.get("generation_order"),
            "stream_order":g.get("stream_order",g.get("generation_order")),
            "room_index":g.get("room_index"),
            "room_label":g.get("room_label"),
            "kind":g.get("room_kind"),
            "family":g.get("dominant_family"),
            "parent_names":g.get("parent_node_names") or [],
            "salvage":g.get("salvage_crates"),
            "footlockers":g.get("crew_footlockers"),
            "targets":g.get("target_containers"),
            "dead_end_evidence":g.get("dead_end_evidence") or [],
        }
        for g in d.get("logical_groups",[])
    ]
    return {
        "session_id":d.get("session_id"),
        "probe_version":d.get("probe_version"),
        "universe_address_hex":d.get("universe_address_hex"),
        "reality_index":d.get("reality_index"),
        "solar_system_index":ga.get("solar_system_index"),
        "voxel_x":ga.get("voxel_x"),
        "voxel_y":ga.get("voxel_y"),
        "voxel_z":ga.get("voxel_z"),
        "preset":(d.get("preset_inference") or {}).get("preset"),
        "preset_confidence":(d.get("preset_inference") or {}).get("confidence"),
        "main_rooms":d.get("observed_main_rooms"),
        "dead_end_rooms":d.get("observed_dead_end_rooms"),
        "total_rooms":d.get("observed_total_rooms",d.get("logical_generated_chunks")),
        "salvage_crates":d.get("predicted_salvage_crates"),
        "crew_footlockers":d.get("predicted_crew_footlockers"),
        "target_containers":d.get("predicted_target_containers"),
        "reward_seed_hexes":reward_seeds,
        "dungeon_root_seed_hexes":dungeon_root_seeds,
        "resource_seed_lineage_signature_sha256":lineage.get("ordered_signature_sha256"),
        "resource_seed_primary_hexes":lineage_primary,
        "resource_seed_context_signature_sha256":context_lineage.get("ordered_signature_sha256"),
        "resource_seed_context_primary_hexes":context_lineage_primary,
        "poi_seed_candidate_hexes":poi_seeds,
        "poi_context_status":d.get("poi_context_status"),
        "poi_description_return_hexes":poi_return_hexes,
        "poi_description_return_matches_root_seed":any(bool(x.get("return_matches_dungeon_root_seed")) for x in (poi_generation.get("description_results") or [])),
        "dungeon_root_inside_poi_prepare":bool(poi_generation.get("dungeon_root_inside_prepare")),
        "dungeon_root_inside_poi_activation":bool(poi_generation.get("dungeon_root_inside_activation")),
        "dungeon_root_inside_poi_lifecycle":bool(poi_generation.get("dungeon_root_inside_lifecycle")),
        "resource_manager_root_event_count":int(poi_generation.get("resource_manager_root_event_count") or 0),
        "dungeon_root_engine_caller_offsets":list(poi_generation.get("dungeon_root_engine_caller_offsets") or []),
        "dungeon_root_manager_caller_offsets":list(poi_generation.get("dungeon_root_manager_caller_offsets") or []),
        "dungeon_root_engine_call_sites":list(poi_generation.get("dungeon_root_engine_call_sites") or []),
        "layout_signature_sha256":d.get("layout_signature_sha256",d.get("generation_signature_sha256")),
        "layout_multiset_signature_sha256":d.get("layout_multiset_signature_sha256"),
        "room_parent_index_coverage":d.get("room_parent_index_coverage"),
        "legacy_stream_signature_sha256":d.get("legacy_stream_signature_sha256"),
        "generation_signature_sha256":d.get("generation_signature_sha256"),
        "room_model_status":d.get("room_model_status"),
        "room_sequence":room_seq,
    }


def rebuild(measurements_dir: Path, summary_path: Path, csv_path: Path) -> dict[str, Any]:
    rows=[]
    for path in sorted(measurements_dir.glob("*.json")):
        try:
            d=load(path)
            if d.get("session_id"):
                rows.append(compact_row(d))
        except Exception:
            continue
    summary={"version":1,"measurement_count":len(rows),"measurements":rows}
    summary_path.parent.mkdir(parents=True,exist_ok=True)
    summary_path.write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding="utf-8")
    fields=["session_id","probe_version","universe_address_hex","solar_system_index","voxel_x","voxel_y","voxel_z","preset","main_rooms","dead_end_rooms","total_rooms","salvage_crates","crew_footlockers","target_containers","reward_seed_hexes","dungeon_root_seed_hexes","resource_seed_lineage_signature_sha256","resource_seed_primary_hexes","resource_seed_context_signature_sha256","resource_seed_context_primary_hexes","poi_seed_candidate_hexes","poi_context_status","poi_description_return_hexes","poi_description_return_matches_root_seed","dungeon_root_inside_poi_prepare","dungeon_root_inside_poi_activation","dungeon_root_inside_poi_lifecycle","resource_manager_root_event_count","dungeon_root_engine_caller_offsets","dungeon_root_manager_caller_offsets","layout_signature_sha256","layout_multiset_signature_sha256","room_parent_index_coverage","legacy_stream_signature_sha256","generation_signature_sha256","room_model_status"]
    with csv_path.open("w",newline="",encoding="utf-8-sig") as fh:
        w=csv.DictWriter(fh,fieldnames=fields)
        w.writeheader()
        for row in rows:
            flat={k:row.get(k) for k in fields}
            flat["reward_seed_hexes"]=";".join(row.get("reward_seed_hexes") or [])
            flat["dungeon_root_seed_hexes"]=";".join(row.get("dungeon_root_seed_hexes") or [])
            flat["resource_seed_primary_hexes"]=";".join(row.get("resource_seed_primary_hexes") or [])
            flat["resource_seed_context_primary_hexes"]=";".join(row.get("resource_seed_context_primary_hexes") or [])
            flat["poi_seed_candidate_hexes"]=";".join(row.get("poi_seed_candidate_hexes") or [])
            flat["poi_description_return_hexes"]=";".join(row.get("poi_description_return_hexes") or [])
            flat["dungeon_root_engine_caller_offsets"]=";".join(row.get("dungeon_root_engine_caller_offsets") or [])
            flat["dungeon_root_manager_caller_offsets"]=";".join(row.get("dungeon_root_manager_caller_offsets") or [])
            w.writerow(flat)
    return summary


def main(argv=None)->int:
    ap=argparse.ArgumentParser(description="Record/rebuild compact derelict generation measurements")
    ap.add_argument("baseline",type=Path,nargs="?")
    ap.add_argument("--measurements-dir",type=Path,required=True)
    ap.add_argument("--summary",type=Path,required=True)
    ap.add_argument("--csv",type=Path,required=True)
    ap.add_argument("--summary-only",action="store_true")
    args=ap.parse_args(argv)
    args.measurements_dir.mkdir(parents=True,exist_ok=True)
    if not args.summary_only:
        if args.baseline is None:
            ap.error("baseline is required unless --summary-only is used")
        d=load(args.baseline)
        sid=str(d.get("session_id") or "unknown-session")
        dest=args.measurements_dir/f"{sid}.json"
        dest.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding="utf-8")
        print(f"Recorded: {dest}")
    summary=rebuild(args.measurements_dir,args.summary,args.csv)
    print(f"Measurements: {summary['measurement_count']}")
    print(f"Summary: {args.summary}")
    print(f"CSV: {args.csv}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
