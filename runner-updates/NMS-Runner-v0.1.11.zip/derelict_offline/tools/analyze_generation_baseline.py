#!/usr/bin/env python3
"""Build a compact derelict-generation research baseline from one captured session.

This intentionally separates proven observations from hypotheses.  It infers a
preset only from concrete streamed scene-family/hazard evidence, groups scene
pieces by their runtime parent handle into logical generated chunks, and uses the
asset crate index to total CRATEM + FOOT_LOCKER containers per chunk.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

DUNGEON_PREFIX = "MODELS/SPACE/POI/DUNGEON/"
DUNGEON_ROOT_SCENE = "MODELS/SPACE/POI/DUNGEON.SCENE.MBIN"
NEUTRAL_FAMILIES = {"EMPTY", "COMM", "SPAWNERS"}
STYLE_FAMILIES = ("CARG", "MEDI")
ANALYSIS_TOOL_VERSION = "0.3.24"


def norm_path(value: str | None) -> str:
    return (value or "").replace("\\", "/").upper()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def decode_direct_callsite(window: dict[str, Any] | None) -> dict[str, Any] | None:
    """Decode the direct rel32 CALL immediately preceding a captured return RVA.

    pyMHF's ``get_caller`` returns the address immediately after the CALL.  For
    the x86-64 ``E8 rel32`` form we can therefore recover both the call
    instruction RVA and its target without a disassembler.  We also recognize
    the exact Windows-x64 argument move used by the observed dungeon-root call:
    ``mov [rsp+0x20], rdi`` means the fifth Engine::AddResource argument
    (the resource descriptor) is passed unchanged from RDI.
    """
    if not isinstance(window, dict):
        return None
    try:
        raw = bytes.fromhex(str(window.get("bytes_hex") or ""))
        idx = int(window.get("return_index"))
        ret = int(str(window.get("return_offset_hex") or "0"), 16)
    except Exception:
        return None
    if idx < 5 or idx > len(raw) or raw[idx - 5] != 0xE8:
        return None
    disp = int.from_bytes(raw[idx - 4:idx], "little", signed=True)
    call_rva = (ret - 5) & 0xFFFFFFFFFFFFFFFF
    target_rva = (ret + disp) & 0xFFFFFFFFFFFFFFFF
    descriptor_register = None
    if idx >= 10 and raw[idx - 10:idx - 5] == bytes.fromhex("48897C2420"):
        descriptor_register = "RDI"
    return {
        "encoding": "E8 rel32",
        "call_instruction_offset_hex": f"{call_rva:08X}",
        "call_target_offset_hex": f"{target_rva:08X}",
        "descriptor_argument_source_register": descriptor_register,
        "descriptor_passed_unchanged_to_engine": descriptor_register is not None,
    }


def scene_family(path: str) -> str | None:
    p = norm_path(path)
    m = re.search(r"/DUNGEON/([^/]+)/", p)
    return m.group(1) if m else None


def dungeon_scene_events(session: dict[str, Any]) -> list[dict[str, Any]]:
    events = session.get("scene_probe", {}).get("events", [])
    out=[]
    for e in events:
        if e.get("kind") != "spawned_node":
            continue
        p = norm_path(e.get("resource_name") or e.get("node_name"))
        if DUNGEON_PREFIX in p:
            x=dict(e)
            x["normalized_resource_name"] = p
            out.append(x)
    return out


def infer_preset(events: list[dict[str, Any]], generation_table: dict[str, Any]) -> dict[str, Any]:
    paths=[e["normalized_resource_name"] for e in events]
    families=Counter(f for p in paths if (f:=scene_family(p)))
    family = None
    family_evidence = {}
    for f in STYLE_FAMILIES:
        family_evidence[f] = families.get(f, 0)
    if family_evidence["CARG"] > 0 and family_evidence["MEDI"] == 0:
        family = "CARGO"
    elif family_evidence["MEDI"] > 0 and family_evidence["CARG"] == 0:
        family = "MEDI"
    elif family_evidence["CARG"] > family_evidence["MEDI"] * 2 and family_evidence["CARG"] > 0:
        family = "CARGO"
    elif family_evidence["MEDI"] > family_evidence["CARG"] * 2 and family_evidence["MEDI"] > 0:
        family = "MEDI"

    joined="\n".join(paths)
    hazard=None
    hazard_evidence=[]
    if "FASTFLOATER" in joined or re.search(r"/SPAWNERS/FLOATER(?:\.|/)", joined):
        hazard="FLOATERS"; hazard_evidence=[p for p in paths if "FLOATER" in p]
    elif any(t in joined for t in ("/SLIME/", "SLIME")):
        hazard="SLIME"; hazard_evidence=[p for p in paths if "SLIME" in p]
    elif any(t in joined for t in ("BUG", "HORROR", "NEST")):
        hazard="BUGS"; hazard_evidence=[p for p in paths if any(t in p for t in ("BUG","HORROR","NEST"))]
    elif "TURRET" in joined:
        hazard="TURRETS"; hazard_evidence=[p for p in paths if "TURRET" in p]

    names=[str(d.get("name") or "") for d in generation_table.get("dungeons", [])]
    expected=f"{family}_{hazard}" if family and hazard else None
    if expected in names:
        candidates=[expected]
        confidence="high"
    else:
        candidates=[]
        for n in names:
            if family and not n.startswith(family+"_"):
                continue
            if hazard and not n.endswith("_"+hazard):
                continue
            candidates.append(n)
        confidence="medium" if len(candidates)==1 else "unresolved"
    return {
        "preset": candidates[0] if len(candidates)==1 else None,
        "confidence": confidence,
        "candidates": candidates,
        "family": family,
        "hazard": hazard,
        "family_scene_counts": family_evidence,
        "all_scene_family_counts": dict(sorted(families.items())),
        "hazard_evidence": sorted(set(hazard_evidence)),
    }


def reward_seeds(session: dict[str, Any]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = {}
    for e in session.get("trace", {}).get("events", []):
        if e.get("kind") != "reward":
            continue
        seed=e.get("seed") or {}
        hx=str(seed.get("seed_hex") or "").upper()
        if not hx or hx == "0000000000000000":
            continue
        key=f"{e.get('reward_id','')}|{hx}"
        row=grouped.setdefault(key, {
            "reward_id": e.get("reward_id", ""),
            "mission_id": e.get("mission_id", ""),
            "seed_hex": hx,
            "seed_u64": seed.get("seed_u64"),
            "use_seed_value": seed.get("use_seed_value"),
            "observations": 0,
        })
        row["observations"] += 1
    return sorted(grouped.values(), key=lambda r:(r["reward_id"],r["seed_hex"]))


def dungeon_root_seeds(session: dict[str, Any], universe_address_hex: str | None = None) -> list[dict[str, Any]]:
    """Collect primary descriptor seeds attached to the derelict dungeon root resource.

    This is deliberately a candidate signal, not a proven layout seed. The
    resource is much closer to room construction than reward seeds are, and the
    verified 51-container raw capture recorded 00C9E8DF0327789E here.
    """
    grouped: dict[str, dict[str, Any]] = {}
    expected_ua = str(universe_address_hex or "").upper().zfill(16)
    for e in session.get("trace", {}).get("events", []):
        if e.get("kind") != "resource_add":
            continue
        if norm_path(e.get("resource_name")) != DUNGEON_ROOT_SCENE:
            continue
        captured_raw = str(e.get("universe_address_hex_at_capture") or "").upper()
        captured_ua = captured_raw.zfill(16) if captured_raw else ""
        if expected_ua and captured_ua and captured_ua != expected_ua:
            continue
        seed = e.get("primary_seed") or {}
        hx = str(seed.get("seed_hex") or "").upper()
        if not hx or hx in ("0000000000000000", "FFFFFFFFFFFFFFFF"):
            continue
        row = grouped.setdefault(hx, {
            "resource_name": DUNGEON_ROOT_SCENE,
            "seed_hex": hx,
            "seed_u64": seed.get("seed_u64"),
            "use_seed_value": seed.get("use_seed_value"),
            "observations": 0,
            "captured_universe_addresses": [],
            "interpretation": "dungeon-root-resource-descriptor-seed-candidate",
        })
        row["observations"] += 1
        if captured_ua and captured_ua not in row["captured_universe_addresses"]:
            row["captured_universe_addresses"].append(captured_ua)
    return sorted(grouped.values(), key=lambda r:r["seed_hex"])



def _resource_seed_lineage(session: dict[str, Any], *, dungeon_only: bool) -> dict[str, Any]:
    """Summarize ordered non-zero descriptor seeds from already-recorded resource events.

    Runtime capture already limits these events to derelict/POI-related resource
    names. ``dungeon_only=True`` preserves the v0.3.14/v0.3.15 contract, while
    the wider context view can expose upstream POI resources without requiring
    another game run.
    """
    invalid = {"", "0000000000000000", "FFFFFFFFFFFFFFFF"}
    rows: list[dict[str, Any]] = []
    for fallback_order, event in enumerate(session.get("trace", {}).get("events", [])):
        if event.get("kind") not in {"resource_add", "resource_find"}:
            continue
        path = norm_path(event.get("resource_name"))
        if dungeon_only and not (path == DUNGEON_ROOT_SCENE or path.startswith(DUNGEON_PREFIX)):
            continue
        primary = event.get("primary_seed") or {}
        secondary = event.get("secondary_seed") or {}
        primary_hex = str(primary.get("seed_hex") or "").upper()
        secondary_hex = str(secondary.get("seed_hex") or "").upper()
        if primary_hex in invalid:
            primary_hex = ""
        if secondary_hex in invalid:
            secondary_hex = ""
        if not primary_hex and not secondary_hex:
            continue
        sequence = event.get("trace_sequence")
        try:
            sequence_value = int(sequence)
        except Exception:
            sequence_value = fallback_order
        rows.append({
            "event_order": fallback_order,
            "trace_sequence": sequence_value,
            "utc": event.get("utc"),
            "kind": event.get("kind"),
            "resource_name": path,
            "primary_seed_hex": primary_hex or None,
            "secondary_seed_hex": secondary_hex or None,
            "primary_use_seed_value": primary.get("use_seed_value") if primary_hex else None,
            "secondary_use_seed_value": secondary.get("use_seed_value") if secondary_hex else None,
        })
    rows.sort(key=lambda row: (int(row.get("trace_sequence") or 0), int(row.get("event_order") or 0)))
    normalized = [
        [row.get("kind"), row.get("resource_name"), row.get("primary_seed_hex"), row.get("secondary_seed_hex")]
        for row in rows
    ]
    signature = hashlib.sha256(
        json.dumps(normalized, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest() if normalized else None
    primary_unique = list(dict.fromkeys(row["primary_seed_hex"] for row in rows if row.get("primary_seed_hex")))
    secondary_unique = list(dict.fromkeys(row["secondary_seed_hex"] for row in rows if row.get("secondary_seed_hex")))
    return {
        "status": "captured" if rows else "not-captured",
        "event_count": len(rows),
        "ordered_signature_sha256": signature,
        "unique_primary_seed_hexes": primary_unique,
        "unique_secondary_seed_hexes": secondary_unique,
        "events": rows,
        "scope": ("dungeon-only" if dungeon_only else "recorded-derelict-poi-context"),
        "interpretation": (
            "ordered non-zero descriptor seeds on dungeon resource events; correlation evidence only"
            if dungeon_only else
            "ordered non-zero descriptor seeds across all derelict/POI resource events already captured by the probe; correlation evidence only"
        ),
    }


def resource_seed_lineage(session: dict[str, Any]) -> dict[str, Any]:
    """Backward-compatible dungeon-only seed lineage."""
    return _resource_seed_lineage(session, dungeon_only=True)


def resource_seed_context_lineage(session: dict[str, Any]) -> dict[str, Any]:
    """Wider seed context using the probe's existing derelict/POI resource trace."""
    return _resource_seed_lineage(session, dungeon_only=False)

def poi_generation_summary(
    session: dict[str, Any],
    universe_address_hex: str | None,
    root_seed_candidates: list[dict[str, Any]],
) -> dict[str, Any]:
    """Summarize target-POI generation boundaries captured by probe v0.3.17+.

    v0.3.18 keeps the older description/Prepare evidence and adds target-only
    OnActivate / AdvanceLifecycle scopes plus the inner cTkResourceManager
    AddResource boundary for the dungeon root. This avoids global RNG tracing.
    """
    expected_raw = str(universe_address_hex or "").upper()
    expected = expected_raw.zfill(16) if expected_raw else ""
    root_hexes = {str(row.get("seed_hex") or "").upper() for row in root_seed_candidates if row.get("seed_hex")}
    events = session.get("trace", {}).get("events", [])

    def matches_ua(event: dict[str, Any]) -> bool:
        raw = str(event.get("raw_argument_hex") or "").upper()
        if not raw or not expected:
            return True
        return raw.zfill(16) == expected

    def compact_component_event(fallback_order: int, event: dict[str, Any]) -> dict[str, Any]:
        return {
            "event_order": fallback_order,
            "trace_sequence": event.get("trace_sequence"),
            "utc": event.get("utc"),
            "phase": event.get("phase"),
            "component_address_hex": event.get("component_address_hex"),
            "raw_argument_hex": event.get("raw_argument_hex"),
            "duration_ms": event.get("duration_ms"),
            "space_poi_id": event.get("space_poi_id"),
            "root_node": event.get("root_node"),
            "node": event.get("node"),
            "return_value_hex": event.get("return_value_hex"),
            "call_index": event.get("call_index"),
            "snapshot_changed": event.get("snapshot_changed"),
            "dungeon_root_added_during_call": event.get("dungeon_root_added_during_call"),
            "before_snapshot": event.get("before_snapshot"),
        }

    description_results: list[dict[str, Any]] = []
    prepare_events: list[dict[str, Any]] = []
    activation_events: list[dict[str, Any]] = []
    lifecycle_events: list[dict[str, Any]] = []
    manager_root_events: list[dict[str, Any]] = []
    description_inputs = 0
    for fallback_order, event in enumerate(events):
        kind = event.get("kind")
        if kind == "space_poi_description" and matches_ua(event):
            description_inputs += 1
        elif kind == "space_poi_description_result" and matches_ua(event):
            hx = str(event.get("return_value_hex") or "").upper() or None
            description_results.append({
                "event_order": fallback_order,
                "trace_sequence": event.get("trace_sequence"),
                "utc": event.get("utc"),
                "poi_type_value": event.get("poi_type_value"),
                "poi_type_name": event.get("poi_type_name"),
                "component_address_hex": event.get("component_address_hex"),
                "raw_argument_hex": event.get("raw_argument_hex"),
                "return_value_hex": hx,
                "return_matches_universe_address": bool(hx and expected and hx.zfill(16) == expected),
                "return_matches_dungeon_root_seed": bool(hx and hx in root_hexes),
            })
        elif kind == "space_poi_prepare" and matches_ua(event):
            prepare_events.append(compact_component_event(fallback_order, event))
        elif kind == "space_poi_activate" and matches_ua(event):
            activation_events.append(compact_component_event(fallback_order, event))
        elif kind == "space_poi_lifecycle" and matches_ua(event):
            lifecycle_events.append(compact_component_event(fallback_order, event))
        elif kind == "resource_manager_add" and norm_path(event.get("resource_name")) == DUNGEON_ROOT_SCENE:
            seed = event.get("primary_seed") or {}
            manager_root_events.append({
                "event_order": fallback_order,
                "trace_sequence": event.get("trace_sequence"),
                "utc": event.get("utc"),
                "resource_name": DUNGEON_ROOT_SCENE,
                "primary_seed_hex": str(seed.get("seed_hex") or "").upper() or None,
                "descriptor_pointer_hex": event.get("descriptor_pointer_hex"),
                "caller_return_offset_hex": event.get("caller_return_offset_hex"),
                "user_call": event.get("user_call"),
                "poi_activation_scope_component_hexes": event.get("poi_activation_scope_component_hexes") or [],
                "poi_lifecycle_scope_component_hexes": event.get("poi_lifecycle_scope_component_hexes") or [],
            })

    prepare_root_scope_events: list[dict[str, Any]] = []
    activation_root_scope_events: list[dict[str, Any]] = []
    lifecycle_root_scope_events: list[dict[str, Any]] = []
    root_resource_events: list[dict[str, Any]] = []
    for fallback_order, event in enumerate(events):
        if event.get("kind") != "resource_add" or norm_path(event.get("resource_name")) != DUNGEON_ROOT_SCENE:
            continue
        seed = event.get("primary_seed") or {}
        row = {
            "event_order": fallback_order,
            "trace_sequence": event.get("trace_sequence"),
            "utc": event.get("utc"),
            "resource_name": DUNGEON_ROOT_SCENE,
            "primary_seed_hex": str(seed.get("seed_hex") or "").upper() or None,
            "descriptor_pointer_hex": event.get("descriptor_pointer_hex"),
            "caller_return_offset_hex": event.get("caller_return_offset_hex"),
            "caller_code_window": event.get("caller_code_window"),
            "caller_decoded": decode_direct_callsite(event.get("caller_code_window")),
            "logical_entry_match_count": int(event.get("logical_entry_match_count") or 0),
            "logical_entry_matches": event.get("logical_entry_matches") or [],
            "logical_entry_nearest_caller_return_offset_hex": event.get("logical_entry_nearest_caller_return_offset_hex"),
            "logical_entry_nearest_caller_code_window": event.get("logical_entry_nearest_caller_code_window"),
            "logical_entry_exact_external_caller_return_offset_hex": event.get("logical_entry_exact_external_caller_return_offset_hex"),
            "logical_entry_exact_external_caller_code_window": event.get("logical_entry_exact_external_caller_code_window"),
            "logical_entry_exact_external_match": event.get("logical_entry_exact_external_match"),
            "logical_entry_unique_callers_observed": event.get("logical_entry_unique_callers_observed"),
            "logical_entry_static_candidate_count": event.get("logical_entry_static_candidate_count"),
            "poi_prepare_scope_component_hexes": event.get("poi_prepare_scope_component_hexes") or [],
            "poi_activation_scope_component_hexes": event.get("poi_activation_scope_component_hexes") or [],
            "poi_lifecycle_scope_component_hexes": event.get("poi_lifecycle_scope_component_hexes") or [],
        }
        root_resource_events.append(row)
        if row["poi_prepare_scope_component_hexes"]:
            prepare_root_scope_events.append(row)
        if row["poi_activation_scope_component_hexes"]:
            activation_root_scope_events.append(row)
        if row["poi_lifecycle_scope_component_hexes"]:
            lifecycle_root_scope_events.append(row)

    return_hexes = list(dict.fromkeys(row["return_value_hex"] for row in description_results if row.get("return_value_hex")))
    captured = bool(description_results or prepare_events or activation_events or lifecycle_events or root_resource_events or manager_root_events)
    return {
        "status": "captured" if captured else ("input-only" if description_inputs else "not-captured"),
        "description_input_count": description_inputs,
        "description_result_count": len(description_results),
        "description_return_hexes": return_hexes,
        "description_results": description_results,
        "prepare_event_count": len(prepare_events),
        "prepare_events": prepare_events,
        "activation_event_count": len(activation_events),
        "activation_events": activation_events,
        "lifecycle_event_count": len(lifecycle_events),
        "lifecycle_events": lifecycle_events,
        "dungeon_root_inside_prepare": bool(prepare_root_scope_events),
        "dungeon_root_prepare_scope_events": prepare_root_scope_events,
        "dungeon_root_inside_activation": bool(activation_root_scope_events),
        "dungeon_root_activation_scope_events": activation_root_scope_events,
        "dungeon_root_inside_lifecycle": bool(lifecycle_root_scope_events),
        "dungeon_root_lifecycle_scope_events": lifecycle_root_scope_events,
        "dungeon_root_resource_events": root_resource_events,
        "resource_manager_root_event_count": len(manager_root_events),
        "resource_manager_root_events": manager_root_events,
        "dungeon_root_engine_caller_offsets": list(dict.fromkeys(row.get("caller_return_offset_hex") for row in root_resource_events if row.get("caller_return_offset_hex"))),
        "dungeon_root_manager_caller_offsets": list(dict.fromkeys(row.get("caller_return_offset_hex") for row in manager_root_events if row.get("caller_return_offset_hex"))),
        "dungeon_root_engine_call_sites": [row.get("caller_decoded") for row in root_resource_events if row.get("caller_decoded")],
        "dungeon_logical_entry_caller_offsets": list(dict.fromkeys(
            match.get("caller_return_offset_hex")
            for row in root_resource_events
            for match in (row.get("logical_entry_matches") or [])
            if match.get("caller_return_offset_hex")
        )),
        "dungeon_logical_entry_nearest_callers": [
            {
                "caller_return_offset_hex": row.get("logical_entry_nearest_caller_return_offset_hex"),
                "caller_code_window": row.get("logical_entry_nearest_caller_code_window"),
            }
            for row in root_resource_events
            if row.get("logical_entry_nearest_caller_return_offset_hex")
        ],
        "dungeon_logical_entry_exact_external_callers": [
            {
                "caller_return_offset_hex": row.get("logical_entry_exact_external_caller_return_offset_hex"),
                "caller_code_window": row.get("logical_entry_exact_external_caller_code_window"),
                "match": row.get("logical_entry_exact_external_match"),
                "unique_callers_observed": row.get("logical_entry_unique_callers_observed"),
                "static_candidate_count": row.get("logical_entry_static_candidate_count"),
            }
            for row in root_resource_events
            if row.get("logical_entry_exact_external_caller_return_offset_hex")
        ],
        "interpretation": "target-POI description/lifecycle plus dungeon-root resource boundaries, direct Engine caller, and exact descriptor-correlated all-callers logical-entry evidence; the verified self-recursive edge is excluded from the exact external caller",
    }

def build_index_map(index: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {norm_path(e.get("scene_path")): e for e in index.get("entries", []) if e.get("scene_path")}


def is_dead_end_group(paths: list[str]) -> tuple[bool, list[str]]:
    """Identify standalone gameplay dead-end rooms without misclassifying wall pieces.

    Verified baseline #2 contains EMPTY/ROOM_DEADEND_R_2 inside a full normal
    room, so that token alone is not sufficient.  The actual additional room is
    a compact group containing a family-level DEADEND_* scene such as
    BARRACKS/DEADEND_BUNK1. Baseline #1 has two equivalent compact groups.
    """
    normalized=[norm_path(p) for p in paths]
    evidence=[p for p in normalized if re.search(r"/DUNGEON/(?!EMPTY/)[^/]+/DEADEND_[^/]+\.SCENE\.MBIN$", p)]
    return bool(evidence and len(normalized) <= 4), evidence


ROOM_NAME_RE = re.compile(r"^Room\s+(\d+)$", re.IGNORECASE)


def room_index_from_parent_names(parent_names: list[str]) -> int | None:
    """Return the game-assigned Room N index when the parent name exposes it."""
    for name in parent_names:
        match = ROOM_NAME_RE.match(str(name).strip())
        if match:
            return int(match.group(1))
    return None


def poi_seed_candidates(session: dict[str, Any]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = {}
    for e in session.get("trace", {}).get("events", []):
        if e.get("kind") != "space_poi_description":
            continue
        hx=str(e.get("raw_argument_hex") or "").upper()
        if not hx:
            continue
        key=f"{e.get('poi_type_value')}|{hx}"
        row=grouped.setdefault(key,{
            "poi_type_value":e.get("poi_type_value"),
            "poi_type_name":e.get("poi_type_name"),
            "raw_argument_hex":hx,
            "raw_argument_u64":e.get("raw_argument_u64"),
            "interpretation":e.get("interpretation","layout-seed-candidate-unverified"),
            "observations":0,
        })
        row["observations"]+=1
    return sorted(grouped.values(),key=lambda r:(str(r.get("poi_type_name")),r["raw_argument_hex"]))


def logical_groups(events: list[dict[str, Any]], index: dict[str, Any]) -> list[dict[str, Any]]:
    by_parent: dict[str, list[tuple[int, dict[str, Any]]]] = defaultdict(list)
    for event_index,e in enumerate(events):
        by_parent[str(e.get("parent_key") or "UNKNOWN")].append((event_index,e))
    idx=build_index_map(index)
    out=[]
    for parent, indexed_xs in by_parent.items():
        xs=[e for _,e in indexed_xs]
        families=Counter()
        paths=Counter()
        salvage=foot=0
        parent_names=[]
        for e in xs:
            p=e["normalized_resource_name"]
            paths[p]+=1
            fam=scene_family(p)
            if fam:
                families[fam]+=1
            row=idx.get(p)
            if row:
                salvage += int(row.get("salvage_crates") or 0)
                foot += int(row.get("crew_footlockers") or 0)
            pname=str(e.get("parent_node_name") or "").strip()
            if pname and pname not in parent_names:
                parent_names.append(pname)
        style_counts={k:v for k,v in families.items() if k not in NEUTRAL_FAMILIES}
        dominant=max(style_counts,key=style_counts.get) if style_counts else None
        expanded_paths=[]
        for p,n in paths.items():
            expanded_paths.extend([p]*n)
        dead_end,dead_evidence=is_dead_end_group(expanded_paths)
        first_index=min(i for i,_ in indexed_xs)
        first_utc=next((e.get("utc") for _,e in indexed_xs if e.get("utc")),None)
        last_utc=next((e.get("utc") for _,e in reversed(indexed_xs) if e.get("utc")),None)
        room_index = room_index_from_parent_names(parent_names)
        out.append({
            "parent_key": parent,
            "parent_node_names": parent_names,
            "room_index": room_index,
            "room_label": (f"Room {room_index}" if room_index is not None else None),
            "first_event_index": first_index,
            "first_seen_utc": first_utc,
            "last_seen_utc": last_utc,
            "scene_instances": len(xs),
            "room_kind": "dead_end" if dead_end else "main_room",
            "dead_end_evidence": dead_evidence,
            "dominant_family": dominant,
            "scene_family_counts": dict(sorted(families.items())),
            "salvage_crates": salvage,
            "crew_footlockers": foot,
            "target_containers": salvage+foot,
            "scene_paths": [{"path":p,"instances":n} for p,n in sorted(paths.items())],
        })
    out.sort(key=lambda r:(r["first_event_index"],r["parent_key"]))
    for order,r in enumerate(out,1):
        # Preserve the old field for compatibility, but make the meaning explicit:
        # this is observation/stream order, not deterministic room order.
        r["generation_order"]=order
        r["stream_order"]=order
    return out


def layout_multiset_signature(groups: list[dict[str, Any]]) -> str:
    """Stable signature of the room assemblies regardless of Room N or stream order."""
    payload=sorted([
        {
            "kind":g.get("room_kind"),
            "family":g.get("dominant_family"),
            "paths":g.get("scene_paths"),
            "target_containers":g.get("target_containers"),
        }
        for g in groups
    ],key=lambda row:json.dumps(row,sort_keys=True,separators=(",",":"),ensure_ascii=False))
    return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")).hexdigest()


def layout_signatures(groups: list[dict[str, Any]]) -> tuple[str, str, list[dict[str, Any]]]:
    """Return stable room-index signature, legacy stream signature, and canonical groups."""
    def canonical_key(g: dict[str, Any]):
        room_index=g.get("room_index")
        if room_index is not None:
            return (0, int(room_index), "")
        # Older captures did not record parent names. Fall back to a stable
        # structural key instead of nondeterministic threaded stream order.
        structural=json.dumps({
            "kind":g.get("room_kind"),
            "family":g.get("dominant_family"),
            "paths":g.get("scene_paths"),
            "targets":g.get("target_containers"),
        },sort_keys=True,separators=(",",":"),ensure_ascii=False)
        return (1, 1_000_000, structural)
    canonical_groups=sorted(groups,key=canonical_key)
    signature_payload=[{
        "room_index":g.get("room_index"),
        "kind":g.get("room_kind"),
        "family":g.get("dominant_family"),
        "paths":g.get("scene_paths"),
        "target_containers":g.get("target_containers"),
    } for g in canonical_groups]
    layout_signature=hashlib.sha256(json.dumps(signature_payload,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")).hexdigest()
    legacy_stream_payload=[{
        "order":g.get("generation_order"),
        "kind":g.get("room_kind"),
        "family":g.get("dominant_family"),
        "paths":g.get("scene_paths"),
        "target_containers":g.get("target_containers"),
    } for g in groups]
    legacy_stream_signature=hashlib.sha256(json.dumps(legacy_stream_payload,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")).hexdigest()
    return layout_signature, legacy_stream_signature, canonical_groups


def selected_config(table: dict[str, Any], preset: str | None) -> dict[str, Any] | None:
    if not preset:
        return None
    for d in table.get("dungeons", []):
        if d.get("name") == preset:
            return {k:v for k,v in d.items() if k != "raw"}
    return None


def build_baseline(session: dict[str, Any], index: dict[str, Any], table: dict[str, Any]) -> dict[str, Any]:
    ev=dungeon_scene_events(session)
    inf=infer_preset(ev,table)
    groups=logical_groups(ev,index)
    runtime=session.get("runtime_start") or {}
    ga=runtime.get("galactic_address") or {}
    sysidx=ga.get("solar_system_index")
    block=None
    if isinstance(sysidx,int):
        start=sysidx & ~0xF
        block={
            "solar_system_index_decimal":sysidx,
            "solar_system_index_hex":f"0x{sysidx:03X}",
            "block_start_hex":f"0x{start:03X}",
            "block_end_hex":f"0x{start+0xF:03X}",
            "status":"historical-community-hypothesis-not-yet-validated-on-cosmos",
        }
    cfg=selected_config(table,inf.get("preset"))
    total_salvage=sum(g["salvage_crates"] for g in groups)
    total_foot=sum(g["crew_footlockers"] for g in groups)
    base_rooms=cfg.get("rooms") if cfg else None
    dead_end_rooms=sum(1 for g in groups if g.get("room_kind") == "dead_end")
    main_rooms=len(groups)-dead_end_rooms
    poi_candidates_all=poi_seed_candidates(session)
    universe_address=str(runtime.get("universe_address_hex") or "").upper().zfill(16)
    poi_candidates=[]
    poi_context_mismatches=[]
    for candidate in poi_candidates_all:
        matches = bool(universe_address and str(candidate.get("raw_argument_hex") or "").upper().zfill(16) == universe_address)
        candidate["matches_universe_address"] = matches
        if matches:
            candidate["interpretation"] = "universe-address-confirmed"
            poi_candidates.append(candidate)
        elif universe_address:
            poi_context_mismatches.append(candidate)
        else:
            poi_candidates.append(candidate)

    root_seed_candidates=dungeon_root_seeds(session, universe_address)
    seed_lineage=resource_seed_lineage(session)
    seed_context_lineage=resource_seed_context_lineage(session)
    poi_generation=poi_generation_summary(session, universe_address, root_seed_candidates)

    # Threaded scene streaming order is not deterministic. The game-assigned
    # parent labels (Room 0, Room 1, ...) are.
    layout_signature, legacy_stream_signature, canonical_groups = layout_signatures(groups)
    multiset_signature = layout_multiset_signature(groups)
    marker_types=Counter(m.get("type") for m in session.get("markers", []))
    return {
        "version":1,
        "analysis_tool_version":ANALYSIS_TOOL_VERSION,
        "session_id":session.get("session_id"),
        "probe_version":session.get("probe_version"),
        "universe_address_hex":runtime.get("universe_address_hex"),
        "reality_index":runtime.get("reality_index"),
        "galactic_address":ga,
        "dungeon_scene_instances":len(ev),
        "logical_generated_chunks":len(groups),
        "predicted_salvage_crates":total_salvage,
        "predicted_crew_footlockers":total_foot,
        "predicted_target_containers":total_salvage+total_foot,
        "preset_inference":inf,
        "selected_preset_config":cfg,
        "reward_seed_candidates":reward_seeds(session),
        "dungeon_root_seed_candidates":root_seed_candidates,
        "dungeon_root_seed_status": ("candidate-captured-unverified" if root_seed_candidates else "not-captured"),
        "resource_seed_lineage":seed_lineage,
        "resource_seed_lineage_status":seed_lineage.get("status"),
        "resource_seed_context_lineage":seed_context_lineage,
        "resource_seed_context_lineage_status":seed_context_lineage.get("status"),
        "poi_generation_trace":poi_generation,
        "poi_generation_trace_status":poi_generation.get("status"),
        # Backward-compatible field name retained; interpretation now records
        # when the value is proven to be the universe address rather than a seed.
        "poi_seed_candidates":poi_candidates,
        "poi_context_arguments":poi_candidates,
        "discarded_poi_context_arguments":poi_context_mismatches,
        "poi_context_status": (
            "universe-address-confirmed"
            if poi_candidates and all(bool(x.get("matches_universe_address")) for x in poi_candidates)
            else ("captured-unclassified" if poi_candidates else "not-captured")
        ),
        "layout_seed_status": ("dungeon-root-resource-seed-candidate" if root_seed_candidates else "not-captured-yet"),
        "generation_signature_sha256":layout_signature,
        "layout_signature_sha256":layout_signature,
        "layout_multiset_signature_sha256":multiset_signature,
        "legacy_stream_signature_sha256":legacy_stream_signature,
        "historical_16_system_block_hypothesis":block,
        "base_room_count_from_table":base_rooms,
        "observed_main_rooms":main_rooms,
        "observed_dead_end_rooms":dead_end_rooms,
        "observed_total_rooms":len(groups),
        "main_room_count_matches_table": (main_rooms == base_rooms) if isinstance(base_rooms,int) else None,
        "manual_room_markers": {
            "main_rooms_f6": int(marker_types.get("room",0)),
            "dead_ends_f5": int(marker_types.get("room_zero",0)),
        },
        "room_model_status": ("validated-against-table" if isinstance(base_rooms,int) and main_rooms == base_rooms else "needs-review"),
        "room_parent_index_coverage": sum(1 for g in groups if g.get("room_index") is not None),
        "canonical_room_sequence": [
            {
                "room_index": g.get("room_index"),
                "room_label": g.get("room_label"),
                "room_kind": g.get("room_kind"),
                "dominant_family": g.get("dominant_family"),
                "salvage_crates": g.get("salvage_crates"),
                "crew_footlockers": g.get("crew_footlockers"),
                "target_containers": g.get("target_containers"),
                "stream_order": g.get("stream_order"),
            }
            for g in canonical_groups
        ],
        "logical_groups":groups,
    }


def main(argv=None) -> int:
    ap=argparse.ArgumentParser(description="Build compact derelict generation baseline")
    ap.add_argument("session",type=Path)
    ap.add_argument("room_crate_index",type=Path)
    ap.add_argument("generation_table",type=Path)
    ap.add_argument("--output",type=Path,required=True)
    args=ap.parse_args(argv)
    out=build_baseline(load_json(args.session),load_json(args.room_crate_index),load_json(args.generation_table))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding="utf-8")
    pi=out["preset_inference"]
    print(f"Preset: {pi.get('preset') or 'unresolved'} ({pi.get('confidence')})")
    print(f"Rooms: {out['observed_total_rooms']} = {out['observed_main_rooms']} main + {out['observed_dead_end_rooms']} dead ends ({out['dungeon_scene_instances']} scene instances)")
    print(f"Target containers: {out['predicted_target_containers']} = {out['predicted_salvage_crates']} salvage + {out['predicted_crew_footlockers']} footlockers")
    if out.get("reward_seed_candidates"):
        print("Reward seeds: " + ", ".join(f"{x['reward_id']}={x['seed_hex']}" for x in out['reward_seed_candidates']))
    if out.get("dungeon_root_seed_candidates"):
        print("Dungeon-root seed candidates: " + ", ".join(x["seed_hex"] for x in out["dungeon_root_seed_candidates"]))
    lineage=out.get("resource_seed_lineage") or {}
    context_lineage=out.get("resource_seed_context_lineage") or {}
    if lineage.get("event_count"):
        print(f"Seed-bearing resource events: {lineage['event_count']} signature={lineage.get('ordered_signature_sha256')}")
    if context_lineage.get("event_count"):
        print(f"POI seed-context events: {context_lineage['event_count']} signature={context_lineage.get('ordered_signature_sha256')}")
    poi_generation=out.get("poi_generation_trace") or {}
    if poi_generation.get("description_result_count"):
        print(f"POI description returns: {poi_generation.get('description_return_hexes')} root_match={any(bool(x.get('return_matches_dungeon_root_seed')) for x in poi_generation.get('description_results') or [])}")
    if poi_generation.get("prepare_event_count"):
        print(f"POI prepare events: {poi_generation.get('prepare_event_count')} root_inside_prepare={poi_generation.get('dungeon_root_inside_prepare')}")
    if poi_generation.get("dungeon_root_engine_caller_offsets"):
        print(f"Dungeon-root Engine caller offsets: {poi_generation.get('dungeon_root_engine_caller_offsets')}")
    if poi_generation.get("dungeon_root_manager_caller_offsets"):
        print(f"Dungeon-root manager caller offsets: {poi_generation.get('dungeon_root_manager_caller_offsets')}")
    if out.get("poi_seed_candidates"):
        print("POI context args: " + ", ".join(f"{x['raw_argument_hex']} ({x.get('interpretation')})" for x in out['poi_seed_candidates']))
    print(f"Wrote: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
