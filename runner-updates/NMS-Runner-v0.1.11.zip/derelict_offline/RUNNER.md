# NMS Offline local runner

Start once with `Start-Runner.cmd`. It checks the private Unicorn environment,
installs the pinned dependency only if needed, runs the first job, then watches
this experiment's source files. NMS stays closed. Ctrl+C stops owned work.
There is no game launch or process attachment. GitHub uploads are optional;
enable them once with `Setup-GitHub.cmd`. The worker does not log in to ChatGPT.

## Desktop window in 0.1.6

`Start-Runner.cmd` without arguments opens the native Tk window and starts the
worker. Python's standard Tcl/Tk component is required; no GUI packages are
downloaded. The launcher falls back to console mode if Tk is unavailable.
`python start.py gui --no-autostart` opens the window without starting work.

- Start launches one owned worker; Stop cancels it, retaining completed reports.
- Pause finishes any current job/upload, then waits without claiming queued
  requests. Resume continues. Upload retry polling can continue while paused.
- Run check publishes the existing fixed request; pending requests are preserved.
- Retry uploads is available after stopping the worker. GitHub setup also runs
  with the worker stopped; its sign-in/install window is intentionally visible.
- Select NMS.exe is optional and only available while stopped. Its resolved path
  and SHA-256 are saved in `.local/nms-exe.json` on this PC only. The worker
  rehashes that exact file before use and stops safely if it is missing, renamed,
  or changed. The path/config are excluded from logs, reports and packages.
- Open reports shows retained outputs. Developer shows build/status/errors and
  allows complete current source ZIP export, including AI_HANDOFF.md.
- Show live activity expands a bounded console view (500 lines, memory only).
  Existing structured logs/results remain unchanged; raw output is not saved.

GUI state and actions use the same worker and request protocol; no second test
pipeline. A spinner appears during work, not idle watching or paused state.
Closing the window stops owned work, with a five-second forced cleanup fallback.
On Windows a hidden worker console permits cooperative cancellation; a Job Object
contains owned descendants. This behavior still needs its first Windows GUI run.

The former missing-module probe was printed before automatic installation;
installer output was buffered until exit. Now expected probe failures are quiet,
automatic repair is explained, and installation/test output appears live.
The Windows WinError 1314 regression test is repaired without elevating privileges.

## Permanent folder in 0.1.7

All Windows launchers use `%USERPROFILE%\Documents\NMS Runner`, which is
`%USERPROFILE%\Documents\NMS Runner` on the requested account. This is the
literal Documents folder, not an inferred OneDrive location. The experiment is
installed directly inside it, with no extra `derelict_offline` subfolder.

Stop the old worker and close its window. For the first migration, copy the new
ZIP's `derelict_offline` contents over your current runner folder, retaining its
runtime files. Open the new Start-Runner.cmd. It runs the installer, copies the
allowlisted source and missing `.local`, `reports` and `requests` entries, then
starts the permanent copy. Original data remains intact. Use the permanent
folder's launcher thereafter; launching a later extracted ZIP updates it first.

Install-Runner.cmd installs without launching. Setup-GitHub.cmd,
Install-Unicorn.cmd, Test-Unicorn.cmd and Export-Offline-Evidence.cmd also route
to the permanent folder. Existing GitHub CLI authentication remains with gh.
An existing target environment is retained and health-checked by the worker.
When moving healthy pinned Unicorn from the old folder, a new correctly rooted
venv reuses its package files; the old venv is preserved. No dependency is bundled.

The installer locks both workers, stages and hashes source, backs up replaced
source under `.local/source-backups/<id>.zip`, and restores replaced files on a
source-write failure. Existing permanent settings/report IDs win; missing data
copies are retryable even when source was already installed. Neither folder's
reports are deleted. Newer installed versions and differing same-version source
are refused. If you intentionally want to repair changed same-version source,
stop the worker and run from the downloaded copy:
`python start.py install --replace-source`. This still backs up source first.

Developer commands remain portable and act on their current experiment folder.
`python start.py install --target "chosen-folder"` is an explicit installation
option; Windows CMD launchers still use the requested default. To roll back,
stop and close the worker, then restore a retained source backup's contents into
the permanent folder, keeping `.local`, `.unicorn-venv`, `reports` and `requests`.
Retain the original folder until the first permanent-folder run succeeds.
Windows CMD execution still needs confirmation on the user's PC.

Console mode: `Start-Runner-CLI.cmd`, or the existing launcher with arguments.
New optional CLI controls: `python start.py runner --pause` / `--resume`.
`.local/runner-control.json` is additive schema 1 with only `schema` and boolean
`paused`. Invalid fields block the watcher; `--once` ignores pause control.

Each stable source change runs once. The completed status is remembered locally
against the exact source digest, requested action, and selected executable hash,
so restarting the worker does not repeat the same full test/replay/1,000-run
Unicorn job. A changed source or reselected executable triggers a fresh automatic check;
Run check and explicit requests still rerun unchanged source. Completed failures
are retained without automatic retry loops; canceled/interrupted and stale jobs
are not marked complete. The pinned Unicorn environment's interpreter and all
Unicorn package files are hashed against the last successful startup smoke test;
the short instruction smoke test is skipped only when those bytes still match.
A changed dependency causes the smoke test to run again. A failed stage stops the
job. Changes during a run mark the result stale and queue the new stable source.
Two consecutive observations, five seconds apart, debounce source edits.

Latest state: `.local/status.json`, `.local/latest.log`,
`.local/latest-result.json`. Per-job results: `reports/<request_id>/` with
`result.json`, `source.zip` and `runner-evidence.zip`. The source ZIP is the
exact tested snapshot, with handoff/tests/assets; local environments, outputs,
requests and caches are excluded. The evidence ZIP contains allowlisted result
JSON, stage logs and a bounded game-code export if requested. No machine paths,
network/device identifiers or personal telemetry are added to these logs.
Subprocess text is shown in the console only; share the stage reports for
diagnosis. Original historical verification reports remain provenance, not
claims about the latest local run. Check the per-run result for actual status.

Developer controls:

```text
python start.py runner --status
python start.py runner --once
python start.py runner --request offline-check
python start.py package --out complete-source.zip
```

## Automatic GitHub uploads in 0.1.5

1. Run `Setup-GitHub.cmd` once. It installs GitHub CLI through the official
   winget package if missing and opens GitHub's sign-in flow if needed. If winget
   is unavailable, install GitHub CLI from https://cli.github.com/ and rerun it.
   An already authenticated CLI is reused; repository write access is checked.
2. Start/restart `Start-Runner.cmd`. Completed jobs upload automatically to
   `vikkitor93-coder/NMS-Derelict-Probe`, branch `nms-runner-evidence`.
3. Use `GITHUB_CHECK_PROMPT.md` for your scheduled ChatGPT check with GitHub
   access. No scheduled task is created by setup or by the runner.

This repository is public. Uploaded source, reports and any explicitly selected
bounded code export are visible publicly. No full NMS.exe, private environment,
credentials, raw process output or unrelated local files are uploaded.
GitHub CLI owns authentication; this package never reads or saves a token.
The CLI is not bundled into the small source ZIP. Auth storage follows GitHub CLI.

Remote layout: `runner-results/<request_id>/` contains readable stage JSON/logs,
`result.json`, `manifest.json`, `runner-evidence.zip`, `AI_HANDOFF.md`,
`GITHUB_CHECK_PROMPT.md`, and `source.zip` when packaging succeeded. The two
text handoff files come from the same frozen tested snapshot, so ChatGPT can
continue from exact current instructions without opening the source ZIP. `runner-results/latest.json` repeats the latest manifest,
including source digest, status, file SHA256 and byte counts. All files/pointer
publish together in one commit. Existing files on the evidence branch are
preserved. Main is never written by the uploader. Old IDs are immutable;
matching uploads are idempotent and do not rewind the latest pointer.

Only allowlisted artifacts are sent: at most 4 MiB each / 8 MiB total per job.
The evidence ZIP also includes the bounded export if requested. Reports retain
their original execution status; `.local/github-status.json` and
`github-uploads.json` record transfer separately. No successful upload means
no verified research conclusion. The uploader uses GitHub CLI's authenticated
API requests with bounded timeouts and no shell commands.

Upload attempts occur after a job and at most once per minute while idle, with
three attempts per report, persisted across restarts. Failed uploads retain all
files, do not rerun tests/export, and block later uploads to preserve order.
After fixing network/auth/access, stop the runner, then run:
`python start.py github --retry`. This resets failed attempt counts and sends
retained reports. Restart the worker afterward. `python start.py github` sends
pending reports without resetting limits. Both require the worker to be stopped.
The first configured launch also uploads retained completed reports from this
experiment folder. A one-shot run returns failure if its upload is unsuccessful.

Disable with `python start.py github --disable`, then restart the worker.
Configuration is `.local/github-config.json`; it is excluded from all ZIPs.
For another authorized repo: `Setup-GitHub.cmd --repo owner/name`; the fixed
evidence branch remains the same. GitHub history retains uploaded reports even
after local cleanup; the existing 100-report local cap still applies.

## Optional executable exports

Only select NMS.exe when new bounded exports are needed. The existing unchanged
exporter cannot reveal new callers. Run:

```text
Start-Runner.cmd --exe "G:\SteamLibrary\steamapps\common\No Man's Sky\Binaries\NMS.exe"
```

This enables bounded read-only exports; the EXE is not launched, modified or
copied. The resolved path and SHA-256 are saved locally and reused on later
starts. The worker checks that exact file against the saved hash before each
job; a changed/missing file blocks the run until you select it again. The path
is not included in reports or configuration uploads. The exporter also checks
the executable identity and fails if incompatible. Unchanged export inputs
reuse the validated local export. A changed exporter or EXE invalidates that
cache. To ask for a check/export after edits:
`python start.py runner --request offline-check-and-export`.
Without the initial `--exe` selection this action fails with
`nms-exe-not-selected`; it does not prompt or probe a different game.

## ChatGPT research continuation

The ChatGPT scheduled task **NMS Research Continuation** reviews unreviewed
GitHub uploads, records one receipt per job, and continues the current offline
research from the tested handoff. It keeps a concise research-progress ledger
on the evidence branch. ChatGPT scheduling currently allows hourly checks, not
five-minute checks. The task can use only the GitHub evidence branch for writes;
it cannot execute arbitrary commands on the PC, edit production Surveyor code,
merge changes, or install a new runner build. See GITHUB_CHECK_PROMPT.md for the
full workflow and exact current research target.

## AI / runner boundary

This is a separate NMS worker using the earlier Unspottable runner pattern.
Unspottable request `build-and-h2` remains unchanged and is not accepted here.
NMS schema 1 accepts exactly:

```json
{"schema":1,"request_id":"32 lowercase hex characters","action":"offline-check","source_sha256":"64 lowercase hex characters"}
```

Publish `requests/ready.json` atomically without replacing a pending request;
the helper command above calculates the source hash and publishes safely.
Only `offline-check` / `offline-check-and-export` are accepted. No arbitrary
commands, arguments or paths are accepted from requests. A lock prevents two
workers. Claimed requests survive crashes and stop the next launch for review.
Check `.local/claimed-request.json` and the corresponding report; after
review, move the claimed file aside, then restart. IDs cannot be reused.

For a local AI with access to the same folder, use `LOCAL_WORK_PROMPT.md`.
That AI can read results, edit code and publish the next fixed request.
The runner itself does not write research code or make scientific decisions.
Alternatively the GitHub upload path lets a scheduled check read completed
results without direct PC folder access. Setup must succeed on the PC first.
The scheduled prompt records a review receipt per job and an evidence-backed
research-progress ledger on the evidence branch. It authorizes only those two
write locations, not production edits. The ChatGPT task is configured for hourly
runs; the platform does not support five-minute scheduling. Starting in 0.1.10,
the permanent installer enables a one-hour poll of the separate
`runner-updates` branch. Update packages are bounded, allowlisted ZIPs with an
archive hash, per-file hashes, source digest, source commit and test-run
evidence. The runner verifies these before staging; it retains a rollback ZIP,
waits for its worker process to exit, applies the package, and restarts the CLI
or reconnects the desktop window. The evidence upload branch is never used for
updates. Package integrity is checked over HTTPS, while write access to the
dedicated update branch is the publisher trust boundary; packages are not
cryptographically signed. Publish `runner-updates/latest.json` and the matching
versioned ZIP under the `runner-updates/` folder in the `runner-updates` branch,
together in one commit. Use
`python -m derelict_offline.tools.build_runner_update --archive <zip> --manifest <latest.json> --source-commit <40-hex-commit>`
to produce them; this command stops if the full test suite does not pass.
Bootstrap once from the supplied ZIP using `Install-Runner.cmd`, then open the
permanent folder's `Start-Runner.cmd`. Later verified feed releases apply and
restart without a manual copy. Keep the previous update ZIP for rollback.

Runner source changes take effect after restarting `Start-Runner.cmd`;
research-module changes are picked up by the next snapshot. Keep completed
reports for review/rollback. At 100 report folders, the runner stops for cleanup
rather than filling disk or deleting evidence. Rollback: stop runner and use
the prior experiment ZIP; existing Surveyor/Unspottable files are untouched.
