"""Diagnostic, validation and benchmark entry point; no NMS/runtime imports."""
from __future__ import annotations
import argparse
import statistics
import time
from . import VERSION
from .build_corpus import build
from .common import HERE, read_json, write_json
from .prototype import replay, root_prediction
from .public_seed import system_seed

def validate(corpus, index):
    results = [replay(case, index) for case in corpus["cases"]]
    return {"schema_version": 1, "prototype_version": VERSION,
            "input": "bundled-source-linked-session-projections",
            "test_status": read_json(HERE / "verification.json") if (HERE / "verification.json").is_file() else {"status": "not-recorded"},
            "source_export_command": "python start.py package --out derelict-offline.zip",
            "corpus_summary": corpus["summary"], "results": results,
            "all_replays_match": all(r["matches_existing_analyzer"] for r in results),
            "root_generation_verified": False,
            "errors": [r["case_id"] for r in results if not r["matches_existing_analyzer"]]}

def benchmark(corpus, index, repetitions=250):
    if repetitions < 1:
        raise ValueError("Repetitions must be positive")
    timings = []
    for _ in range(5):
        start = time.perf_counter()
        for _ in range(repetitions):
            for case in corpus["cases"]:
                replay(case, index)
        timings.append(time.perf_counter() - start)
    count = repetitions * len(corpus["cases"])
    # Includes index construction and validation per invocation.
    seconds = statistics.median(timings)
    return {"schema_version": 1, "prototype_version": VERSION,
            "boundary": "selected-scenes-to-asset-counts",
            "cases_per_trial": count, "trials": 5, "seconds_each": timings,
            "median_seconds": seconds, "cases_per_second": count / seconds,
            "includes": ["index validation", "scene lookup", "count aggregation", "comparison"],
            "excludes": ["disk load", "root derivation", "layout generation", "travel", "rendering"],
            "in_game_baseline_seconds": None, "end_to_end_speedup": None,
            "interpretation": "Batch replay throughput only; no generated-derelict speedup established."}

def main(argv=None):
    parser = argparse.ArgumentParser(description="Derelict offline diagnostic: replay, never pretend generation")
    parser.add_argument("command", choices=("diagnose", "validate", "benchmark", "address", "code", "rng", "emulate"), nargs="?", default="diagnose")
    parser.add_argument("--address")
    parser.add_argument("--case")
    parser.add_argument("--out")
    parser.add_argument("--repetitions", type=int, default=250)
    parser.add_argument("--seed")
    parser.add_argument("--disabled-seed", action="store_true")
    args = parser.parse_args(argv)
    try:
        corpus = build()
        index = read_json(HERE / "fixtures/room-crate-index.json")
        if args.command == "emulate":
            from .unicorn_check import check
            result = check(args.repetitions)
        elif args.command == "code":
            from .code_evidence import inspect
            result = inspect()
        elif args.command == "rng":
            from .rng_kernel import diagnose
            if args.seed is None:
                raise ValueError("--seed is required")
            result = {"prototype_version": VERSION, "result": diagnose(args.seed, not args.disabled_seed), "errors": []}
        elif args.command == "address":
            if not args.address:
                raise ValueError("--address is required")
            result = {"prototype_version": VERSION, "input": args.address, "result": root_prediction(args.address), "errors": []}
        else:
            if args.case:
                corpus["cases"] = [case for case in corpus["cases"] if case["case_id"] == args.case]
                if not corpus["cases"]:
                    raise ValueError("Unknown case")
            result = benchmark(corpus, index, args.repetitions) if args.command == "benchmark" else validate(corpus, index)
            if args.command == "diagnose":
                result["code_arithmetic_check"] = read_json(HERE / "unicorn-verification.json") if (HERE / "unicorn-verification.json").is_file() else {"status": "not-recorded"}
        if args.out:
            write_json(args.out, result)
        print(__import__("json").dumps(result, indent=2))
        return 0 if not result.get("errors") else 1
    except (ValueError, KeyError, OSError) as error:
        result = {"prototype_version": VERSION, "input_case": args.case, "errors": [str(error)]}
        if args.out:
            write_json(args.out, result)
        print(__import__("json").dumps(result, indent=2))
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
