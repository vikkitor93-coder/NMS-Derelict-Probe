"""Reproduce bounded hypothesis, existing-parser and saved-byte checks."""
from collections import defaultdict
import hashlib
import xml.etree.ElementTree as ET
from tools.analyze_seed_room_correlation import analyze
from tools.analyze_dungeon_generation_table import prop_to_obj, normalize_dungeon, iter_dungeon_items
from tools.analyze_nms_seed_function import scan_disp_references
from .common import HERE, read_json, write_json
from .public_seed import system_seed

def audit():
    journal = read_json(HERE / "evidence/root-journal-analysis.json")
    checks = []
    for row in journal["all_root_event_observations"]:
        address, root = row["universe_address_hex"], row["root_seed_candidate_hex"]
        seed = system_seed(address)
        checks.append({"event_id": row["event_id"], "universe_address_hex": address,
                       "root_candidate_hex": root, "public_system_seed_hex": f"{seed:08X}",
                       "root_equals_address": root == address,
                       "root_equals_zero_extended_public_seed": int(root, 16) == seed,
                       "root_low_word_equals_public_seed": (int(root, 16) & 0xFFFFFFFF) == seed})
    hypotheses = {"schema_version": 1, "identity_status": "Unpinned observations; tests are value comparisons only.",
                  "observations": len(checks), "distinct_addresses": len({c["universe_address_hex"] for c in checks}),
                  "hypotheses": [{"name": key, "matches": sum(c[key] for c in checks), "tested": len(checks)}
                                 for key in ("root_equals_address", "root_equals_zero_extended_public_seed", "root_low_word_equals_public_seed")],
                  "cases": checks, "conclusion": "Simple identity hypotheses do not derive the observed roots."}
    summary = read_json(HERE / "evidence/generation-measurements-summary.json")
    groups = defaultdict(list)
    for row in summary["measurements"]:
        epoch = "historical-pre-7.05-update-date-unpinned" if row["session_id"][:8] < "20260930" else "post-update-date-unpinned"
        groups[epoch].append(row)
    historical = {"schema_version": 1,
                  "policy": "Date partitions are not verified game versions. No historical row enters the four-session regression corpus.",
                  "cohorts": {key: analyze({"measurements": rows}) for key, rows in groups.items()}}
    table = read_json(HERE / "fixtures/dungeon-generation-table.json")
    def element(node):
        attributes = {}
        for key in ("name", "value"):
            value = node.get(key)
            if value is not None:
                attributes[key] = str(value).lower() if isinstance(value, bool) else str(value)
        result = ET.Element("Property", attributes)
        result.extend(element(child) for child in node.get("children", []))
        return result
    presets = [normalize_dungeon(prop_to_obj(item)) for item in iter_dungeon_items(element(table["raw_table"]))]
    parser_check = {"schema_version": 1, "input": "Existing parsed Property AST; not newly extracted MXML",
                    "normalized_presets": len(presets), "matches_existing_table": presets == table["dungeons"],
                    "asset_build_pinned": False}
    static = read_json(HERE / "evidence/dungeon-seed-function-analysis-latest.json")
    raw = bytes.fromhex(static["root_runtime_fragment_bytes_hex"])
    if hashlib.sha256(raw).hexdigest() != static["root_runtime_fragment_sha256"]:
        raise ValueError("Saved root fragment hash mismatch")
    refs = scan_disp_references(raw, int(static["root_runtime_fragment"]["begin_rva_hex"], 16))
    static_check = {"schema_version": 1, "executable": static["nms_exe"],
                    "saved_fragment_hash_verified": True, "saved_fragment_length": len(raw),
                    "existing_byte_scanner_references": refs,
                    "fresh_full_executable_analysis": "blocked-executable-not-available",
                    "interpretation": "Byte-pattern references only; no complete function emulated or root formula verified."}
    for name, value in (("hypothesis-results.json", hypotheses), ("historical-correlation.json", historical),
                        ("asset-parser-check.json", parser_check), ("static-check.json", static_check)):
        write_json(HERE / name, value)
    return {"root_observations": len(checks), "distinct_addresses": hypotheses["distinct_addresses"],
            "normalized_presets": len(presets), "parser_roundtrip_matches": parser_check["matches_existing_table"],
            "saved_fragment_hash_verified": True}

if __name__ == "__main__":
    print(audit())
