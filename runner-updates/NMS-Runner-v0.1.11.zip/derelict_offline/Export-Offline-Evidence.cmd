@echo off
setlocal EnableExtensions
set "NMS_RUNNER_HOME=%USERPROFILE%\Documents\NMS Runner"
if /I "%~dp0"=="%NMS_RUNNER_HOME%\" goto permanent_folder
call "%~dp0Install-Runner.cmd" --quiet-exit
if errorlevel 1 goto permanent_failed
call "%NMS_RUNNER_HOME%\Export-Offline-Evidence.cmd" %*
exit /b %ERRORLEVEL%
:permanent_failed
echo Installation could not finish. Stop the old runner, close its window, then retry.
pause
exit /b 2
:permanent_folder
pushd "%~dp0"
set "NMS_EXE_ARG="
if not "%~1"=="" set NMS_EXE_ARG=--exe "%~1"
where py.exe >nul 2>&1
if not errorlevel 1 (
    py -3 start.py export %NMS_EXE_ARG%
) else (
    python start.py export %NMS_EXE_ARG%
)
set "RC=%ERRORLEVEL%"
popd
echo.
if "%RC%"=="0" (
    echo Attach offline-evidence.zip from this folder to the chat.
) else (
    echo Export did not complete cleanly. Send the error shown above.
)
pause
exit /b %RC%
