"""Smallest supported downstream boundary: selected scenes -> asset totals."""
from collections import Counter
from .common import effective_seed, hex64
from .public_seed import system_seed

def replay(case, index):
    entries = {}
    for row in index.get("entries", []):
        name = str(row["scene_path"]).replace("\\", "/").upper()
        if name in entries:
            raise ValueError(f"Duplicate index scene: {name}")
        entries[name] = row
    counts = Counter()
    unresolved = []
    scene_count = 0
    for group in case["selected_scene_groups"]:
        for selection in group["scene_paths"]:
            path = selection["path"].replace("\\", "/").upper()
            n = selection["instances"]
            if isinstance(n, bool) or not isinstance(n, int) or n <= 0:
                raise ValueError("Scene multiplicity must be a positive integer")
            scene_count += n
            row = entries.get(path)
            if row is None or row.get("unresolved_dependencies") or row.get("cycle_detected"):
                unresolved.append({"path": path, "instances": n, "reason": "missing-or-incomplete-asset"})
                continue
            for key in ("salvage_crates", "crew_footlockers"):
                value = row.get(key)
                if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                    raise ValueError(f"Invalid {key} in index: {path}")
                counts[key] += value * n
    complete = not unresolved and scene_count > 0
    result = {"salvage_crates": counts["salvage_crates"], "crew_footlockers": counts["crew_footlockers"],
              "target_containers": sum(counts.values())}
    expected = case["asset_derived_counts"]
    roots = []
    for seed in case["root_seeds"]:
        roots.append({"raw": hex64(seed["seed_hex"]), "use_seed_value": seed.get("use_seed_value"),
                      "effective": effective_seed(seed)})
    return {"case_id": case["case_id"], "boundary": "selected-scenes-to-asset-counts",
            "evidence_status": "asset-derived-replay",
            "complete": complete, "result": result if complete else None,
            "partial_asset_counts": result if not complete else None,
            "matches_existing_analyzer": complete and result == expected,
            "matches_runtime_asset_counter": result == case.get("runtime_asset_counts") if complete and case.get("runtime_asset_counts") else None,
            "unresolved_scenes": unresolved, "scene_instances": scene_count,
            "room_groups": len(case["selected_scene_groups"]), "root_seeds": roots,
            "table_main_rooms": case.get("table_main_rooms"),
            "captured_main_room_groups": case["captured_main_room_groups"],
            "table_count_matches": case.get("table_main_rooms") == case["captured_main_room_groups"] if case.get("table_main_rooms") is not None else None,
            "independent_physical_count_verified": False,
            "root_to_layout_implemented": False}

def root_prediction(address):
    return {"universe_address_hex": hex64(address),
            "public_system_seed_hex": f"{system_seed(address):08X}",
            "public_system_seed_status": "reference-equations-only-current-game-unverified",
            "derelict_root_seed_hex": None, "room_layout": None,
            "status": "blocked-unrecovered-root-and-layout-algorithms"}
