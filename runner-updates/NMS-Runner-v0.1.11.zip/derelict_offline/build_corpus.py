"""Regenerate cases from source-linked projections using existing analyzers."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from pathlib import Path
from tools.analyze_generation_baseline import build_baseline
from tools.record_generation_measurement import compact_row
from tools.analyze_seed_room_correlation import analyze
from .common import HERE, hex64, read_json, sha256, write_json
from . import VERSION

def captured_roots(session, address):
    roots = {}
    for event in session.get("trace", {}).get("events", []):
        if event.get("kind") != "resource_add" or event.get("resource_name") != "MODELS/SPACE/POI/DUNGEON.SCENE.MBIN":
            continue
        captured_address = event.get("universe_address_hex_at_capture")
        if captured_address and hex64(captured_address) != hex64(address):
            continue
        primary = event.get("primary_seed") or {}
        if primary.get("seed_hex") is None:
            continue
        seed, flag = hex64(primary["seed_hex"]), primary.get("use_seed_value")
        flag = flag if isinstance(flag, bool) else None
        row = roots.setdefault((seed, flag), {"seed_hex": seed, "use_seed_value": flag, "observations": 0})
        row["observations"] += 1
    return list(roots.values())

def build(manifest_path=HERE / "fixtures/manifest.json"):
    manifest_path = Path(manifest_path)
    manifest = read_json(manifest_path)
    if manifest.get("schema_version") != 1:
        raise ValueError("Unsupported fixture manifest schema")
    root = manifest_path.parent
    for record in [manifest["index"], manifest["table"], *manifest["sessions"]]:
        if sha256(root / record["path"]) != record["projection_sha256"]:
            raise ValueError(f"Fixture hash mismatch: {record['path']}")
    index, table = read_json(root / manifest["index"]["path"]), read_json(root / manifest["table"]["path"])
    cases, baselines = [], []
    cohorts = defaultdict(list)
    for record in manifest["sessions"]:
        session = read_json(root / record["path"])
        baseline = build_baseline(session, index, table)
        baselines.append(baseline)
        runtime = session.get("generation_room_summary") or {}
        live_counts = ({key: runtime.get(field) for key, field in
                       (("salvage_crates", "salvage_crates_seen"),
                        ("crew_footlockers", "crew_footlockers_seen"),
                        ("target_containers", "target_containers_seen"))}
                       if "target_containers_seen" in runtime else None)
        identity = record["game_identity"]
        pinned = bool(identity.get("executable_sha256") and identity.get("game_version") and identity.get("game_version_status") == "captured")
        identity_key = (identity.get("game_version"), identity.get("game_version_status"), identity.get("executable_sha256"))
        cohorts[identity_key].append(compact_row(baseline))
        cases.append({
            "case_id": session["session_id"], "game_identity": identity,
            "strict_version_pinned": pinned,
            "identity_status": "pinned" if pinned else "quarantined-unpinned",
            "universe_address_hex": baseline["universe_address_hex"],
            "reality_index": baseline["reality_index"],
            "probe_version": session.get("probe_version"),
            "provenance": record,
            "root_seeds": captured_roots(session, baseline["universe_address_hex"]),
            "root_events": [event for event in session.get("trace", {}).get("events", [])
                            if event.get("kind") == "resource_add" and event.get("resource_name") == "MODELS/SPACE/POI/DUNGEON.SCENE.MBIN"],
            "preset_inference": baseline["preset_inference"],
            "selected_preset_config": baseline["selected_preset_config"],
            "table_main_rooms": baseline["base_room_count_from_table"],
            "captured_main_room_groups": baseline["observed_main_rooms"],
            "captured_dead_end_groups": baseline["observed_dead_end_rooms"],
            "room_parent_index_coverage": baseline["room_parent_index_coverage"],
            "selected_scene_groups": [{k: group[k] for k in
                ("room_index", "room_kind", "dominant_family", "scene_paths")}
                for group in baseline["logical_groups"]],
            "asset_derived_counts": {key: baseline["predicted_" + key] for key in
                ("salvage_crates", "crew_footlockers", "target_containers")},
            "runtime_asset_counts": live_counts,
            "manual_marker_counts": dict(Counter(m.get("type") for m in session.get("markers", []))),
            "manual_count_status": "partial-markers-not-a-completed-inventory",
            "layout_signature_sha256": baseline["layout_signature_sha256"],
            "layout_multiset_signature_sha256": baseline["layout_multiset_signature_sha256"],
        })
    # Explicit exploratory report: these cases are not admitted to hash-pinned
    # generation validation. Older measurements never enter this cohort.
    correlations = []
    for (version, status, binary_hash), rows in sorted(cohorts.items(), key=lambda item: str(item[0])):
        correlation = analyze({"measurements": rows})
        correlation["game_identity"] = {"game_version": version, "game_version_status": status, "executable_sha256": binary_hash}
        correlation["identity_policy"] = ("Same recorded identity cohort." if version and status == "captured" and binary_hash else
                                         "Exploratory unpinned cohort. Repetition does not establish executable identity.")
        correlations.append(correlation)
    return {"schema_version": 1, "prototype_version": VERSION,
            "source_baseline": manifest["source_baseline"], "cases": cases,
            "summary": {"cases": len(cases), "strictly_pinned_cases": sum(c["strict_version_pinned"] for c in cases),
                        "quarantined_cases": sum(not c["strict_version_pinned"] for c in cases)},
            "correlations_by_identity": correlations,
            "generation_validation_status": "blocked-no-complete-pinned-generation-inputs"}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, default=HERE / "fixtures/manifest.json")
    parser.add_argument("--out", type=Path, default=HERE / "corpus.json")
    args = parser.parse_args()
    result = build(args.manifest)
    write_json(args.out, result)
    print(result["summary"])
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
