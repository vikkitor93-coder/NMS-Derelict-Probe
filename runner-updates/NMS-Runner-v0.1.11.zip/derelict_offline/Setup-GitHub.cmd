@echo off
setlocal
set "NMS_RUNNER_HOME=%USERPROFILE%\Documents\NMS Runner"
if /I "%~dp0"=="%NMS_RUNNER_HOME%\" goto permanent_folder
call "%~dp0Install-Runner.cmd" --quiet-exit
if errorlevel 1 goto permanent_failed
call "%NMS_RUNNER_HOME%\Setup-GitHub.cmd" %*
exit /b %ERRORLEVEL%
:permanent_failed
echo Installation could not finish. Stop the old runner, close its window, then retry.
pause
exit /b 2
:permanent_folder
echo NMS Offline - enable automatic GitHub evidence uploads
cd /d "%~dp0"
where gh >nul 2>nul
if not errorlevel 1 goto python
if exist "%ProgramFiles%\GitHub CLI\gh.exe" goto python
if exist "%LOCALAPPDATA%\Programs\GitHub CLI\gh.exe" goto python
echo Installing GitHub CLI using the official winget package...
where winget >nul 2>nul
if errorlevel 1 goto missing
call winget install --id GitHub.cli --exact --source winget --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto missing
:python
if exist ".unicorn-venv\Scripts\python.exe" goto private
where py >nul 2>nul
if errorlevel 1 goto fallback
call py -3 -u start.py github --setup %*
goto done
:private
call ".unicorn-venv\Scripts\python.exe" -u start.py github --setup %*
goto done
:fallback
call python -u start.py github --setup %*
goto done
:missing
echo GitHub CLI is needed. Install it from https://cli.github.com/ then run this again.
pause
exit /b 2
:done
set "NMS_GITHUB_RESULT=%ERRORLEVEL%"
if not "%NMS_GITHUB_RESULT%"=="0" echo Setup failed. The message above identifies the next step.
pause
exit /b %NMS_GITHUB_RESULT%
