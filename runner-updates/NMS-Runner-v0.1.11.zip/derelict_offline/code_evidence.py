"""Validate bounded raw exports without executing them or pinning old sessions."""
import hashlib
from . import VERSION
from .common import HERE, read_json, sha256
from .export_evidence import MAX_BODY, MAX_BYTES, KNOWN_BINARY

EVIDENCE = HERE / "evidence/offline-code-evidence-20261011.json"
LATEST_EVIDENCE = HERE / "evidence/offline-code-evidence-20261011-v0.1.2.json"


def verify(evidence, corpus):
    if evidence.get("schema_version") != 1:
        raise ValueError("Unsupported code-evidence schema")
    binary = evidence["binary"]
    digest = binary["sha256"]
    if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise ValueError("Invalid executable hash")
    bodies, total = [], 0
    for body in evidence["function_ranges"]:
        start, end = int(body["start_rva_hex"], 16), int(body["end_rva_exclusive_hex"], 16)
        if not 0 < end - start <= MAX_BODY:
            raise ValueError("Invalid/over-budget code range")
        raw = bytes.fromhex(body["bytes_hex"])
        total += len(raw)
        if total > MAX_BYTES or len(raw) != end - start:
            raise ValueError("Code range size/budget mismatch")
        if hashlib.sha256(raw).hexdigest() != body["sha256"]:
            raise ValueError("Code range hash mismatch")
        if any(start < other_end and other_start < end for other_start, other_end, _ in bodies):
            raise ValueError("Duplicate or overlapping code ranges")
        bodies.append((start, end, raw))
    if total != evidence["byte_count"]:
        raise ValueError("Total byte count mismatch")
    matches = []
    for case in corpus["cases"]:
        for event in case["root_events"]:
            window = event.get("caller_code_window") or {}
            raw = bytes.fromhex(window.get("bytes_hex") or "")
            if not raw:
                continue
            start = int(window["start_offset_hex"], 16)
            try:
                actual = read_ranges(bodies, start, start + len(raw))
            except ValueError:
                actual = None
            matches.append({"case_id": case["case_id"], "recomputed_window_matches":
                            actual == raw})
    return {"schema_version": 1, "prototype_version": VERSION, "binary": binary,
            "range_count": len(bodies), "verified_code_bytes": total,
            "range_hashes_verified": True, "window_checks": matches,
            "supported_arithmetic_binary": digest == KNOWN_BINARY,
            "whole_executable_hash_independently_verified": False,
            "identity_limit": "Full hash reported by exporter; original executable is not uploaded. Historical captures remain unpinned.",
            "root_generation_verified": False, "errors": evidence.get("errors", [])}


def read_ranges(bodies, start, end):
    result, cursor = bytearray(), start
    for begin, stop, raw in sorted(bodies):
        if begin <= cursor < stop:
            take = min(stop, end)
            result.extend(raw[cursor - begin:take - begin])
            cursor = take
            if cursor == end:
                return bytes(result)
    raise ValueError(f"Missing code range {start:08X}..{end:08X}")


def slice_bytes(evidence, start, end):
    bodies = [(int(b["start_rva_hex"], 16), int(b["end_rva_exclusive_hex"], 16),
               bytes.fromhex(b["bytes_hex"])) for b in evidence["function_ranges"]]
    return read_ranges(bodies, start, end)


def inspect():
    from .build_corpus import build
    result = verify(read_json(LATEST_EVIDENCE), build())
    result["evidence_sha256"] = sha256(LATEST_EVIDENCE)
    return result
