"""Recovered integer kernels from binary 13d5060d..., RVA 0062E2B0.

Only seed initialization and a later straight-line state/output calculation.
The intervening 52 selection calls are not implemented. These are NOT root,
room, or crate predictions. All arithmetic follows the captured x64 widths.
"""
from .common import hex64

U32 = (1 << 32) - 1
U64 = (1 << 64) - 1
MULTIPLIER = 0x5A76F899


def seed_state(seed, enabled):
    seed = int(hex64(seed), 16)
    if not isinstance(enabled, bool):
        raise ValueError("An explicit boolean seed flag is required")
    if not enabled:
        return (1, 0)
    low, high = seed & U32, seed >> 32
    rotated = ((low >> 16) | (low << 16)) & U32
    return (low + int(low == 0), rotated ^ high ^ low)


def checked_state(state):
    if len(state) != 2 or any(isinstance(v, bool) or not isinstance(v, int)
                              or not 0 <= v <= U32 for v in state):
        raise ValueError("State must contain two unsigned 32-bit integers")
    return tuple(state)


def scramble(value):
    value ^= value >> 33
    value = (value * 0x64DD81482CBD31D7) & U64
    value ^= value >> 33
    value = (value * 0xE36AA5C613612997) & U64
    return value ^ (value >> 33)


def advance_output(state):
    """Transcribe RVA 0062E36D..0062E3DF for a supplied internal state.

    Its actual call-path input follows missing selection calls, not necessarily
    seed_state(root). Return ((new_low, new_high), mixed_output).
    """
    low, high = checked_state(state)
    first = low * MULTIPLIER + high
    first_low, first_high = first & U32, first >> 32
    second = first_low * MULTIPLIER + first_high
    second_low, second_high = second & U32, second >> 32
    output = scramble((second_low << 32) | first_low)
    return ((second_low, second_high), output)


def diagnose(seed, enabled=True):
    state = seed_state(seed, enabled)
    advanced, value = advance_output(state)
    return {"boundary": "seed-to-initial-random-state-and-supplied-state-arithmetic",
            "seed_hex": hex64(seed), "use_seed_value": enabled,
            "initial_state_u32": list(state), "advanced_state_u32": list(advanced),
            "mixed_output_hex": f"{value:016X}",
            "call_path_input_status": "illustrative-initial-state-not-post-selection-game-state",
            "derelict_root_derived": False, "layout_generated": False}
