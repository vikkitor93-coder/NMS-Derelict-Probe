"""Visible private-environment setup with non-identifying stage logs."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

BUILD = "0.1.3"


class SetupError(Exception):
    pass


def environment_python(root):
    return root / ".unicorn-venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def setup(root, wheel_dir=None):
    root = Path(root).resolve()
    log = root / "latest-install.log"
    # Stages/codes only: no paths, usernames, subprocess output or device IDs.
    def record(stage, status, **fields):
        with log.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"schema_version": 1, "build": BUILD,
                                     "operation": "install-unicorn", "stage": stage,
                                     "status": status, **fields}) + "\n")

    def run(stage, command):
        record(stage, "running")
        try:
            result = subprocess.run(command, cwd=root)
        except OSError as error:
            record(stage, "failed", error_code="process-start-failed")
            raise SetupError(f"Could not start {stage}: {error}") from error
        if result.returncode:
            record(stage, "failed", error_code="nonzero-exit", returncode=result.returncode)
            raise SetupError(f"{stage} failed with exit code {result.returncode}. See the output above.")
        record(stage, "passed")

    log.write_text("", encoding="utf-8")
    print(f"Unicorn installer {BUILD} started.", flush=True)
    record("start", "running")
    if sys.version_info < (3, 10):
        record("python-version", "failed", error_code="python-too-old")
        raise SetupError("Python 3.10 or newer is required. Install it, then rerun Install-Unicorn.cmd.")
    if not (root / "requirements-unicorn.txt").is_file():
        record("requirements", "failed", error_code="missing-package-file")
        raise SetupError("requirements-unicorn.txt is missing. Extract the entire ZIP first.")
    python = environment_python(root)
    print("[1/3] Preparing the private Python environment...", flush=True)
    if not python.is_file():
        run("create-environment", [sys.executable, "-m", "venv", str(root / ".unicorn-venv")])
    if not python.is_file():
        record("create-environment", "failed", error_code="environment-python-missing")
        raise SetupError("Environment creation did not produce Python. Check the error above and folder write access.")
    run("check-environment", [str(python), "-c",
        "import sys; print('Private Python: %s' % sys.version.split()[0], flush=True); sys.exit(0 if sys.version_info >= (3,10) else 1)"])
    print("[2/3] Installing Unicorn 2.1.4 (download progress follows)...", flush=True)
    command = [str(python), "-m", "pip", "install", "--disable-pip-version-check", "--timeout", "30", "--retries", "2"]
    if wheel_dir is not None:
        command += ["--no-index", "--find-links", str(Path(wheel_dir).resolve())]
    command += ["-r", str(root / "requirements-unicorn.txt")]
    run("install-dependency", command)
    print("[3/3] Checking that Unicorn imports and executes x64 code...", flush=True)
    # Check a real mov eax,42 instruction; no game bytes involved in setup.
    smoke = (
        "import unicorn; from unicorn import Uc,UC_ARCH_X86,UC_MODE_64; "
        "from unicorn.x86_const import UC_X86_REG_RAX; "
        "assert unicorn.__version__ == '2.1.4', 'Wrong Unicorn version'; "
        "u=Uc(UC_ARCH_X86,UC_MODE_64); u.mem_map(0x1000,4096); "
        "u.mem_write(0x1000,bytes.fromhex('b82a00000090')); "
        "u.emu_start(0x1000,0x1006,count=2); "
        "assert u.reg_read(UC_X86_REG_RAX)==42, 'Instruction check failed'; "
        "print('Unicorn 2.1.4 instruction check passed.',flush=True)"
    )
    run("verify-unicorn", [str(python), "-c", smoke])
    record("complete", "passed")
    print("\nReady. Run Test-Unicorn.cmd. Setup log: latest-install.log", flush=True)
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--wheel-dir", type=Path, help="Optional local wheel folder for offline setup")
    args = parser.parse_args(argv)
    try:
        return setup(Path(__file__).resolve().parent, args.wheel_dir)
    except (SetupError, OSError) as error:
        print(f"\nSETUP FAILED: {error}", flush=True)
        print("Share latest-install.log. Base diagnostics still work without Unicorn.", flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
