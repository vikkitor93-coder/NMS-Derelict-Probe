"""Read-only derelict research. Never imported by Surveyor."""
VERSION = "0.1.11"
SCHEMA_VERSION = 1
