"""Independent fixed-width transcription of the published mixing equations.

Reference: hadsh/nms_namegen, commit
52ad48affaa4089c8f487a470a888dc9b7a650aa, iprng.py and system.py.
This predicts the PUBLIC SYSTEM SEED, never the derelict root seed.
Current executable agreement is unverified.
"""
from .common import hex64

MASK = 2**64 - 1
ROTATIONS = ((-23, 24), (-5, 27), (-25, 31), (18, -12),
             (6, -22), (-32, -32), (-14, -16), (7, 12),
             (-23, 24), (-5, 27), (-25, 31), (18, -12),
             (6, -22), (-32, -32), (-14, -16), (12, 7), (-23, 24))

def rotate(value, amount):
    amount %= 64
    value &= MASK
    return ((value >> amount) | (value << ((64 - amount) % 64))) & MASK

def mix(seed, block):
    key = seed ^ 0x1BD11BDAA9FC1A22
    a = (seed + block) & MASK
    b = rotate(a, 7) ^ a
    c, d = (b + a) & MASK, (a * 2) & MASK
    for i, (ra, rb) in enumerate(ROTATIONS):
        if i in (7, 8):
            a, b, c, d = b, a, d, c
        x, y = rotate(b, ra) ^ c, rotate(a, rb) ^ d
        a, b, c, d = x & MASK, y & MASK, (y + c) & MASK, (x + d) & MASK
        if i == 1:
            a, d = (a + key + 1) & MASK, (d + key + 1) & MASK
        elif i == 5:
            a, d = (a + seed + 2) & MASK, (d + key + seed + 2) & MASK
        elif i == 9:
            a, b, c, d = (a + 3) & MASK, (b + key) & MASK, (c + key) & MASK, (d + 3 + seed) & MASK
        elif i == 13:
            a, b, c, d = (a + 4) & MASK, (b + seed) & MASK, (c + seed + key) & MASK, (d + 4) & MASK
    return ((c + seed) & MASK, rotate(a, 27) ^ d, d,
            ((rotate(b, -5) ^ c) + 5) & MASK)

def system_seed(address):
    address = int(hex64(address), 16)
    system_id = (address >> 40) & 0xFFF
    if system_id == 0:
        raise ValueError("System index 0 has no supported public reference result")
    offset = system_id - 1
    block, slot = (0, offset) if system_id < 9 else (1 + ((offset - 8) >> 3), (offset - 8) & 7)
    words = mix(address & 0xFFFFFFFFFF, block)
    return (words[slot // 2] >> (32 if slot % 2 else 0)) & 0xFFFFFFFF
