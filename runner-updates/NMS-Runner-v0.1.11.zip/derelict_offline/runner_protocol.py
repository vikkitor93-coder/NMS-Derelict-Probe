"""NMS-specific request contract; deliberately separate from Unspottable."""
import hashlib
import json
import os
from pathlib import Path
import re
import uuid

SCHEMA = 1
ACTIONS = ("offline-check", "offline-check-and-export")


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def validate_request(value):
    if not isinstance(value, dict) or set(value) != {"schema", "request_id", "action", "source_sha256"}:
        raise ValueError("invalid-request-schema")
    if type(value["schema"]) is not int or value["schema"] != SCHEMA:
        raise ValueError("unsupported-request-schema")
    for key, size in (("request_id", 32), ("source_sha256", 64)):
        if not isinstance(value[key], str) or not re.fullmatch("[0-9a-f]{%d}" % size, value[key]):
            raise ValueError("invalid-" + key)
    if value["action"] not in ACTIONS:
        raise ValueError("unsupported-action")
    return value


def digest(files):
    result = hashlib.sha256()
    for name, path in sorted(files.items()):
        raw = Path(path).read_bytes()
        # Length prefixes avoid concatenation ambiguity.
        key = name.encode()
        result.update(len(key).to_bytes(8, "little") + key)
        result.update(len(raw).to_bytes(8, "little") + raw)
    return result.hexdigest()


def publish_request(root, source_sha256, action="offline-check"):
    request = validate_request({"schema": SCHEMA, "request_id": uuid.uuid4().hex,
                                "action": action, "source_sha256": source_sha256})
    path = Path(root) / "requests" / "ready.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name("." + request["request_id"] + ".tmp")
    try:
        temporary.write_text(json.dumps(request, indent=2) + "\n", encoding="utf-8")
        os.link(temporary, path)  # Publish atomically, never replace a pending request.
    finally:
        temporary.unlink(missing_ok=True)
    return request
