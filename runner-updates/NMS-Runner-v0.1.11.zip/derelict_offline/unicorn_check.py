"""Optional, bounded x64 emulation of verified exported instructions.

No attachment, full game binary, guessed imports, asset generation or root
prediction. Each invocation restores registers and clears private memory.
"""
import json
import copy
import random
import struct
import time
from . import VERSION
from .common import HERE, read_json, sha256, hex64
from .code_evidence import slice_bytes, verify
from .export_evidence import KNOWN_BINARY
from .rng_kernel import seed_state, advance_output, checked_state

EVIDENCE = HERE / "evidence/offline-code-evidence-20261011-v0.1.2.json"
PRIOR_EVIDENCE = HERE / "evidence/offline-code-evidence-20261011-v0.1.1.json"
BASE = 0x140000000
DATA, STACK, RETURN = 0x10000000, 0x20000000, 0x30000000
PRIVATE_SIZE = 0x10000
ZERO_COPY = 0x33E4B4C


class EmulationError(ValueError):
    """An incomplete or unsupported emulation, never a generated result."""


def dependency():
    try:
        import unicorn
        from unicorn import x86_const
    except ImportError as error:
        raise EmulationError("Optional Unicorn is missing. Run Install-Unicorn.cmd or python -m pip install unicorn==2.1.4") from error
    if unicorn.__version__ != "2.1.4":
        raise EmulationError(f"Unsupported Unicorn {unicorn.__version__}; install pinned unicorn==2.1.4")
    return unicorn, x86_const


def supplement_vector(evidence):
    """Keep a working dependency omitted by the newer export's bounded quota.

    Only this exact reviewed helper is eligible. Never mix binary identities or
    overwrite new ranges. Both original exports retain their separate hashes.
    """
    verify(evidence, {"cases": []})
    prior = read_json(PRIOR_EVIDENCE)
    verify(prior, {"cases": []})
    if evidence["binary"] != prior["binary"]:
        raise EmulationError("Supplementary dependency executable identity mismatch")
    start, end = 0x2BF9A00, 0x2BF9B96
    expected = slice_bytes(prior, start, end)
    overlaps = [b for b in evidence["function_ranges"] if
                int(b["start_rva_hex"], 16) < end and start < int(b["end_rva_exclusive_hex"], 16)]
    if overlaps:
        if slice_bytes(evidence, start, end) != expected:
            raise EmulationError("Supplementary vector dependency conflicts with latest export")
        return evidence
    result = copy.deepcopy(evidence)
    bodies = [b for b in prior["function_ranges"] if
              start <= int(b["start_rva_hex"], 16) and int(b["end_rva_exclusive_hex"], 16) <= end]
    result["function_ranges"].extend(copy.deepcopy(bodies))
    result["byte_count"] += len(expected)
    verify(result, {"cases": []})
    return result


class Machine:
    def __init__(self, evidence, spans, zero_copy=False):
        # Validate *all* supplied ranges before executing any of them.
        verify(evidence, {"cases": []})
        if evidence["binary"]["sha256"] != KNOWN_BINARY:
            raise EmulationError("Unsupported executable identity; fixed RVAs refused")
        if int(evidence["binary"]["preferred_image_base_hex"], 16) != BASE:
            raise EmulationError("Unsupported image base")
        self.u, self.x = dependency()
        self.vm = self.u.Uc(self.u.UC_ARCH_X86, self.u.UC_MODE_64)
        self.spans = [(BASE + a, BASE + b) for a, b in spans]
        self.zero_copy = zero_copy
        pages = set()
        for start, end in spans:
            pages.update(range((BASE + start) & ~4095, (BASE + end + 4095) & ~4095, 4096))
        if zero_copy:
            pages.add((BASE + ZERO_COPY) & ~4095)
        for page in sorted(pages):
            self.vm.mem_map(page, 4096, self.u.UC_PROT_ALL)
            self.vm.mem_write(page, b"\xCC" * 4096)
        for start, end in spans:
            self.vm.mem_write(BASE + start, slice_bytes(evidence, start, end))
        if zero_copy:
            # Explicit model of the zero-byte path ONLY. The original external
            # helper is absent; nonzero copy and arbitrary imports are refused.
            self.vm.mem_write(BASE + ZERO_COPY, b"\xC3")
        for page in sorted(pages):
            self.vm.mem_protect(page, 4096, self.u.UC_PROT_READ | self.u.UC_PROT_EXEC)
        for address in (DATA, STACK):
            self.vm.mem_map(address, PRIVATE_SIZE, self.u.UC_PROT_READ | self.u.UC_PROT_WRITE)
        self.vm.mem_map(RETURN, 4096, self.u.UC_PROT_READ | self.u.UC_PROT_EXEC)
        self.vm.hook_add(self.u.UC_HOOK_CODE, self._instruction)
        self.vm.hook_add(self.u.UC_HOOK_MEM_INVALID, self._fault)
        self.clean = self.vm.context_save()
        self.reset()

    def reset(self):
        self.vm.context_restore(self.clean)
        self.vm.mem_write(DATA, bytes(PRIVATE_SIZE))
        self.vm.mem_write(STACK, bytes(PRIVATE_SIZE))
        self.error, self.completed = None, False
        self.instructions, self.models = 0, []
        self.stop = RETURN
        # Windows x64 entry: RSP = 8 mod 16, caller shadow space is available.
        rsp = STACK + PRIVATE_SIZE - 0x108
        self.reg("RSP", rsp)
        self.vm.mem_write(rsp, struct.pack("<Q", RETURN))

    def reg(self, name, value=None):
        register = getattr(self.x, "UC_X86_REG_" + name)
        if value is None:
            return self.vm.reg_read(register)
        self.vm.reg_write(register, value)

    def _instruction(self, vm, address, size, _):
        if address == self.stop:
            self.completed = True
            vm.emu_stop()
            return
        self.instructions += 1
        if self.zero_copy and address == BASE + ZERO_COPY:
            if self.reg("R8") != 0:
                self.error = "Zero-byte copy model refuses nonzero length"
                vm.emu_stop()
                return
            self.models.append({"rva_hex": f"{ZERO_COPY:08X}", "model": "zero-byte-copy-only", "length": 0})
            self.reg("RAX", self.reg("RCX"))
            return
        if not any(start <= address and address + size <= end for start, end in self.spans):
            self.error = f"Missing executable code at RVA {address - BASE:08X}"
            vm.emu_stop()

    def _fault(self, vm, access, address, size, value, _):
        if access in (self.u.UC_MEM_FETCH_UNMAPPED, self.u.UC_MEM_FETCH_PROT):
            self.error = f"Missing executable code at RVA {address - BASE:08X}"
        else:
            self.error = f"Unmapped/protected memory at 0x{address:X}, size {size}, access {access}"
        return False

    def execute(self, start, stop=RETURN, limit=10000):
        if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 100000:
            raise EmulationError("Instruction limit must be 1..100000")
        self.stop = stop
        try:
            # Hooks, count and timeout independently bound execution.
            self.vm.emu_start(BASE + start, stop, timeout=1000000, count=limit)
        except self.u.UcError as error:
            raise EmulationError(self.error or f"Unicorn stopped: {error}") from error
        if self.error:
            raise EmulationError(self.error)
        # emu_start's end address stops BEFORE the end instruction/hook.
        if self.reg("RIP") == stop:
            self.completed = True
        if not self.completed:
            raise EmulationError(f"Instruction/time limit reached at RVA {self.reg('RIP') - BASE:08X}")
        return {"instructions": self.instructions, "environment_models": list(self.models)}


def descriptor(seed, flag, secondary, secondary_flag, count=0, pointer=0):
    # Retain padding too, so MOVUPS copies are checked byte-for-byte.
    result = bytearray(b"\xA5" * 48)
    struct.pack_into("<IIQ", result, 0, count, count, pointer)
    struct.pack_into("<Q", result, 16, seed)
    result[24] = flag
    struct.pack_into("<Q", result, 32, secondary)
    result[40] = secondary_flag
    return bytes(result)


class Kernels:
    def __init__(self, evidence):
        evidence = supplement_vector(evidence)
        self.init = Machine(evidence, [(0x62E2E3, 0x62E306)])
        self.output = Machine(evidence, [(0x62E36D, 0x62E3DF)])
        self.copy = Machine(evidence, [(0x227A40, 0x227AA9), (0x2BF9A00, 0x2BF9B96),
                                       (0x2C20E90, 0x2C21131)], zero_copy=True)
        self.remove = Machine(evidence, [(0x640EA0, 0x640F30)])

    def initialization(self, seed):
        seed = int(hex64(seed), 16)
        m = self.init
        m.reset()
        m.reg("RBP", DATA + 0x100)
        m.reg("R9", seed)
        m.execute(0x62E2E3, BASE + 0x62E306)
        return struct.unpack("<II", m.vm.mem_read(DATA + 0x148, 8))

    def state_output(self, state):
        state = checked_state(state)
        m = self.output
        m.reset()
        m.reg("RBP", DATA + 0x100)
        m.vm.mem_write(DATA + 0x148, struct.pack("<II", *state))
        m.execute(0x62E36D, BASE + 0x62E3DF)
        return ((m.reg("RDX") & 0xFFFFFFFF, m.reg("R8") & 0xFFFFFFFF), m.reg("RBX"))

    def copy_descriptor(self, source):
        if len(source) != 48:
            raise ValueError("Descriptor must contain exactly 48 bytes")
        m = self.copy
        m.reset()
        m.vm.mem_write(DATA, source)
        m.vm.mem_write(DATA + 0x100, b"\xCC" * 48)
        m.reg("RCX", DATA + 0x100)
        m.reg("RDX", DATA)
        trace = m.execute(0x227A40)
        if m.reg("RAX") != DATA + 0x100:
            raise EmulationError("Unexpected descriptor return pointer")
        return bytes(m.vm.mem_read(DATA + 0x100, 48)), trace

    def remove_identifier(self, identifiers, query, source):
        if len(identifiers) > 512 or len(query) != 32 or any(len(item) != 32 for item in identifiers) or len(source) != 48:
            raise ValueError("Require <=512 identifiers of 32 bytes and a 48-byte descriptor")
        m = self.remove
        m.reset()
        obj = bytearray(source)
        struct.pack_into("<IIQ", obj, 0, len(identifiers), len(identifiers), DATA + 0x1000)
        m.vm.mem_write(DATA, bytes(obj))
        if identifiers:
            m.vm.mem_write(DATA + 0x1000, b"".join(identifiers))
        m.vm.mem_write(DATA + 0x100, query)
        m.reg("RCX", DATA)
        m.reg("RDX", DATA + 0x100)
        trace = m.execute(0x640EA0)
        result = bytes(m.vm.mem_read(DATA, 48))
        count = struct.unpack_from("<I", result, 4)[0]
        if count > len(identifiers):
            raise EmulationError("Unexpected output identifier count")
        items = [bytes(m.vm.mem_read(DATA + 0x1000 + i * 32, 32)) for i in range(count)]
        return items, result, trace


def check(count=1000):
    if not isinstance(count, int) or isinstance(count, bool) or not 1 <= count <= 10000:
        raise ValueError("Comparison count must be 1..10000")
    from .build_corpus import build
    corpus, evidence = build(), read_json(EVIDENCE)
    code = verify(evidence, corpus)
    kernels = Kernels(evidence)
    rng = random.Random(0x705)
    roots = [int(r["seed_hex"], 16) for c in corpus["cases"] for r in c["root_seeds"]]
    seeds = [0, 1, 0xFFFFFFFF, 1 << 32, (1 << 64) - 1, *roots] + [rng.getrandbits(64) for _ in range(count)]
    states = [(0, 0), (1, 0), (0xFFFFFFFF, 0), (0xFFFFFFFF, 0xFFFFFFFF)] + [(rng.getrandbits(32), rng.getrandbits(32)) for _ in range(count)]
    start = time.perf_counter()
    for seed in seeds:
        if kernels.initialization(seed) != seed_state(seed, True):
            raise EmulationError(f"Seed initialization mismatch: {seed:016X}")
    for state in states:
        if kernels.state_output(state) != advance_output(state):
            raise EmulationError(f"State/output mismatch: {state}")
    arithmetic_seconds = time.perf_counter() - start
    sources = [descriptor(s, flag, rng.getrandbits(64), other) for s in seeds[:5] for flag in (0, 1) for other in (0, 1)]
    sources += [descriptor(rng.getrandbits(64), rng.randrange(256), rng.getrandbits(64), rng.randrange(256)) for _ in range(count)]
    for case in corpus["cases"]:
        for event in case["root_events"]:
            a, b = event["primary_seed"], event["secondary_seed"]
            sources.append(descriptor(int(a["seed_hex"], 16), int(a["use_seed_value"]), int(b["seed_hex"], 16), int(b["use_seed_value"])))
    for source in sources:
        actual, trace = kernels.copy_descriptor(source)
        if actual != source or len(trace["environment_models"]) != 1:
            raise EmulationError("Empty-vector descriptor copy mismatch")
    removals = [([], bytes(32)), ([bytes(32)], bytes(32)), ([bytes(32)], b"\x01" * 32)]
    for n in range(count):
        items = [rng.getrandbits(256).to_bytes(32, "little") for _ in range(rng.randrange(1, 25))]
        if n % 3 == 0:
            items.append(items[0])  # duplicate match: only the first is removed
        query = items[rng.randrange(len(items))] if n % 2 else rng.getrandbits(256).to_bytes(32, "little")
        removals.append((items, query))
    for items, query in removals:
        expected = items[:]
        if query in expected:
            index = expected.index(query)
            expected[index] = expected[-1]
            expected.pop()
        source = sources[0]
        actual, obj, trace = kernels.remove_identifier(items, query, source)
        if actual != expected or obj[16:] != source[16:] or trace["environment_models"]:
            raise EmulationError("Identifier swap-delete or seed preservation mismatch")
    try:
        kernels.copy_descriptor(descriptor(1, 1, 2, 0, count=1, pointer=DATA + 0x1000))
    except EmulationError as error:
        blocked = str(error)
        if "0x145292041" not in blocked:
            raise
    else:
        raise EmulationError("Nonempty descriptor unexpectedly accepted absent allocator global state")
    return {"schema_version": 1, "prototype_version": VERSION, "validation_engine": "Unicorn 2.1.4 x86-64",
            "evidence_sha256": sha256(EVIDENCE), "code_validation": code,
            "supplementary_dependency": {"file": PRIOR_EVIDENCE.name, "sha256": sha256(PRIOR_EVIDENCE),
                                         "rva_range_hex": ["02BF9A00", "02BF9B96"], "bytes": 406,
                                         "identity_matches_latest_export": True},
            "comparisons": {"enabled_seed_initialization": len(seeds), "supplied_state_output": len(states),
                            "empty_vector_descriptor_copy": len(sources), "identifier_swap_delete": len(removals)},
            "mismatches": 0, "expected_failure": {"nonempty_descriptor_copy": blocked},
            "allocator_boundary": {"code_supplied_and_executed": True, "first_absent_global_rva_hex": "05292041",
                                   "global_state_model_supplied": False},
            "environment_models": [{"rva_hex": f"{ZERO_COPY:08X}", "behavior": "return destination only when byte length is zero; otherwise refuse",
                                    "identity": "copy-like ABI inferred; original helper not exported"}],
            "arithmetic_batch": {"cases": len(seeds) + len(states), "seconds": arithmetic_seconds,
                                 "cases_per_second": (len(seeds) + len(states)) / arithmetic_seconds,
                                 "includes": ["register/memory reset", "instruction hooks", "Unicorn arithmetic", "Python comparison"],
                                 "excludes": ["initialization of emulator", "descriptor functions", "root derivation", "layout generation", "game baseline"],
                                 "end_to_end_speedup": None},
            "limits": ["Historical captures remain unpinned; captured seed values are test inputs only",
                       "Descriptor vectors are deliberately synthetic and empty in copy checks",
                       "Initialization block tests enabled-seed arithmetic only",
                       "RNG function is a palette candidate, not established dungeon layout generation",
                       "Nonempty clone reaches supplied allocator; its global/TLS state is absent; arbitrary imports fail"],
            "root_derivation_verified": False, "layout_generation_verified": False, "errors": []}


if __name__ == "__main__":
    print(json.dumps(check(), indent=2))
