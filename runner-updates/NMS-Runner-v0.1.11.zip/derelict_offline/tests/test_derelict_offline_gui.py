import contextlib
import io
import json
import os
from pathlib import Path
import queue
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from derelict_offline import local_runner as worker
from derelict_offline.gui_process import WorkerProcess, worker_python
from derelict_offline.runner_protocol import atomic_json, publish_request


class GuiWorkerTests(unittest.TestCase):
    def test_pause_control_is_versioned_and_rejects_invalid_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.assertFalse(worker.is_paused(root))
            worker.set_paused(root, True)
            self.assertTrue(worker.is_paused(root))
            worker.set_paused(root, False)
            self.assertFalse(worker.is_paused(root))
            for value in ({"schema": True, "paused": False}, {"schema": 1, "paused": "true"},
                          {"schema": 1, "paused": False, "command": "other"}):
                atomic_json(root / ".local/runner-control.json", value)
                with self.assertRaisesRegex(ValueError, "invalid-runner-control"):
                    worker.is_paused(root)

    def test_pause_preserves_pending_job_without_claiming_or_running(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            root = Path(tmp)
            publish_request(root, "a" * 64)
            worker.set_paused(root, True)
            with patch.object(worker, "healthy_python", return_value=sys.executable), \
                 patch.object(worker, "execute") as execute, \
                 patch.object(worker.time, "sleep", side_effect=KeyboardInterrupt):
                worker.watch(root)
            execute.assert_not_called()
            self.assertTrue((root / "requests/ready.json").is_file())
            self.assertFalse((root / ".local/claimed-request.json").exists())

    def test_probe_hides_expected_missing_import_then_reports_repair(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()) as output:
            with patch.object(worker, "run_command", side_effect=[1, 0]) as command:
                worker.healthy_python(Path(tmp))
            self.assertFalse(command.call_args_list[0].kwargs["show_output"])
            self.assertIn("Installing/repairing", output.getvalue())

    def test_process_output_streams_before_exit(self):
        seen = threading.Event()
        class Sink(io.StringIO):
            def write(self, value):
                if "READY" in value:
                    seen.set()
                return super().write(value)
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(Sink()):
            thread = threading.Thread(target=worker.run_command, args=([sys.executable, "-u", "-c",
                    "import time;print('READY',flush=True);time.sleep(0.4)"], Path(tmp)))
            thread.start()
            self.assertTrue(seen.wait(2), "No live output")
            self.assertTrue(thread.is_alive(), "Output was delayed until exit")
            thread.join(3)
            self.assertFalse(thread.is_alive())

    def test_pythonw_supervisor_uses_console_python_for_worker(self):
        with patch("derelict_offline.gui_process.sys.executable", "C:/Python/pythonw.exe"):
            self.assertTrue(worker_python().endswith("python.exe"))

    def test_owned_process_start_stop_and_duplicate_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "start.py").write_text("import time\nprint('READY',flush=True)\ntime.sleep(20)\n")
            process = WorkerProcess(root)
            try:
                process.start(["runner"])
                self.assertTrue(process.active)
                with self.assertRaises(ValueError):
                    process.start(["runner"])
                self.assertEqual("READY", process.messages.get(timeout=3))
                process.stop()
                deadline = time.monotonic() + 7
                while process.active and time.monotonic() < deadline:
                    process.tick()
                    time.sleep(0.02)
                self.assertFalse(process.active)
            finally:
                if process.active:
                    process.process.kill()
                    process.process.wait()
                process.finish()

    def test_gui_activity_status_does_not_spin_while_idle_or_failed(self):
        try:
            from derelict_offline.runner_gui import display_status
        except ImportError:
            self.skipTest("Python installed without Tk")
        self.assertTrue(display_status({"stage": "tests", "status": "running"})[1])
        self.assertFalse(display_status({"stage": "watching", "status": "waiting-for-source-change"})[1])
        self.assertFalse(display_status({"stage": "tests", "status": "failed"})[1])
        self.assertIn("Paused", display_status({"stage": "runner", "status": "paused"})[0])


if __name__ == "__main__":
    unittest.main()
