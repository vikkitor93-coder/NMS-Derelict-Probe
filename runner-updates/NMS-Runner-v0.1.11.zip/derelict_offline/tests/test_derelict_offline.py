import copy
import json
import struct
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from derelict_offline.build_corpus import build, captured_roots
from derelict_offline.common import HERE, effective_seed, read_json
from derelict_offline.export_evidence import collect, connected_ranges
from derelict_offline.prototype import replay, root_prediction
from derelict_offline.public_seed import system_seed
from derelict_offline.run import main, validate

class OfflineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.corpus = build()
        cls.index = read_json(HERE / "fixtures/room-crate-index.json")

    def test_real_replay_matches_existing_analyzer(self):
        report = validate(self.corpus, self.index)
        self.assertTrue(report["all_replays_match"])
        self.assertEqual([37, 37, 23, 23], [r["result"]["target_containers"] for r in report["results"]])
        self.assertFalse(report["root_generation_verified"])

    def test_repeat_pairs_same_root_and_captured_layout(self):
        cases = self.corpus["cases"]
        for a, b in ((cases[0], cases[1]), (cases[2], cases[3])):
            self.assertEqual(a["root_seeds"][0]["seed_hex"], b["root_seeds"][0]["seed_hex"])
            self.assertEqual(a["layout_signature_sha256"], b["layout_signature_sha256"])
            self.assertEqual(a["layout_multiset_signature_sha256"], b["layout_multiset_signature_sha256"])

    def test_runtime_counters_agree_where_available(self):
        results = validate(self.corpus, self.index)["results"]
        self.assertEqual([None, True, True, True], [r["matches_runtime_asset_counter"] for r in results])
        self.assertTrue(all(not r["independent_physical_count_verified"] for r in results))

    def test_table_room_count_failure_is_visible(self):
        results = validate(self.corpus, self.index)["results"]
        self.assertTrue(all(r["table_count_matches"] is False for r in results))
        self.assertEqual([10, 10, 9, 9], [r["captured_main_room_groups"] for r in results])

    def test_missing_scene_never_claims_complete_count(self):
        case = copy.deepcopy(self.corpus["cases"][0])
        case["selected_scene_groups"][0]["scene_paths"].append({"path": "UNKNOWN.SCENE.MBIN", "instances": 1})
        result = replay(case, self.index)
        self.assertFalse(result["complete"])
        self.assertIsNone(result["result"])
        self.assertFalse(result["matches_existing_analyzer"])
        self.assertTrue(result["unresolved_scenes"])

    def test_empty_input_not_verified_zero(self):
        case = copy.deepcopy(self.corpus["cases"][0])
        case["selected_scene_groups"] = []
        self.assertFalse(replay(case, self.index)["complete"])

    def test_multiplicity_preserved_and_bad_multiplicity_rejected(self):
        case = copy.deepcopy(self.corpus["cases"][0])
        selection = case["selected_scene_groups"][0]["scene_paths"][0]
        selection["instances"] = -1
        with self.assertRaises(ValueError):
            replay(case, self.index)

    def test_duplicate_index_rejected(self):
        index = copy.deepcopy(self.index)
        index["entries"].append(index["entries"][0])
        with self.assertRaises(ValueError):
            replay(self.corpus["cases"][0], index)

    def test_incomplete_dependency_rejected(self):
        index = copy.deepcopy(self.index)
        path = self.corpus["cases"][0]["selected_scene_groups"][0]["scene_paths"][0]["path"]
        row = next(r for r in index["entries"] if r["scene_path"] == path)
        row["unresolved_dependencies"] = ["MISSING"]
        self.assertFalse(replay(self.corpus["cases"][0], index)["complete"])

    def test_missing_executable_identity_quarantined(self):
        self.assertEqual(0, self.corpus["summary"]["strictly_pinned_cases"])
        self.assertTrue(all(c["identity_status"] == "quarantined-unpinned" for c in self.corpus["cases"]))

    def test_disabled_and_unknown_flags_do_not_produce_effective_seed(self):
        self.assertIsNone(effective_seed({"seed_hex": "1234", "use_seed_value": False}))
        self.assertIsNone(effective_seed({"seed_hex": "1234"}))
        self.assertEqual("0000000000001234", effective_seed({"seed_hex": "1234", "use_seed_value": True}))
        self.assertEqual("0000000000000000", effective_seed({"seed_hex": "0", "use_seed_value": True}))

    def test_raw_flag_changes_and_zero_seeds_not_collapsed(self):
        events = [{"kind": "resource_add", "resource_name": "MODELS/SPACE/POI/DUNGEON.SCENE.MBIN",
                   "universe_address_hex_at_capture": "1234",
                   "primary_seed": {"seed_hex": "0", "use_seed_value": flag}} for flag in (True, False)]
        events.append({**events[0], "universe_address_hex_at_capture": "5678"})
        roots = captured_roots({"trace": {"events": events}}, "1234")
        self.assertEqual(2, len(roots))
        self.assertEqual([True, False], [r["use_seed_value"] for r in roots])

    def test_different_game_identities_are_partitioned(self):
        with tempfile.TemporaryDirectory() as tmp:
            import shutil
            root = Path(tmp) / "fixtures"
            shutil.copytree(HERE / "fixtures", root)
            manifest = read_json(root / "manifest.json")
            manifest["sessions"][0]["game_identity"]["game_version"] = "historical-other-version"
            (root / "manifest.json").write_text(json.dumps(manifest))
            result = build(root / "manifest.json")
            self.assertEqual(2, len(result["correlations_by_identity"]))

    def test_existing_parser_and_saved_fragment_checks(self):
        from derelict_offline.audit import audit
        with patch("derelict_offline.audit.write_json"):
            result = audit()
        self.assertTrue(result["parser_roundtrip_matches"])
        self.assertTrue(result["saved_fragment_hash_verified"])
        self.assertEqual(20, result["root_observations"])

    def test_public_reference_anchors(self):
        for address, expected in (("00001A0004E84EFD", 0xB006BAB6),
                                  ("0001550006607CAC", 0x9E1A7905),
                                  ("0001680006607CAC", 0x8A6EF089)):
            self.assertEqual(expected, system_seed(address))

    def test_public_seed_never_presented_as_root(self):
        result = root_prediction("0000760006606CAB")
        self.assertIsNone(result["derelict_root_seed_hex"])
        self.assertIsNone(result["room_layout"])
        with self.assertRaises(ValueError):
            system_seed("0000000006606CAB")
        with self.assertRaises(ValueError):
            system_seed(-1)

    def test_scene_replay_does_not_depend_on_root_seed(self):
        case = copy.deepcopy(self.corpus["cases"][0])
        original = replay(case, self.index)["result"]
        case["root_seeds"][0]["seed_hex"] = "0000000000000001"
        result = replay(case, self.index)
        self.assertEqual(original, result["result"])
        self.assertFalse(result["root_to_layout_implemented"])

    def test_fixture_tampering_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            import shutil
            root = Path(tmp) / "fixtures"
            shutil.copytree(HERE / "fixtures", root)
            (root / "room-crate-index.json").write_text("{}")
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                build(root / "manifest.json")

    def test_safe_diagnostic_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "error.json"
            with patch("builtins.print"):
                code = main(["diagnose", "--case", "missing", "--out", str(output)])
            self.assertEqual(2, code)
            self.assertEqual(["Unknown case"], read_json(output)["errors"])

    def test_chain_closure_includes_parent_and_sibling_funclets(self):
        a, b, c = (1, 10, 100), (10, 20, 200), (20, 30, 300)
        parents = {a: None, b: a, c: b}
        self.assertEqual([a, b, c], connected_ranges(None, None, [a, b, c], b, parents))

    def test_export_synthetic_pe_and_mismatch_gate(self):
        with tempfile.TemporaryDirectory() as tmp:
            exe = Path(tmp) / "NMS.exe"
            blob = bytearray(0x900)
            blob[:2] = b"MZ"
            struct.pack_into("<I", blob, 0x3C, 0x80)
            blob[0x80:0x84] = b"PE\0\0"
            struct.pack_into("<HHIIIHH", blob, 0x84, 0x8664, 3, 123, 0, 0, 0xF0, 0x22)
            struct.pack_into("<H", blob, 0x98, 0x20B)
            struct.pack_into("<Q", blob, 0x98 + 24, 0x140000000)
            for i, (name, va, rawoff) in enumerate(((b".text", 0x1000, 0x400),
                                                   (b".pdata", 0x2000, 0x600),
                                                   (b".xdata", 0x3000, 0x800))):
                off = 0x80 + 24 + 0xF0 + i * 40
                blob[off:off + len(name)] = name
                struct.pack_into("<IIII", blob, off + 8, 0x100, va, 0x100, rawoff)
                struct.pack_into("<I", blob, off + 36, 0x60000020 if i == 0 else 0x40000040)
            raw = bytes.fromhex("E800000000C3")
            blob[0x400:0x406] = raw
            struct.pack_into("<III", blob, 0x600, 0x1000, 0x1006, 0x3000)
            blob[0x800] = 1
            exe.write_bytes(blob)
            event = {"utc": "test", "caller_return_offset_hex": "00001005",
                     "caller_code_window": {"start_offset_hex": "00001000", "bytes_hex": raw.hex()}}
            corpus = {"cases": [{"case_id": "synthetic", "root_events": [event]}]}
            result = collect(exe, corpus)
            self.assertEqual(raw.hex().upper(), result["function_ranges"][0]["bytes_hex"])
            self.assertTrue(result["window_checks"][0]["window_matches"])
            self.assertEqual([], result["known_binary_helpers"])
            self.assertFalse(result["emulation_ready"])
            event["caller_code_window"]["bytes_hex"] = "909090909090"
            with self.assertRaisesRegex(ValueError, "No bundled root-call window"):
                collect(exe, corpus)

if __name__ == "__main__":
    unittest.main()
