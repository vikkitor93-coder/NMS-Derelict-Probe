import contextlib
import io
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from derelict_offline.install_unicorn import setup, environment_python, SetupError
from derelict_offline.package_experiment import package
from derelict_offline.common import HERE


class InstallerTests(unittest.TestCase):
    def fixture(self, root):
        (root / "requirements-unicorn.txt").write_text("unicorn==2.1.4\n")

    def test_existing_environment_is_preserved_and_verified(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.fixture(root)
            python = environment_python(root)
            python.parent.mkdir(parents=True)
            python.write_bytes(b"existing-python")
            with patch("derelict_offline.install_unicorn.subprocess.run", return_value=subprocess.CompletedProcess([], 0)) as run, contextlib.redirect_stdout(io.StringIO()) as out:
                self.assertEqual(0, setup(root))
            self.assertEqual(b"existing-python", python.read_bytes())
            self.assertEqual(3, run.call_count)
            self.assertIn("[1/3]", out.getvalue())
            self.assertIn("[3/3]", out.getvalue())
            rows = [json.loads(line) for line in (root / "latest-install.log").read_text().splitlines()]
            self.assertEqual("passed", rows[-1]["status"])
            self.assertNotIn(str(root), (root / "latest-install.log").read_text())
            smoke = run.call_args_list[-1].args[0][-1]
            self.assertIn("u.emu_start", smoke)

    def test_failed_environment_creation_stops_before_pip_and_logs_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.fixture(root)
            with patch("derelict_offline.install_unicorn.subprocess.run", return_value=subprocess.CompletedProcess([], 7)) as run, contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(SetupError, "create-environment.*7"):
                    setup(root)
            self.assertEqual(1, run.call_count)
            row = json.loads((root / "latest-install.log").read_text().splitlines()[-1])
            self.assertEqual("create-environment", row["stage"])
            self.assertEqual(7, row["returncode"])

    def test_pip_failure_does_not_claim_ready_or_run_verification(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.fixture(root)
            python = environment_python(root)
            python.parent.mkdir(parents=True)
            python.write_bytes(b"existing")
            with patch("derelict_offline.install_unicorn.subprocess.run", side_effect=[subprocess.CompletedProcess([], 0), subprocess.CompletedProcess([], 1)]) as run, contextlib.redirect_stdout(io.StringIO()) as out:
                with self.assertRaisesRegex(SetupError, "install-dependency"):
                    setup(root)
            self.assertEqual(2, run.call_count)
            self.assertNotIn("Ready.", out.getvalue())
            self.assertEqual("failed", json.loads((root / "latest-install.log").read_text().splitlines()[-1])["status"])

    def test_incomplete_zip_has_visible_actionable_error(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()) as out:
            with self.assertRaisesRegex(SetupError, "Extract the entire ZIP"):
                setup(Path(tmp))
            self.assertIn("installer 0.1.3 started", out.getvalue())

    def test_archive_launchers_use_windows_line_endings_and_visible_start(self):
        import zipfile
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "standalone.zip"
            with patch("derelict_offline.package_experiment.members", return_value=({"Install-Unicorn.cmd": HERE / "Install-Unicorn.cmd"}, True)):
                package(path)
            with zipfile.ZipFile(path) as archive:
                raw = archive.read("derelict_offline/Install-Unicorn.cmd")
            self.assertIn(b"\r\n", raw)
            self.assertNotIn(b"\n", raw.replace(b"\r\n", b""))
            self.assertLess(raw.index(b"echo Starting Unicorn"), raw.index(b"call py.exe"))
            self.assertIn(b"pause\r\n", raw)
            self.assertIn(b"latest-install.log", raw)


if __name__ == "__main__":
    unittest.main()
