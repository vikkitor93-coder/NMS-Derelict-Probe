import base64
import contextlib
import io
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import zipfile
from derelict_offline import github_exchange as exchange
from derelict_offline import local_runner as worker
from derelict_offline.runner_protocol import atomic_json


class FakeGitHub:
    """Git object model: uploaded blobs are invisible until the branch moves."""
    def __init__(self):
        self.calls = []
        self.blobs = {}
        self.trees = {"initial-tree": {"README.md": "original"}}
        self.commits = {"initial": "initial-tree"}
        self.head = None
        self.fail = None

    def api(self, endpoint, method="GET", body=None, missing_ok=False):
        self.calls.append((endpoint, method, body))
        if endpoint == self.fail:
            raise exchange.TransportError("github-api-failed")
        if endpoint == "":
            return {"default_branch": "main"}
        if endpoint.startswith("git/ref/"):
            head = "initial" if endpoint.endswith("/main") else self.head
            return {"object": {"sha": head}} if head else None
        if endpoint == "git/refs":
            self.head = body["sha"]
            return {}
        if endpoint.startswith("contents/"):
            path, ref = endpoint[9:].split("?ref=")
            tree = self.trees[self.commits[ref]]
            if path not in tree:
                return None
            return {"content": base64.b64encode(self.blobs[tree[path]]).decode()}
        if method == "GET" and endpoint.startswith("git/commits/"):
            return {"tree": {"sha": self.commits[endpoint.rsplit("/", 1)[1]]}}
        if endpoint == "git/blobs":
            sha = "blob" + str(len(self.blobs))
            self.blobs[sha] = base64.b64decode(body["content"])
            return {"sha": sha}
        if endpoint == "git/trees":
            sha = "tree" + str(len(self.trees))
            self.trees[sha] = {**self.trees[body["base_tree"]], **{v["path"]: v["sha"] for v in body["tree"]}}
            return {"sha": sha}
        if endpoint == "git/commits":
            sha = "commit" + str(len(self.commits))
            self.commits[sha] = body["tree"]
            return {"sha": sha}
        if method == "PATCH":
            assert body["force"] is False
            self.head = body["sha"]
            return {}
        raise AssertionError(endpoint)

    def visible(self):
        return self.trees[self.commits[self.head]] if self.head else {}


class GitHubTests(unittest.TestCase):
    def fixture(self, root, identifier="a" * 32, status="passed"):
        folder = root / "reports" / identifier
        folder.mkdir(parents=True)
        result = {"schema": 1, "schema_version": 1, "request_id": identifier, "action": "offline-check",
                  "source_sha256": "b" * 64, "status": status, "prototype_version": "test", "errors": []}
        atomic_json(folder / "result.json", result)
        (folder / "latest.log").write_text('{"stage":"complete"}\n')
        (folder / "AI_HANDOFF.md").write_text("exact tested handoff")
        (folder / "GITHUB_CHECK_PROMPT.md").write_text("scheduled task instructions")
        with zipfile.ZipFile(folder / "source.zip", "w") as archive:
            archive.writestr("derelict_offline/start.py", "test source")
        worker.bundle(folder)
        return folder

    def test_unconfigured_worker_has_no_network_transport(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(exchange, "command") as command:
            self.assertIsNone(exchange.config(Path(tmp)))
            command.assert_not_called()

    def test_config_rejects_main_urls_and_arbitrary_commands(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            good = {"schema": 1, "repo": exchange.REPO, "branch": exchange.BRANCH}
            for value in ({**good, "branch": "main"}, {**good, "repo": "https://github.com/a/b"},
                          {**good, "command": "echo test"}, {**good, "schema": True}, {**good, "repo": "../repo"}):
                atomic_json(root / ".local/github-config.json", value)
                with self.assertRaisesRegex(exchange.TransportError, "config-invalid"):
                    exchange.config(root)

    def test_allowlist_hashes_and_private_file_exclusion(self):
        import hashlib
        with tempfile.TemporaryDirectory() as tmp:
            folder = self.fixture(Path(tmp))
            (folder / "token.txt").write_text("secret")
            (folder / "NMS.exe").write_bytes(b"private game")
            data, manifest = exchange.prepare(folder)
            self.assertEqual(set(data), {"result.json", "latest.log", "source.zip", "runner-evidence.zip",
                                         "AI_HANDOFF.md", "GITHUB_CHECK_PROMPT.md"})
            self.assertEqual(hashlib.sha256(data["source.zip"]).hexdigest(), manifest["files"]["source.zip"]["sha256"])
            self.assertNotIn(str(folder), json.dumps(manifest))

    def test_rejects_running_invalid_id_symlink_oversize_and_extra_zip_entries(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = self.fixture(Path(tmp), status="running")
            with self.assertRaises(exchange.TransportError):
                exchange.prepare(folder)
            result = json.loads((folder / "result.json").read_text())
            result["status"] = "passed"
            atomic_json(folder / "result.json", result)
            worker.bundle(folder)
            with zipfile.ZipFile(folder / "runner-evidence.zip", "a") as archive:
                archive.writestr("token.txt", "secret")
            with self.assertRaises(exchange.TransportError):
                exchange.prepare(folder)
            worker.bundle(folder)
            with patch.object(exchange, "MAX_FILE", 1):
                with self.assertRaisesRegex(exchange.TransportError, "too-large"):
                    exchange.prepare(folder)
            # Exercise rejection without requiring Windows symlink privileges.
            with patch.object(Path, "is_symlink", lambda path: path.name == "latest.log"):
                with self.assertRaises(exchange.TransportError):
                    exchange.prepare(folder)

    def test_failed_run_can_upload_without_source_package(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = self.fixture(Path(tmp), status="failed")
            (folder / "source.zip").unlink()
            _, manifest = exchange.prepare(folder)
            self.assertEqual("failed", manifest["status"])
            self.assertNotIn("source.zip", manifest["files"])

    def test_atomic_upload_preserves_base_tree_and_only_moves_evidence_branch(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, manifest = exchange.prepare(self.fixture(Path(tmp)))
            api = FakeGitHub()
            commit = exchange.publish(api, data, manifest)
            self.assertEqual(commit, api.head)
            self.assertEqual("original", api.visible()["README.md"])
            self.assertIn("runner-results/latest.json", api.visible())
            refs = [(p, b) for p, m, b in api.calls if m == "PATCH"]
            self.assertEqual([( "git/refs/heads/" + exchange.BRANCH, {"sha": commit, "force": False})], refs)
            self.assertEqual(manifest, exchange.read_json(api, "runner-results/latest.json", commit))

    def test_partial_upload_and_conflict_never_publish_latest(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, manifest = exchange.prepare(self.fixture(Path(tmp)))
            for fail in ("git/blobs", "git/trees", "git/commits", "git/refs/heads/" + exchange.BRANCH):
                api = FakeGitHub()
                api.fail = fail
                with self.assertRaises(exchange.TransportError):
                    exchange.publish(api, data, manifest)
                self.assertNotIn("runner-results/latest.json", api.visible())
                api.fail = None
                exchange.publish(api, data, manifest)
                self.assertIn("runner-results/latest.json", api.visible())

    def test_lost_reply_recovery_is_idempotent_and_old_receipt_does_not_rewind_latest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            api = FakeGitHub()
            data, first = exchange.prepare(self.fixture(root))
            exchange.publish(api, data, first)
            other, latest = exchange.prepare(self.fixture(root, "c" * 32))
            exchange.publish(api, other, latest)
            head = api.head
            exchange.publish(api, data, first)
            self.assertEqual(head, api.head)
            self.assertEqual(latest, exchange.read_json(api, "runner-results/latest.json", head))
            with self.assertRaisesRegex(exchange.TransportError, "id-conflict"):
                exchange.publish(api, data, {**first, "status": "failed"})

    def test_persistent_bounded_retries_keep_reports_without_rerunning_jobs(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            root = Path(tmp)
            self.fixture(root)
            self.fixture(root, "c" * 32)
            api = FakeGitHub()
            api.fail = "git/blobs"
            settings = {"repo": exchange.REPO}
            for _ in range(4):
                self.assertFalse(exchange.Uploader(root, settings, api).poll(force=True))
            ledger = json.loads((root / ".local/github-uploads.json").read_text())
            self.assertEqual(3, ledger["jobs"]["a" * 32]["attempts"])
            self.assertNotIn("c" * 32, ledger["jobs"])
            self.assertEqual(2, len(list((root / "reports").iterdir())))
            self.assertNotIn("runner-results/latest.json", api.visible())

    def test_completed_receipts_survive_restart_and_retries_are_throttled(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            root = Path(tmp)
            self.fixture(root)
            api = FakeGitHub()
            settings = {"repo": exchange.REPO}
            uploader = exchange.Uploader(root, settings, api)
            self.assertTrue(uploader.poll())
            calls = len(api.calls)
            uploader.poll()
            exchange.Uploader(root, settings, api).poll(force=True)
            self.assertEqual(calls, len(api.calls))

    def test_gh_uses_fixed_host_stdin_json_no_shell_and_hides_raw_failure(self):
        api = exchange.GitHub(exchange.REPO)
        with patch.object(exchange, "gh_path", return_value="gh"), \
             patch.object(exchange.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, b'{}', b'')) as run:
            api.api("git/blobs", "POST", {"content": "payload"})
        argv = run.call_args.args[0]
        self.assertIn("github.com", argv)
        self.assertNotIn("payload", argv)
        self.assertEqual({"content": "payload"}, json.loads(run.call_args.kwargs["input"]))
        self.assertNotIn("shell", run.call_args.kwargs)
        with patch.object(exchange, "command", return_value=subprocess.CompletedProcess([], 1, b'', b'account/private/path (HTTP 403)')):
            with self.assertRaisesRegex(exchange.TransportError, "^github-api-failed$"):
                api.api("contents/no", missing_ok=True)
        with patch.object(exchange, "command", return_value=subprocess.CompletedProcess([], 1, b'', b'(HTTP 404)')):
            self.assertIsNone(api.api("contents/no", missing_ok=True))

    def test_watch_upload_failure_does_not_reexecute_science(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            root = Path(tmp)
            source = root / "source.py"
            source.write_text("test")
            atomic_json(root / ".local/github-config.json", {"schema": 1, "repo": exchange.REPO, "branch": exchange.BRANCH})
            with patch.object(worker, "source_files", return_value={"source.py": source}), \
                 patch.object(worker, "healthy_python", return_value="python"), \
                 patch.object(worker, "execute", return_value={"status": "passed"}) as execute, \
                 patch.object(exchange.Uploader, "poll", return_value=False), \
                 patch.object(worker.time, "sleep", side_effect=[None, None, KeyboardInterrupt()]):
                self.assertEqual(0, worker.watch(root))
            self.assertEqual(1, execute.call_count)

    def test_setup_reuses_auth_and_does_not_enable_without_repo_write_access(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            root = Path(tmp)
            result = subprocess.CompletedProcess([], 0, b'', b'')
            with patch.object(exchange, "gh_path", return_value="gh"), \
                 patch.object(exchange, "command", return_value=result), \
                 patch.object(exchange.subprocess, "call") as login, \
                 patch.object(exchange.GitHub, "api", return_value={"permissions": {"push": False}}):
                with self.assertRaisesRegex(exchange.TransportError, "write-access-required"):
                    exchange.setup(root, exchange.REPO)
                self.assertFalse((root / ".local/github-config.json").exists())
                login.assert_not_called()
            with patch.object(exchange, "gh_path", return_value="gh"), \
                 patch.object(exchange, "command", return_value=result), \
                 patch.object(exchange.GitHub, "api", return_value={"permissions": {"push": True}}):
                exchange.setup(root, exchange.REPO)
            self.assertEqual(exchange.REPO, exchange.config(root)["repo"])

    def test_one_shot_reports_unsent_artifacts_as_failure(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            root = Path(tmp)
            source = root / "source.py"
            source.write_text("test")
            atomic_json(root / ".local/github-config.json", {"schema": 1, "repo": exchange.REPO, "branch": exchange.BRANCH})
            with patch.object(worker, "source_files", return_value={"source.py": source}), \
                 patch.object(worker, "healthy_python", return_value="python"), \
                 patch.object(worker, "execute", return_value={"status": "passed"}), \
                 patch.object(exchange.Uploader, "poll", return_value=False):
                self.assertEqual(1, worker.watch(root, once=True))


if __name__ == "__main__":
    unittest.main()
