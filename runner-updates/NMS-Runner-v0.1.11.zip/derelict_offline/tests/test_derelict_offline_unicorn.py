import copy
import struct
import unittest
from unittest.mock import patch
from derelict_offline.common import read_json
from derelict_offline.unicorn_check import (BASE, DATA, EVIDENCE, ZERO_COPY,
    EmulationError, Kernels, Machine, check, dependency, descriptor, supplement_vector)

try:
    dependency()
    AVAILABLE = True
except EmulationError:
    AVAILABLE = False


class DependencyTests(unittest.TestCase):
    def test_optional_missing_dependency_has_actionable_error(self):
        with patch.dict("sys.modules", {"unicorn": None}):
            with self.assertRaisesRegex(EmulationError, "Optional Unicorn is missing"):
                dependency()

    def test_wrong_binary_refused_before_importing_unicorn(self):
        evidence = read_json(EVIDENCE)
        evidence["binary"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(EmulationError, "executable identity"):
            Machine(evidence, [(0x640EA0, 0x640F30)])

    def test_supplement_preserves_input_and_records_only_same_binary_dependency(self):
        original = read_json(EVIDENCE)
        merged = supplement_vector(original)
        self.assertEqual(149, len(original["function_ranges"]))
        self.assertEqual(152, len(merged["function_ranges"]))
        self.assertEqual(original["byte_count"] + 406, merged["byte_count"])
        original["binary"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(EmulationError, "identity mismatch"):
            supplement_vector(original)


@unittest.skipUnless(AVAILABLE, "Optional pinned Unicorn is not installed")
class UnicornTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.evidence = read_json(EVIDENCE)

    def test_full_validation_including_captured_seeds_and_expected_failure(self):
        result = check(100)
        self.assertEqual(0, result["mismatches"])
        self.assertEqual(149, result["code_validation"]["range_count"])
        self.assertEqual(103256, result["code_validation"]["verified_code_bytes"])
        self.assertTrue(all(w["recomputed_window_matches"] for w in result["code_validation"]["window_checks"]))
        self.assertIn("0x145292041", result["expected_failure"]["nonempty_descriptor_copy"])
        self.assertTrue(result["allocator_boundary"]["code_supplied_and_executed"])
        self.assertFalse(result["root_derivation_verified"])
        self.assertFalse(result["layout_generation_verified"])

    def test_register_stack_and_memory_do_not_leak_between_cases(self):
        m = Machine(self.evidence, [(0x640EA0, 0x640F30)])
        m.reg("R9", 999)
        m.reg("XMM0", (1 << 128) - 1)
        m.vm.mem_write(DATA, b"private-state")
        m.reset()
        self.assertEqual(0, m.reg("R9"))
        self.assertEqual(0, m.reg("XMM0"))
        self.assertEqual(bytes(13), bytes(m.vm.mem_read(DATA, 13)))
        self.assertEqual(8, m.reg("RSP") % 16)

    def test_instruction_limit_is_reported_as_failure(self):
        m = Machine(self.evidence, [(0x640EA0, 0x640F30)])
        m.reg("RCX", DATA)
        with self.assertRaisesRegex(EmulationError, "limit reached"):
            m.execute(0x640EA0, limit=1)

    def test_missing_bytes_in_mapped_page_are_not_executed(self):
        m = Machine(self.evidence, [(0x640EA0, 0x640EA4)])
        with self.assertRaisesRegex(EmulationError, "Missing executable code.*00640EA4"):
            m.execute(0x640EA0)

    def test_unmapped_data_is_reported_as_failure(self):
        m = Machine(self.evidence, [(0x640EA0, 0x640F30)])
        m.reg("RCX", 0x40000000)
        with self.assertRaisesRegex(EmulationError, "Unmapped/protected memory"):
            m.execute(0x640EA0)

    def test_zero_copy_model_cannot_copy_nonzero_bytes(self):
        m = Machine(self.evidence, [], zero_copy=True)
        m.reg("R8", 1)
        with self.assertRaisesRegex(EmulationError, "refuses nonzero length"):
            m.execute(ZERO_COPY)

    def test_duplicate_removal_swaps_last_only_once_and_preserves_seeds(self):
        kernels = Kernels(self.evidence)
        a, b = bytes(32), b"\x01" * 32
        source = descriptor(0xFFFFFFFFFFFFFFFF, 255, 0, 0)
        result, obj, trace = kernels.remove_identifier([a, a, b], a, source)
        self.assertEqual([b, a], result)
        self.assertEqual(source[16:], obj[16:])
        self.assertEqual([], trace["environment_models"])

    def test_allocator_global_state_is_not_invented_for_nonempty_clone(self):
        kernels = Kernels(self.evidence)
        with self.assertRaisesRegex(EmulationError, "0x145292041"):
            kernels.copy_descriptor(descriptor(1, 1, 2, 0, count=1, pointer=DATA + 0x1000))

    def test_tampered_bytes_are_rejected(self):
        evidence = copy.deepcopy(self.evidence)
        evidence["function_ranges"][0]["bytes_hex"] = "90" + evidence["function_ranges"][0]["bytes_hex"][2:]
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            Machine(evidence, [(0x640EA0, 0x640F30)])


if __name__ == "__main__":
    unittest.main()
