"""Optional Linux x64 check against two exact, whitelisted integer blocks.

Runs in a child process in tests. No full function, external call, branch, game
memory or process attachment. Refuses changed bytes/hash or unsupported hosts.
The normal prototype is pure Python and works without this validation harness.
"""
import ctypes
import hashlib
import json
import mmap
import platform
import random
import statistics
import sys
import time
from . import VERSION
from .common import read_json, sha256
from .code_evidence import EVIDENCE, slice_bytes, verify
from .build_corpus import build
from .export_evidence import KNOWN_BINARY
from .rng_kernel import advance_output, seed_state

INIT = bytes.fromhex("8bc64585c9418bc90f94c0c1c9104103c1894548498bc148c1e82033c84133c9894d4c")
STEP = bytes.fromhex("8b454849bad731bd2c4881dd644869d099f8765a8b454c49b997296113c6a56ae34803d08bca4c69c199f8765a48c1ea204c03c2418bd0418bc048c1e020480bc149c1e820488bc848c1e9214833c8490fafca488bc148c1e8214833c1490fafc14869ca99f8765a488bd848c1eb214833d8")


def supported():
    return sys.platform == "linux" and platform.machine().lower() in ("x86_64", "amd64")


class CodeBlock:
    def __init__(self, code, signature):
        self.buffer = mmap.mmap(-1, mmap.PAGESIZE, prot=mmap.PROT_READ | mmap.PROT_WRITE)
        self.buffer.write(code)
        address = ctypes.addressof(ctypes.c_char.from_buffer(self.buffer))
        protect = ctypes.CDLL(None, use_errno=True).mprotect
        protect.argtypes = (ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int)
        protect.restype = ctypes.c_int
        if protect(address, mmap.PAGESIZE, mmap.PROT_READ | mmap.PROT_EXEC):
            self.buffer.close()
            raise OSError(ctypes.get_errno(), "Cannot make validation block executable")
        self.call = signature(address)

    def close(self):
        self.buffer.close()


def check(count=10000):
    if not supported():
        raise ValueError("Native check requires Linux x86-64; use pure-Python rng diagnostics elsewhere")
    evidence = read_json(EVIDENCE)
    corpus = build()
    verified = verify(evidence, corpus)
    if evidence["binary"]["sha256"] != KNOWN_BINARY:
        raise ValueError("Unsupported executable identity")
    if slice_bytes(evidence, 0x62E2E3, 0x62E306) != INIT or slice_bytes(evidence, 0x62E36D, 0x62E3DF) != STEP:
        raise ValueError("Whitelisted arithmetic bytes do not match evidence")
    # SysV wrappers preserve touched callee-saved registers. rbp addresses a
    # private 96-byte stack area; source blocks have no calls, jumps or returns.
    init_code = bytes.fromhex("55564883ec604889e533f64989f9") + INIT + bytes.fromhex("488b45484883c4605e5dc3")
    step_code = bytes.fromhex("55534883ec604889e548897d48") + STEP + bytes.fromhex("48891e488956084c8946104883c4605b5dc3")
    init = CodeBlock(init_code, ctypes.CFUNCTYPE(ctypes.c_uint64, ctypes.c_uint64))
    step = None
    try:
        step = CodeBlock(step_code, ctypes.CFUNCTYPE(None, ctypes.c_uint64, ctypes.POINTER(ctypes.c_uint64)))
        rng = random.Random(0x705)
        roots = [int(r["seed_hex"], 16) for c in corpus["cases"] for r in c["root_seeds"]]
        seeds = [0, 1, 0xFFFFFFFF, 1 << 32, (1 << 64) - 1, *roots]
        seeds += [rng.getrandbits(64) for _ in range(count)]
        states = [0, 1, 0xFFFFFFFF, (1 << 64) - 1] + [rng.getrandbits(64) for _ in range(count)]
        for seed in seeds:
            low, high = seed_state(seed, True)
            if init.call(seed) != (high << 32) | low:
                raise AssertionError(f"Initialization mismatch: {seed:016X}")
        output = (ctypes.c_uint64 * 3)()
        for state in states:
            step.call(state, output)
            new, value = advance_output((state & 0xFFFFFFFF, state >> 32))
            if tuple(output) != (value, *new):
                raise AssertionError(f"State/output mismatch: {state:016X}")
        timings = []
        for _ in range(5):
            start = time.perf_counter()
            for state in states:
                advance_output((state & 0xFFFFFFFF, state >> 32))
            timings.append(time.perf_counter() - start)
        return {"schema_version": 1, "prototype_version": VERSION,
                "evidence_sha256": sha256(EVIDENCE), "code_range_validation": verified,
                "validation_engine": "exact-whitelisted-exported-x64-instructions-in-private-stack-wrappers",
                "initialization_comparisons": len(seeds), "state_output_comparisons": len(states), "mismatches": 0,
                "kernel_benchmark": {"trials": 5, "cases_per_trial": len(states), "seconds_each": timings,
                                     "median_seconds": statistics.median(timings),
                                     "cases_per_second": len(states) / statistics.median(timings),
                                     "includes": ["Python state validation", "integer state/output arithmetic"],
                                     "excludes": ["asset selection", "root derivation", "layout generation", "I/O", "native harness"],
                                     "in_game_baseline_seconds": None, "end_to_end_speedup": None},
                "root_derivation_verified": False, "layout_generation_verified": False,
                "limits": ["Disabled-seed constant checked separately; native block tests enabled initialization",
                           "Arithmetic state inputs are controlled, not captured post-selection state",
                           "No full generation function or whole executable is executed"]}
    finally:
        if step is not None:
            step.close()
        init.close()


if __name__ == "__main__":
    print(json.dumps(check(), indent=2))
