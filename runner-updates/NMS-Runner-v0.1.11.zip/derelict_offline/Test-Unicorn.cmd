@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "NMS_RUNNER_HOME=%USERPROFILE%\Documents\NMS Runner"
if /I "%~dp0"=="%NMS_RUNNER_HOME%\" goto permanent_folder
call "%~dp0Install-Runner.cmd" --quiet-exit
if errorlevel 1 goto permanent_failed
call "%NMS_RUNNER_HOME%\Test-Unicorn.cmd" %*
exit /b %ERRORLEVEL%
:permanent_failed
echo Installation could not finish. Stop the old runner, close its window, then retry.
pause
exit /b 2
:permanent_folder
title NMS Offline - Unicorn checks
echo Starting the Unicorn checks...
pushd "%~dp0"
set "OFFLINE_PY=python"
where py.exe >nul 2>&1
if not errorlevel 1 set "OFFLINE_PY=py -3"
if exist ".unicorn-venv\Scripts\python.exe" set "OFFLINE_PY=.unicorn-venv\Scripts\python.exe"
call %OFFLINE_PY% -u start.py emulate --repetitions 1000 --out unicorn-local-result.json
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (echo Passed. Results: unicorn-local-result.json) else (echo See the error above. Install-Unicorn.cmd installs the optional dependency.)
popd
pause
exit /b %RC%
