@echo off
call "%~dp0Start-Runner.cmd" --watch %*
exit /b %ERRORLEVEL%
