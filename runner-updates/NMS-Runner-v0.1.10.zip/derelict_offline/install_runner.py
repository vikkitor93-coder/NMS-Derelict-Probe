"""Permanent-folder installation: preserve runtime state, lock and back up source."""
import argparse
from contextlib import ExitStack
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import uuid
import zipfile
from . import VERSION
from .common import HERE
from .local_runner import instance_lock, source_files
from .runner_protocol import digest


def default_folder():
    # On the requested Windows account: C:\Users\Vikman\Documents\NMS Runner.
    return Path.home() / "Documents" / "NMS Runner"


def copy_missing(source, target):
    """Permanent-folder data wins; never overwrite it with an extracted copy."""
    if not source.exists() or target.exists():
        return
    if source.is_symlink():
        raise ValueError("linked-runtime-data-needs-review")
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        # Refuse links instead of copying data outside the selected experiment.
        if any(path.is_symlink() for path in source.rglob("*")):
            raise ValueError("linked-runtime-data-needs-review")
        staging = target.with_name(target.name + ".install-" + uuid.uuid4().hex)
        try:
            shutil.copytree(source, staging)
            os.replace(staging, target)
        finally:
            if staging.exists():
                shutil.rmtree(staging)
    else:
        staging = target.with_name(target.name + ".install-" + uuid.uuid4().hex)
        try:
            shutil.copyfile(source, staging)
            os.replace(staging, target)
        finally:
            staging.unlink(missing_ok=True)


def private_python(root):
    return root / ".unicorn-venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def python_value(python, expression):
    result = subprocess.run([str(python), "-c", expression], stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=30)
    if result.returncode:
        raise ValueError("dependency-migration-probe-failed")
    return result.stdout.decode("utf-8", errors="strict").strip()


def migrate_unicorn(source, target):
    """Create a correctly rooted venv, reuse just the installed pinned wheel files."""
    if private_python(target).is_file() or not private_python(source).is_file():
        return
    old = private_python(source)
    try:
        base = python_value(old, "import sys;print(sys._base_executable)")
        site = Path(python_value(old, "import sysconfig;print(sysconfig.get_paths()['purelib'])"))
        python_value(old, "import unicorn;assert unicorn.__version__=='2.1.4';print('ready')")
    except (ValueError, OSError, subprocess.TimeoutExpired):
        print("Unicorn will be prepared automatically on first start.", flush=True)
        return
    print("Preparing Unicorn in the permanent folder using existing installed files...", flush=True)
    result = subprocess.run([base, "-m", "venv", str(target / ".unicorn-venv")],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    if result.returncode:
        raise ValueError("permanent-environment-creation-failed")
    destination = Path(python_value(private_python(target), "import sysconfig;print(sysconfig.get_paths()['purelib'])"))
    for name in ("unicorn", "unicorn-2.1.4.dist-info"):
        copy_missing(site / name, destination / name)
    python_value(private_python(target),
        "import unicorn;from unicorn import Uc,UC_ARCH_X86,UC_MODE_64;"
        "from unicorn.x86_const import UC_X86_REG_RAX;assert unicorn.__version__=='2.1.4';"
        "u=Uc(UC_ARCH_X86,UC_MODE_64);u.mem_map(4096,4096);"
        "u.mem_write(4096,bytes.fromhex('b82a000000'));u.emu_start(4096,4101,count=1);"
        "assert u.reg_read(UC_X86_REG_RAX)==42;print('ready')")


def installed_version(target):
    path = target / "__init__.py"
    if not path.is_file():
        return None
    match = re.search(r'VERSION\s*=\s*"(\d+\.\d+\.\d+)"', path.read_text(encoding="utf-8"))
    if not match:
        raise ValueError("unrecognized-installed-project")
    return tuple(map(int, match.group(1).split(".")))


def install(source, target, replace_source=False):
    source, target = Path(source).absolute(), Path(target).absolute()
    if source.is_symlink() or target.is_symlink():
        raise ValueError("linked-install-folder-needs-review")
    source, target = source.resolve(), target.resolve()
    for name in (*source_files(source), ".local", "reports", "requests", ".unicorn-venv"):
        path = target / name
        if any(parent.is_symlink() for parent in (path, *path.parents) if parent == target or target in parent.parents):
            raise ValueError("linked-installed-source-needs-review")
    if source == target:
        return {"status": "already-installed", "version": VERSION}
    if source in target.parents or target in source.parents:
        raise ValueError("install-folders-must-be-separate")
    files = source_files(source)
    expected = digest(files)
    if any(path.is_symlink() for path in files.values()) or target.is_symlink():
        raise ValueError("linked-install-folder-needs-review")
    with ExitStack() as stack:
        stack.enter_context(instance_lock(source / ".local"))
        stack.enter_context(instance_lock(target / ".local"))
        existing = installed_version(target)
        current = tuple(map(int, VERSION.split(".")))
        if existing and existing > current:
            raise ValueError("newer-runner-already-installed")
        unchanged = False
        if existing is None and any(path.name != ".local" for path in target.iterdir()):
            raise ValueError("install-folder-not-empty-or-not-a-runner")
        if existing == current and not replace_source:
            try:
                if digest({name: target / name for name in files}) == expected:
                    unchanged = True
            except OSError:
                pass
            if not unchanged:
                raise ValueError("same-version-source-conflict-use-install-replace-source")
        if not unchanged:
            prior = {}
            with tempfile.TemporaryDirectory(prefix="nms-install-") as tmp:
                staged = Path(tmp)
                for name, path in files.items():
                    out = staged / name
                    out.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(path, out)
                if digest({name: staged / name for name in files}) != expected or digest(files) != expected:
                    raise ValueError("source-changed-during-install")
                for name in files:
                    path = target / name
                    if path.is_symlink():
                        raise ValueError("linked-installed-source-needs-review")
                    if path.is_file():
                        prior[name] = path.read_bytes()
                if prior:
                    backup = target / ".local/source-backups" / (uuid.uuid4().hex + ".zip")
                    backup.parent.mkdir(parents=True, exist_ok=True)
                    with zipfile.ZipFile(backup, "w", zipfile.ZIP_DEFLATED) as archive:
                        for name, raw in prior.items():
                            archive.writestr("derelict_offline/" + name, raw)
                written, previous, created_dirs = [], {}, set()
                try:
                    for name in files:
                        path = target / name
                        for parent in path.parents:
                            if parent == target:
                                break
                            if not parent.exists():
                                created_dirs.add(parent)
                        path.parent.mkdir(parents=True, exist_ok=True)
                        temporary = path.with_name(path.name + ".install-" + uuid.uuid4().hex)
                        try:
                            shutil.copyfile(staged / name, temporary)
                            if path.is_file():
                                saved = path.with_name(path.name + ".rollback-" + uuid.uuid4().hex)
                                os.replace(path, saved)
                                previous[name] = saved
                            written.append(name)
                            os.replace(temporary, path)
                        finally:
                            temporary.unlink(missing_ok=True)
                except OSError:
                    for name in reversed(written):
                        if name in previous:
                            os.replace(previous[name], target / name)
                        else:
                            (target / name).unlink(missing_ok=True)
                    for directory in sorted(created_dirs, key=lambda p: len(p.parts), reverse=True):
                        try:
                            directory.rmdir()
                        except OSError:
                            pass
                    raise
                else:
                    for saved in previous.values():
                        saved.unlink(missing_ok=True)
        # Existing permanent state always wins. Source originals remain intact.
        local = source / ".local"
        for path in local.iterdir():
            if path.name not in ("runner.lock", "source-backups"):
                copy_missing(path, target / ".local" / path.name)
        for directory in ("reports", "requests"):
            parent = source / directory
            if parent.is_dir():
                for path in parent.iterdir():
                    copy_missing(path, target / directory / path.name)
        for name in ("latest-install.log", "unicorn-local-result.json"):
            copy_missing(source / name, target / name)
        migrate_unicorn(source, target)
        channel = target / ".local" / "update-channel.json"
        if not channel.exists():
            from .update_protocol import UPDATE_URL
            from .runner_protocol import atomic_json
            atomic_json(channel, {"schema": 1, "enabled": True, "feed_url": UPDATE_URL})
    return {"status": "already-installed" if unchanged else "installed", "version": VERSION}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", type=Path, default=default_folder())
    parser.add_argument("--replace-source", action="store_true", help="Explicitly repair differing same-version source; back up first")
    args = parser.parse_args(argv)
    try:
        print("Installing/updating the permanent NMS Runner folder...", flush=True)
        result = install(HERE, args.target, args.replace_source)
        print("Permanent runner " + result["version"] + ": " + result["status"], flush=True)
        return 0
    except (ValueError, OSError, subprocess.TimeoutExpired) as error:
        reason = str(error) if isinstance(error, ValueError) else "folder-locked-or-filesystem-error"
        print("Installation stopped: " + reason, flush=True)
        print("Stop the old runner and close its window, then retry. Existing reports/settings are retained.", flush=True)
        return 2
