"""Build a hash-indexed update bundle for the dedicated runner-updates branch."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile
from derelict_offline import VERSION
from derelict_offline.package_experiment import package
from derelict_offline.update_protocol import source_digest


def build(archive_path, manifest_path, source_commit):
    archive_path, manifest_path = Path(archive_path).resolve(), Path(manifest_path).resolve()
    completed = subprocess.run([sys.executable, "-u", "start.py", "test"],
                               cwd=Path(__file__).resolve().parents[1],
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=900)
    test_output = completed.stdout
    match = re.search(rb"Ran ([0-9]+) tests? in ", test_output)
    if completed.returncode or not match or b"OK" not in test_output[-512:]:
        raise ValueError("update-tests-did-not-pass")
    package(archive_path)
    archive_raw = archive_path.read_bytes()
    if len(archive_raw) > 8 * 1024 * 1024:
        raise ValueError("update-archive-exceeds-runner-limit")
    source_bytes = {}
    with zipfile.ZipFile(archive_path) as bundle:
        for item in bundle.infolist():
            name = item.filename.removeprefix("derelict_offline/")
            source_bytes[name] = bundle.read(item)
    version_line = 'VERSION = "' + VERSION + '"'
    if version_line.encode() not in source_bytes["__init__.py"].splitlines():
        raise ValueError("update-version-not-found")
    commit = source_commit.lower()
    if len(commit) != 40 or any(c not in "0123456789abcdef" for c in commit):
        raise ValueError("invalid-source-commit")
    files = {name: {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
             for name, raw in sorted(source_bytes.items())}
    value = {
        "schema": 1,
        "version": VERSION,
        "source_commit": commit,
        "source_sha256": source_digest(source_bytes),
        "archive_url": "https://raw.githubusercontent.com/vikkitor93-coder/NMS-Derelict-Probe/runner-updates/NMS-Runner-v" + VERSION + ".zip",
        "archive_sha256": hashlib.sha256(archive_raw).hexdigest(),
        "archive_bytes": len(archive_raw),
        "files": files,
        "tests_status": "passed",
        "tests_count": int(match.group(1)),
        "tests_output_sha256": hashlib.sha256(test_output).hexdigest(),
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return value


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--source-commit", required=True)
    args = parser.parse_args(argv)
    result = build(args.archive, args.manifest, args.source_commit)
    print(json.dumps({"version": result["version"], "source_sha256": result["source_sha256"],
                      "archive_sha256": result["archive_sha256"], "archive_bytes": result["archive_bytes"],
                      "file_count": len(result["files"])}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
