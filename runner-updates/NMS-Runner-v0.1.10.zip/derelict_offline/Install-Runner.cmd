@echo off
setlocal EnableExtensions DisableDelayedExpansion
title NMS Runner permanent folder installer 0.1.10
echo Installing NMS Runner 0.1.10 in your Documents folder...
set "NMS_INSTALL_QUIET="
if /I "%~1"=="--quiet-exit" set "NMS_INSTALL_QUIET=1"
pushd "%~dp0"
if errorlevel 1 goto folder_failed
if exist ".unicorn-venv\Scripts\python.exe" goto private
where py.exe >nul 2>&1
if not errorlevel 1 goto launcher
where python.exe >nul 2>&1
if not errorlevel 1 goto fallback
echo Python 3.10 or newer is required. Install Python, then try again.
set "RC=2"
goto finished
:private
call ".unicorn-venv\Scripts\python.exe" -u start.py install
set "RC=%ERRORLEVEL%"
goto finished
:launcher
call py.exe -3 -u start.py install
set "RC=%ERRORLEVEL%"
goto finished
:fallback
call python.exe -u start.py install
set "RC=%ERRORLEVEL%"
goto finished
:folder_failed
echo Extract the entire ZIP before installing.
set "RC=2"
goto report
:finished
popd
:report
if "%RC%"=="0" echo Ready. Open Start-Runner.cmd in "%USERPROFILE%\Documents\NMS Runner".
if not defined NMS_INSTALL_QUIET pause
exit /b %RC%
